import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  defineCommand,
  external_exports
} from "../chunks/chunk-KBCZMWDD.js";
import "../chunks/chunk-LWY6IOUG.js";

// src/commands/greet.ts
var greet_default = defineCommand({
  args: {
    _positional: external_exports.array(external_exports.string()).optional(),
    name: external_exports.string().optional()
  },
  handler: async (ctx) => {
    const name = ctx.args.name ?? ctx.args._positional?.[0] ?? "World";
    const company = typeof ctx.config.companyName === "string" ? ctx.config.companyName : "RenreKit";
    ctx.logger?.info(`Greeting ${name} from ${company}`);
    return {
      output: `Hello, ${name}! Welcome from ${company}.`,
      exitCode: 0
    };
  }
});
export {
  greet_default as default
};
