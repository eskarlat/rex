import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  defineCommand
} from "../chunks/chunk-KBCZMWDD.js";
import "../chunks/chunk-LWY6IOUG.js";

// src/commands/info.ts
var info_default = defineCommand({
  handler: async () => ({
    output: "hello-world v1.0.0 \u2014 A simple hello world extension for RenreKit",
    exitCode: 0
  })
});
export {
  info_default as default
};
