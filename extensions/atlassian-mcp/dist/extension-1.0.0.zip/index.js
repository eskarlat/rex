import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import "./chunks/chunk-LWY6IOUG.js";

// src/index.ts
function onInit(context) {
  context.sdk.deployAgentAssets();
}
function onDestroy(context) {
  context.sdk.cleanupAgentAssets();
}
export {
  onDestroy,
  onInit
};
