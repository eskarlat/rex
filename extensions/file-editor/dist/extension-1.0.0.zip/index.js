import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import "./chunks/chunk-LWY6IOUG.js";

// src/index.ts
function onInit(context) {
  context.sdk.logger.info("Initializing file-editor extension");
}
function onDestroy(context) {
  context.sdk.logger.info("Destroying file-editor extension");
}
export {
  onDestroy,
  onInit
};
