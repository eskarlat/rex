import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  defineCommand,
  external_exports
} from "../chunks/chunk-KBCZMWDD.js";
import "../chunks/chunk-LWY6IOUG.js";

// src/commands/tree.ts
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, resolve, relative } from "node:path";
function loadGitignorePatterns(projectPath) {
  try {
    const content = readFileSync(join(projectPath, ".gitignore"), "utf-8");
    return content.split("\n").map((line) => line.trim()).filter((line) => line && !line.startsWith("#"));
  } catch {
    return [];
  }
}
function isIgnored(name, relPath, patterns) {
  const alwaysIgnore = ["node_modules", ".git", "dist", ".DS_Store", "coverage"];
  if (alwaysIgnore.includes(name)) return true;
  for (const pattern of patterns) {
    const clean = pattern.replace(/\/$/, "");
    if (name === clean || relPath === clean || relPath.startsWith(clean + "/")) {
      return true;
    }
  }
  return false;
}
function listDirectory(dirPath, projectPath, patterns) {
  const entries = [];
  let dirEntries;
  try {
    dirEntries = readdirSync(dirPath, { withFileTypes: true });
  } catch {
    return entries;
  }
  for (const entry of dirEntries) {
    if (entry.isSymbolicLink()) continue;
    const fullPath = join(dirPath, entry.name);
    const relPath = relative(projectPath, fullPath);
    if (isIgnored(entry.name, relPath, patterns)) continue;
    if (entry.isDirectory()) {
      entries.push({
        name: entry.name,
        path: relPath,
        type: "directory"
      });
    } else if (entry.isFile()) {
      const stat = statSync(fullPath);
      const dotIdx = entry.name.lastIndexOf(".");
      entries.push({
        name: entry.name,
        path: relPath,
        type: "file",
        size: stat.size,
        extension: dotIdx > 0 ? entry.name.slice(dotIdx + 1) : void 0
      });
    }
  }
  entries.sort((a, b) => {
    if (a.type !== b.type) return a.type === "directory" ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  return entries;
}
var tree_default = defineCommand({
  args: {
    path: external_exports.string().optional().default("")
  },
  handler: async (ctx) => {
    const projectPath = ctx.projectPath;
    const requestedPath = ctx.args.path || "";
    const targetDir = resolve(projectPath, requestedPath);
    if (!targetDir.startsWith(resolve(projectPath))) {
      return { output: JSON.stringify({ error: "Path outside project directory" }), exitCode: 1 };
    }
    const patterns = loadGitignorePatterns(projectPath);
    const entries = listDirectory(targetDir, projectPath, patterns);
    return {
      output: JSON.stringify(entries),
      exitCode: 0
    };
  }
});
export {
  tree_default as default
};
