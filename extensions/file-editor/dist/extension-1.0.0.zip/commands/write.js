import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  defineCommand,
  external_exports,
  isInsideProject
} from "../chunks/chunk-X6MQCY6J.js";
import "../chunks/chunk-LWY6IOUG.js";

// src/commands/write.ts
import { writeFileSync, mkdirSync } from "node:fs";
import { resolve, dirname } from "node:path";
var write_default = defineCommand({
  args: {
    path: external_exports.string(),
    content: external_exports.string()
  },
  handler: (ctx) => {
    const projectPath = ctx.projectPath;
    const filePath = resolve(projectPath, ctx.args.path);
    if (!isInsideProject(projectPath, filePath)) {
      return { output: JSON.stringify({ error: "Path outside project directory" }), exitCode: 1 };
    }
    try {
      mkdirSync(dirname(filePath), { recursive: true });
      writeFileSync(filePath, ctx.args.content, "utf-8");
      return {
        output: JSON.stringify({ success: true, path: ctx.args.path }),
        exitCode: 0
      };
    } catch {
      return {
        output: JSON.stringify({ error: "Failed to write file" }),
        exitCode: 1
      };
    }
  }
});
export {
  write_default as default
};
