import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  defineCommand,
  external_exports,
  isInsideProject
} from "../chunks/chunk-X6MQCY6J.js";
import "../chunks/chunk-LWY6IOUG.js";

// src/commands/create.ts
import { writeFileSync, mkdirSync, existsSync } from "node:fs";
import { resolve, dirname } from "node:path";
var create_default = defineCommand({
  args: {
    path: external_exports.string(),
    type: external_exports.enum(["file", "directory"])
  },
  handler: (ctx) => {
    const projectPath = ctx.projectPath;
    const targetPath = resolve(projectPath, ctx.args.path);
    if (!isInsideProject(projectPath, targetPath)) {
      return { output: JSON.stringify({ error: "Path outside project directory" }), exitCode: 1 };
    }
    if (existsSync(targetPath)) {
      return { output: JSON.stringify({ error: "Path already exists" }), exitCode: 1 };
    }
    try {
      if (ctx.args.type === "directory") {
        mkdirSync(targetPath, { recursive: true });
      } else {
        mkdirSync(dirname(targetPath), { recursive: true });
        writeFileSync(targetPath, "", "utf-8");
      }
      return {
        output: JSON.stringify({ success: true, path: ctx.args.path, type: ctx.args.type }),
        exitCode: 0
      };
    } catch {
      return {
        output: JSON.stringify({ error: `Failed to create ${ctx.args.type}` }),
        exitCode: 1
      };
    }
  }
});
export {
  create_default as default
};
