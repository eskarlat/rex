import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  defineCommand,
  external_exports
} from "../chunks/chunk-KBCZMWDD.js";
import "../chunks/chunk-LWY6IOUG.js";

// src/commands/rename.ts
import { renameSync, existsSync, mkdirSync } from "node:fs";
import { resolve, dirname } from "node:path";
var rename_default = defineCommand({
  args: {
    oldPath: external_exports.string(),
    newPath: external_exports.string()
  },
  handler: async (ctx) => {
    const projectPath = ctx.projectPath;
    const sourcePath = resolve(projectPath, ctx.args.oldPath);
    const destPath = resolve(projectPath, ctx.args.newPath);
    if (!sourcePath.startsWith(resolve(projectPath))) {
      return {
        output: JSON.stringify({ error: "Source path outside project directory" }),
        exitCode: 1
      };
    }
    if (!destPath.startsWith(resolve(projectPath))) {
      return {
        output: JSON.stringify({ error: "Destination path outside project directory" }),
        exitCode: 1
      };
    }
    if (!existsSync(sourcePath)) {
      return { output: JSON.stringify({ error: "Source path does not exist" }), exitCode: 1 };
    }
    if (existsSync(destPath)) {
      return {
        output: JSON.stringify({ error: "Destination path already exists" }),
        exitCode: 1
      };
    }
    try {
      mkdirSync(dirname(destPath), { recursive: true });
      renameSync(sourcePath, destPath);
      return {
        output: JSON.stringify({
          success: true,
          oldPath: ctx.args.oldPath,
          newPath: ctx.args.newPath
        }),
        exitCode: 0
      };
    } catch {
      return {
        output: JSON.stringify({ error: "Failed to rename/move" }),
        exitCode: 1
      };
    }
  }
});
export {
  rename_default as default
};
