import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  defineCommand,
  external_exports
} from "../chunks/chunk-KBCZMWDD.js";
import "../chunks/chunk-LWY6IOUG.js";

// src/commands/delete.ts
import { rmSync, existsSync } from "node:fs";
import { resolve } from "node:path";
var delete_default = defineCommand({
  args: {
    path: external_exports.string()
  },
  handler: (ctx) => {
    const projectPath = ctx.projectPath;
    const targetPath = resolve(projectPath, ctx.args.path);
    if (!targetPath.startsWith(resolve(projectPath))) {
      return { output: JSON.stringify({ error: "Path outside project directory" }), exitCode: 1 };
    }
    if (!existsSync(targetPath)) {
      return { output: JSON.stringify({ error: "Path does not exist" }), exitCode: 1 };
    }
    if (resolve(targetPath) === resolve(projectPath)) {
      return { output: JSON.stringify({ error: "Cannot delete project root" }), exitCode: 1 };
    }
    try {
      rmSync(targetPath, { recursive: true, force: true });
      return {
        output: JSON.stringify({ success: true, path: ctx.args.path }),
        exitCode: 0
      };
    } catch {
      return {
        output: JSON.stringify({ error: "Failed to delete path" }),
        exitCode: 1
      };
    }
  }
});
export {
  delete_default as default
};
