// react-global:react
var R = window.__RENRE_REACT__;
var {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
  useContext,
  useReducer,
  useId,
  useLayoutEffect,
  useInsertionEffect,
  useImperativeHandle,
  useDebugValue,
  useSyncExternalStore,
  useTransition,
  useDeferredValue,
  createContext,
  createElement,
  createRef,
  forwardRef,
  memo,
  lazy,
  Fragment,
  Suspense,
  StrictMode,
  Component,
  Children,
  cloneElement,
  isValidElement,
  startTransition
} = R;

// react-global:react/jsx-runtime
var { jsx, jsxs, Fragment: Fragment2 } = window.__RENRE_JSX_RUNTIME__;

// src/ui/editor-panel.tsx
var FILE_ICONS = {
  ts: "\u{1F7E6}",
  tsx: "\u269B\uFE0F",
  js: "\u{1F7E8}",
  jsx: "\u269B\uFE0F",
  json: "\u{1F4CB}",
  md: "\u{1F4DD}",
  css: "\u{1F3A8}",
  scss: "\u{1F3A8}",
  html: "\u{1F310}",
  svg: "\u{1F5BC}\uFE0F",
  png: "\u{1F5BC}\uFE0F",
  jpg: "\u{1F5BC}\uFE0F",
  py: "\u{1F40D}",
  rb: "\u{1F48E}",
  rs: "\u{1F980}",
  go: "\u{1F439}",
  java: "\u2615",
  sh: "\u{1F41A}",
  yaml: "\u2699\uFE0F",
  yml: "\u2699\uFE0F",
  toml: "\u2699\uFE0F",
  sql: "\u{1F5C4}\uFE0F",
  dockerfile: "\u{1F433}",
  gitignore: "\u{1F4C2}",
  env: "\u{1F512}",
  lock: "\u{1F512}"
};
function getFileIcon(name, type, expanded) {
  if (type === "directory") return expanded ? "\u{1F4C2}" : "\u{1F4C1}";
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  return FILE_ICONS[ext] ?? "\u{1F4C4}";
}
function FileTreeNode({
  node,
  depth,
  onToggle,
  onSelect,
  onContextMenu,
  onDrop,
  selectedPath
}) {
  const [dragOver, setDragOver] = useState(false);
  const handleDragStart = (e) => {
    e.dataTransfer.setData("text/plain", node.path);
    e.dataTransfer.effectAllowed = "move";
  };
  const handleDragOver = (e) => {
    if (node.type !== "directory") return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setDragOver(true);
  };
  const handleDragLeave = () => setDragOver(false);
  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const sourcePath = e.dataTransfer.getData("text/plain");
    if (sourcePath && sourcePath !== node.path && node.type === "directory") {
      onDrop(sourcePath, node.path);
    }
  };
  const handleClick = () => {
    if (node.type === "directory") {
      onToggle(node);
    } else {
      onSelect(node);
    }
  };
  const isSelected = selectedPath === node.path;
  return /* @__PURE__ */ jsxs(Fragment2, { children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: `flex items-center cursor-pointer select-none hover:bg-accent/50 ${isSelected ? "bg-accent text-accent-foreground" : ""} ${dragOver ? "bg-primary/20 outline outline-1 outline-primary" : ""}`,
        style: { paddingLeft: `${depth * 16 + 8}px`, height: "28px" },
        onClick: handleClick,
        onContextMenu: (e) => onContextMenu(e, node),
        draggable: true,
        onDragStart: handleDragStart,
        onDragOver: handleDragOver,
        onDragLeave: handleDragLeave,
        onDrop: handleDrop,
        children: [
          node.type === "directory" && /* @__PURE__ */ jsx("span", { className: "mr-1 text-xs text-muted-foreground w-3 inline-block", children: node.expanded ? "\u25BE" : "\u25B8" }),
          node.type === "file" && /* @__PURE__ */ jsx("span", { className: "mr-1 w-3 inline-block" }),
          /* @__PURE__ */ jsx("span", { className: "mr-1.5 text-sm", children: getFileIcon(node.name, node.type, node.expanded) }),
          /* @__PURE__ */ jsx("span", { className: "text-sm truncate", children: node.name })
        ]
      }
    ),
    node.type === "directory" && node.expanded && node.children?.map((child) => /* @__PURE__ */ jsx(
      FileTreeNode,
      {
        node: child,
        depth: depth + 1,
        onToggle,
        onSelect,
        onContextMenu,
        onDrop,
        selectedPath
      },
      child.path
    ))
  ] });
}
function ContextMenu({
  state,
  onClose,
  onNewFile,
  onNewFolder,
  onRename,
  onDelete
}) {
  const ref = useRef(null);
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (ref.current && !ref.current.contains(e.target)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [onClose]);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      ref,
      className: "fixed z-50 min-w-[160px] rounded-md border bg-popover p-1 shadow-md",
      style: { left: state.x, top: state.y },
      children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "w-full text-left px-3 py-1.5 text-sm rounded-sm hover:bg-accent hover:text-accent-foreground",
            onClick: () => {
              onNewFile();
              onClose();
            },
            children: "New File"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "w-full text-left px-3 py-1.5 text-sm rounded-sm hover:bg-accent hover:text-accent-foreground",
            onClick: () => {
              onNewFolder();
              onClose();
            },
            children: "New Folder"
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "h-px my-1 bg-border" }),
        state.node && /* @__PURE__ */ jsxs(Fragment2, { children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "w-full text-left px-3 py-1.5 text-sm rounded-sm hover:bg-accent hover:text-accent-foreground",
              onClick: () => {
                onRename();
                onClose();
              },
              children: "Rename"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "w-full text-left px-3 py-1.5 text-sm rounded-sm text-destructive hover:bg-destructive/10",
              onClick: () => {
                onDelete();
                onClose();
              },
              children: "Delete"
            }
          )
        ] })
      ]
    }
  );
}
function InlineInput({
  defaultValue,
  onSubmit,
  onCancel,
  depth
}) {
  const inputRef = useRef(null);
  useEffect(() => {
    inputRef.current?.focus();
    inputRef.current?.select();
  }, []);
  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      const value = inputRef.current?.value.trim();
      if (value) onSubmit(value);
    } else if (e.key === "Escape") {
      onCancel();
    }
  };
  return /* @__PURE__ */ jsx("div", { style: { paddingLeft: `${depth * 16 + 8}px`, height: "28px" }, className: "flex items-center", children: /* @__PURE__ */ jsx(
    "input",
    {
      ref: inputRef,
      defaultValue,
      onKeyDown: handleKeyDown,
      onBlur: onCancel,
      className: "h-6 w-full bg-background border border-primary rounded px-1 text-sm focus:outline-none"
    }
  ) });
}
function TabBar({
  tabs,
  activeIndex,
  onSelect,
  onClose
}) {
  return /* @__PURE__ */ jsx("div", { className: "flex items-center border-b bg-muted/30 overflow-x-auto", children: tabs.map((tab, i) => /* @__PURE__ */ jsxs(
    "div",
    {
      className: `group flex items-center gap-1.5 px-3 py-1.5 text-sm cursor-pointer border-r border-b-2 select-none whitespace-nowrap ${i === activeIndex ? "bg-background border-b-primary text-foreground" : "bg-muted/30 border-b-transparent text-muted-foreground hover:bg-muted/60"}`,
      onClick: () => onSelect(i),
      children: [
        /* @__PURE__ */ jsx("span", { className: "text-xs", children: getFileIcon(tab.name, "file") }),
        /* @__PURE__ */ jsx("span", { children: tab.name }),
        tab.modified && /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-primary inline-block" }),
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "ml-1 opacity-0 group-hover:opacity-100 hover:bg-accent rounded px-0.5 text-xs text-muted-foreground hover:text-foreground",
            onClick: (e) => {
              e.stopPropagation();
              onClose(i);
            },
            children: "\xD7"
          }
        )
      ]
    },
    tab.path
  )) });
}
function CodeEditor({
  content,
  language,
  onChange,
  onSave,
  theme
}) {
  const [MonacoEditor, setMonacoEditor] = useState(null);
  const [monacoError, setMonacoError] = useState(false);
  useEffect(() => {
    import("https://cdn.jsdelivr.net/npm/@monaco-editor/react@4.7.0/+esm").then((mod) => {
      setMonacoEditor(() => mod.default ?? mod.Editor);
    }).catch(() => {
      setMonacoError(true);
    });
  }, []);
  const handleKeyDown = useCallback(
    (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        onSave();
      }
    },
    [onSave]
  );
  if (MonacoEditor && !monacoError) {
    return /* @__PURE__ */ jsx("div", { className: "h-full", onKeyDown: handleKeyDown, children: /* @__PURE__ */ jsx(
      MonacoEditor,
      {
        height: "100%",
        language,
        value: content,
        theme,
        onChange: (val) => onChange(val ?? ""),
        options: {
          minimap: { enabled: true },
          fontSize: 13,
          lineNumbers: "on",
          wordWrap: "on",
          scrollBeyondLastLine: false,
          automaticLayout: true,
          tabSize: 2
        }
      }
    ) });
  }
  return /* @__PURE__ */ jsx(
    "textarea",
    {
      className: `w-full h-full resize-none font-mono text-sm p-4 focus:outline-none ${theme === "vs-dark" ? "bg-[#1e1e1e] text-[#d4d4d4]" : "bg-white text-[#1e1e1e]"}`,
      value: content,
      onChange: (e) => onChange(e.target.value),
      onKeyDown: handleKeyDown,
      spellCheck: false
    }
  );
}
function EditorPanel({ sdk, extensionName }) {
  const [treeNodes, setTreeNodes] = useState([]);
  const [tabs, setTabs] = useState([]);
  const [activeTabIndex, setActiveTabIndex] = useState(-1);
  const [loading, setLoading] = useState(true);
  const [contextMenu, setContextMenu] = useState(null);
  const [inlineInput, setInlineInput] = useState(null);
  const [theme, setTheme] = useState("vs-dark");
  const [sidebarWidth, setSidebarWidth] = useState(260);
  const resizingRef = useRef(false);
  const containerRef = useRef(null);
  const extName = extensionName ?? "file-editor";
  const activeTab = activeTabIndex >= 0 && activeTabIndex < tabs.length ? tabs[activeTabIndex] : null;
  const loadDirectory = useCallback(
    async (path) => {
      if (!sdk) return [];
      try {
        const result = await sdk.exec.run(`${extName}:tree`, { path });
        const entries = JSON.parse(result.output);
        return entries.map((e) => ({
          ...e,
          loaded: e.type === "file",
          expanded: false,
          children: e.type === "directory" ? [] : void 0
        }));
      } catch {
        return [];
      }
    },
    [sdk, extName]
  );
  useEffect(() => {
    loadDirectory("").then((nodes) => {
      setTreeNodes(nodes);
      setLoading(false);
    });
  }, [loadDirectory]);
  const updateNodeInTree = useCallback(
    (nodes, path, updater) => {
      return nodes.map((node) => {
        if (node.path === path) return updater(node);
        if (node.children) {
          return { ...node, children: updateNodeInTree(node.children, path, updater) };
        }
        return node;
      });
    },
    []
  );
  const handleToggle = useCallback(
    async (node) => {
      if (node.expanded) {
        setTreeNodes(
          (prev) => updateNodeInTree(prev, node.path, (n) => ({ ...n, expanded: false }))
        );
        return;
      }
      if (!node.loaded) {
        const children = await loadDirectory(node.path);
        setTreeNodes(
          (prev) => updateNodeInTree(prev, node.path, (n) => ({
            ...n,
            expanded: true,
            loaded: true,
            children
          }))
        );
      } else {
        setTreeNodes(
          (prev) => updateNodeInTree(prev, node.path, (n) => ({ ...n, expanded: true }))
        );
      }
    },
    [loadDirectory, updateNodeInTree]
  );
  const handleSelect = useCallback(
    async (node) => {
      const existingIndex = tabs.findIndex((t) => t.path === node.path);
      if (existingIndex >= 0) {
        setActiveTabIndex(existingIndex);
        return;
      }
      if (!sdk) return;
      try {
        const result = await sdk.exec.run(`${extName}:read`, { path: node.path });
        const data = JSON.parse(result.output);
        if (data.error) {
          sdk.ui.toast({ title: "Error", description: data.error, variant: "destructive" });
          return;
        }
        const newTab = {
          path: node.path,
          name: node.name,
          content: data.content,
          originalContent: data.content,
          language: data.language,
          modified: false
        };
        setTabs((prev) => [...prev, newTab]);
        setActiveTabIndex(tabs.length);
      } catch {
        sdk.ui.toast({ title: "Error", description: "Failed to open file", variant: "destructive" });
      }
    },
    [sdk, extName, tabs]
  );
  const handleSave = useCallback(async () => {
    if (!activeTab || !sdk || !activeTab.modified) return;
    try {
      await sdk.exec.run(`${extName}:write`, {
        path: activeTab.path,
        content: activeTab.content
      });
      setTabs(
        (prev) => prev.map(
          (t, i) => i === activeTabIndex ? { ...t, modified: false, originalContent: t.content } : t
        )
      );
      sdk.ui.toast({ title: "Saved", description: activeTab.name });
    } catch {
      sdk.ui.toast({ title: "Error", description: "Failed to save", variant: "destructive" });
    }
  }, [activeTab, activeTabIndex, sdk, extName]);
  const handleTabClose = useCallback(
    (index) => {
      const tab = tabs[index];
      if (tab?.modified) {
        sdk?.ui.toast({ title: "Unsaved changes", description: `${tab.name} has unsaved changes` });
      }
      setTabs((prev) => prev.filter((_, i) => i !== index));
      if (activeTabIndex >= index && activeTabIndex > 0) {
        setActiveTabIndex((prev) => prev - 1);
      } else if (tabs.length <= 1) {
        setActiveTabIndex(-1);
      }
    },
    [tabs, activeTabIndex, sdk]
  );
  const handleContentChange = useCallback(
    (value) => {
      setTabs(
        (prev) => prev.map(
          (t, i) => i === activeTabIndex ? { ...t, content: value, modified: value !== t.originalContent } : t
        )
      );
    },
    [activeTabIndex]
  );
  const handleContextMenu = useCallback((e, node) => {
    e.preventDefault();
    const parentPath = node.type === "directory" ? node.path : node.path.split("/").slice(0, -1).join("/");
    setContextMenu({ x: e.clientX, y: e.clientY, node, parentPath });
  }, []);
  const handleTreeContextMenu = useCallback((e) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY, node: null, parentPath: "" });
  }, []);
  const getNodeDepth = useCallback((path) => {
    if (!path) return 0;
    return path.split("/").length;
  }, []);
  const handleNewFile = useCallback(() => {
    const parentPath = contextMenu?.parentPath ?? "";
    setInlineInput({
      type: "new-file",
      parentPath,
      depth: getNodeDepth(parentPath) + 1
    });
  }, [contextMenu, getNodeDepth]);
  const handleNewFolder = useCallback(() => {
    const parentPath = contextMenu?.parentPath ?? "";
    setInlineInput({
      type: "new-folder",
      parentPath,
      depth: getNodeDepth(parentPath) + 1
    });
  }, [contextMenu, getNodeDepth]);
  const handleRename = useCallback(() => {
    if (!contextMenu?.node) return;
    const node = contextMenu.node;
    setInlineInput({
      type: "rename",
      parentPath: node.path.split("/").slice(0, -1).join("/"),
      depth: getNodeDepth(node.path),
      originalPath: node.path,
      originalName: node.name
    });
  }, [contextMenu, getNodeDepth]);
  const handleDelete = useCallback(async () => {
    if (!contextMenu?.node || !sdk) return;
    const node = contextMenu.node;
    try {
      await sdk.exec.run(`${extName}:delete`, { path: node.path });
      const removeFromTree = (nodes) => nodes.filter((n) => n.path !== node.path).map((n) => ({
        ...n,
        children: n.children ? removeFromTree(n.children) : void 0
      }));
      setTreeNodes(removeFromTree);
      const tabIdx = tabs.findIndex((t) => t.path === node.path);
      if (tabIdx >= 0) handleTabClose(tabIdx);
      sdk.ui.toast({ title: "Deleted", description: node.name });
    } catch {
      sdk.ui.toast({ title: "Error", description: "Failed to delete", variant: "destructive" });
    }
  }, [contextMenu, sdk, extName, tabs, handleTabClose]);
  const handleInlineSubmit = useCallback(
    async (value) => {
      if (!sdk || !inlineInput) return;
      const { type, parentPath, originalPath } = inlineInput;
      const newPath = parentPath ? `${parentPath}/${value}` : value;
      try {
        if (type === "new-file") {
          await sdk.exec.run(`${extName}:create`, { path: newPath, type: "file" });
        } else if (type === "new-folder") {
          await sdk.exec.run(`${extName}:create`, { path: newPath, type: "directory" });
        } else if (type === "rename" && originalPath) {
          const oldParent = originalPath.split("/").slice(0, -1).join("/");
          const targetPath = oldParent ? `${oldParent}/${value}` : value;
          await sdk.exec.run(`${extName}:rename`, { oldPath: originalPath, newPath: targetPath });
          setTabs(
            (prev) => prev.map(
              (t) => t.path === originalPath ? { ...t, path: targetPath, name: value } : t
            )
          );
        }
        const parentNodes = await loadDirectory(parentPath);
        if (!parentPath) {
          setTreeNodes(parentNodes);
        } else {
          setTreeNodes(
            (prev) => updateNodeInTree(prev, parentPath, (n) => ({
              ...n,
              children: parentNodes,
              loaded: true,
              expanded: true
            }))
          );
        }
      } catch {
        sdk.ui.toast({ title: "Error", description: `Failed to ${type}`, variant: "destructive" });
      }
      setInlineInput(null);
    },
    [sdk, extName, inlineInput, loadDirectory, updateNodeInTree]
  );
  const handleDrop = useCallback(
    async (sourcePath, targetDirPath) => {
      if (!sdk) return;
      const fileName = sourcePath.split("/").pop() ?? "";
      const newPath = `${targetDirPath}/${fileName}`;
      try {
        await sdk.exec.run(`${extName}:rename`, { oldPath: sourcePath, newPath });
        setTabs(
          (prev) => prev.map((t) => t.path === sourcePath ? { ...t, path: newPath } : t)
        );
        const sourceParent = sourcePath.split("/").slice(0, -1).join("/");
        const refreshParent = async (parentPath) => {
          const nodes = await loadDirectory(parentPath);
          if (!parentPath) {
            setTreeNodes(nodes);
          } else {
            setTreeNodes(
              (prev) => updateNodeInTree(prev, parentPath, (n) => ({
                ...n,
                children: nodes,
                loaded: true
              }))
            );
          }
        };
        await refreshParent(sourceParent);
        await refreshParent(targetDirPath);
        sdk.ui.toast({ title: "Moved", description: `${fileName} \u2192 ${targetDirPath}` });
      } catch {
        sdk.ui.toast({ title: "Error", description: "Failed to move", variant: "destructive" });
      }
    },
    [sdk, extName, loadDirectory, updateNodeInTree]
  );
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleSave]);
  const handleResizeMouseDown = useCallback((e) => {
    e.preventDefault();
    resizingRef.current = true;
    const startX = e.clientX;
    const startWidth = sidebarWidth;
    const onMouseMove = (moveEvent) => {
      if (!resizingRef.current) return;
      const diff = moveEvent.clientX - startX;
      const newWidth = Math.max(180, Math.min(500, startWidth + diff));
      setSidebarWidth(newWidth);
    };
    const onMouseUp = () => {
      resizingRef.current = false;
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  }, [sidebarWidth]);
  const [rootDragOver, setRootDragOver] = useState(false);
  const handleRootDragOver = useCallback((e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setRootDragOver(true);
  }, []);
  const handleRootDrop = useCallback(
    (e) => {
      e.preventDefault();
      setRootDragOver(false);
      const sourcePath = e.dataTransfer.getData("text/plain");
      if (sourcePath) {
        const fileName = sourcePath.split("/").pop() ?? "";
        handleDrop(sourcePath, "").catch(() => {
        });
        void fileName;
      }
    },
    [handleDrop]
  );
  const detectedTheme = useMemo(() => {
    if (typeof document === "undefined") return "vs-dark";
    return document.documentElement.classList.contains("dark") ? "vs-dark" : "vs-light";
  }, []);
  useEffect(() => {
    setTheme(detectedTheme);
  }, [detectedTheme]);
  if (loading) {
    return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-96 text-muted-foreground", children: "Loading file tree..." });
  }
  return /* @__PURE__ */ jsxs("div", { ref: containerRef, className: "flex h-[calc(100vh-200px)] border rounded-lg overflow-hidden bg-background", children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: "flex flex-col border-r bg-muted/20 overflow-hidden",
        style: { width: `${sidebarWidth}px`, minWidth: `${sidebarWidth}px` },
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-3 py-2 border-b bg-muted/40", children: [
            /* @__PURE__ */ jsx("span", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Explorer" }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-1", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  className: "h-6 w-6 flex items-center justify-center rounded hover:bg-accent text-muted-foreground hover:text-foreground text-xs",
                  title: "New File",
                  onClick: () => {
                    setInlineInput({ type: "new-file", parentPath: "", depth: 0 });
                  },
                  children: "+"
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  className: "h-6 w-6 flex items-center justify-center rounded hover:bg-accent text-muted-foreground hover:text-foreground text-xs",
                  title: "New Folder",
                  onClick: () => {
                    setInlineInput({ type: "new-folder", parentPath: "", depth: 0 });
                  },
                  children: "\u{1F4C1}"
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  className: "h-6 w-6 flex items-center justify-center rounded hover:bg-accent text-muted-foreground hover:text-foreground text-xs",
                  title: "Refresh",
                  onClick: () => {
                    loadDirectory("").then(setTreeNodes);
                  },
                  children: "\u21BB"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs(
            "div",
            {
              className: `flex-1 overflow-auto py-1 ${rootDragOver ? "bg-primary/10" : ""}`,
              onContextMenu: handleTreeContextMenu,
              onDragOver: handleRootDragOver,
              onDragLeave: () => setRootDragOver(false),
              onDrop: handleRootDrop,
              children: [
                treeNodes.map((node) => /* @__PURE__ */ jsx(
                  FileTreeNode,
                  {
                    node,
                    depth: 0,
                    onToggle: handleToggle,
                    onSelect: handleSelect,
                    onContextMenu: handleContextMenu,
                    onDrop: handleDrop,
                    selectedPath: activeTab?.path ?? null
                  },
                  node.path
                )),
                inlineInput && !inlineInput.originalPath && /* @__PURE__ */ jsx(
                  InlineInput,
                  {
                    defaultValue: "",
                    depth: inlineInput.depth,
                    onSubmit: handleInlineSubmit,
                    onCancel: () => setInlineInput(null)
                  }
                ),
                treeNodes.length === 0 && !inlineInput && /* @__PURE__ */ jsx("div", { className: "text-sm text-muted-foreground text-center py-8 px-4", children: "No files found." })
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: "w-1 cursor-col-resize hover:bg-primary/30 active:bg-primary/50 flex-shrink-0",
        onMouseDown: handleResizeMouseDown
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "flex-1 flex flex-col overflow-hidden", children: tabs.length > 0 ? /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsx(
        TabBar,
        {
          tabs,
          activeIndex: activeTabIndex,
          onSelect: setActiveTabIndex,
          onClose: handleTabClose
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-3 py-1 border-b bg-muted/20", children: [
        /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground truncate", children: activeTab?.path }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: activeTab?.language }),
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "text-xs px-2 py-0.5 rounded hover:bg-accent text-muted-foreground hover:text-foreground",
              onClick: () => setTheme((t) => t === "vs-dark" ? "vs-light" : "vs-dark"),
              children: theme === "vs-dark" ? "\u2600\uFE0F" : "\u{1F319}"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "text-xs px-2 py-0.5 rounded bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50",
              onClick: handleSave,
              disabled: !activeTab?.modified,
              children: "Save"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-hidden", children: activeTab && /* @__PURE__ */ jsx(
        CodeEditor,
        {
          content: activeTab.content,
          language: activeTab.language,
          onChange: handleContentChange,
          onSave: handleSave,
          theme
        }
      ) })
    ] }) : /* @__PURE__ */ jsxs("div", { className: "flex-1 flex flex-col items-center justify-center text-muted-foreground gap-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-6xl", children: "\u{1F4DD}" }),
      /* @__PURE__ */ jsx("div", { className: "text-lg font-medium", children: "No file open" }),
      /* @__PURE__ */ jsx("div", { className: "text-sm", children: "Select a file from the explorer to start editing" }),
      /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground/60 mt-4 space-y-1 text-center", children: [
        /* @__PURE__ */ jsx("div", { children: "Ctrl+S \u2014 Save file" }),
        /* @__PURE__ */ jsx("div", { children: "Right-click \u2014 Context menu" }),
        /* @__PURE__ */ jsx("div", { children: "Drag & drop \u2014 Move files" })
      ] })
    ] }) }),
    contextMenu && /* @__PURE__ */ jsx(
      ContextMenu,
      {
        state: contextMenu,
        onClose: () => setContextMenu(null),
        onNewFile: handleNewFile,
        onNewFolder: handleNewFolder,
        onRename: handleRename,
        onDelete: handleDelete
      }
    ),
    inlineInput?.originalPath && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-40", onClick: () => setInlineInput(null), children: /* @__PURE__ */ jsx(
      "div",
      {
        className: "absolute",
        style: { left: sidebarWidth * 0.3, top: "50%" },
        onClick: (e) => e.stopPropagation(),
        children: /* @__PURE__ */ jsx(
          InlineInput,
          {
            defaultValue: inlineInput.originalName ?? "",
            depth: 0,
            onSubmit: handleInlineSubmit,
            onCancel: () => setInlineInput(null)
          }
        )
      }
    ) })
  ] });
}
export {
  EditorPanel as default
};
