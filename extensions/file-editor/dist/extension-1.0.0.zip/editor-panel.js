// react-global:react
var R = window.__RENRE_REACT__;
var react_default = R;
var {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
  useContext,
  useReducer,
  useId,
  useLayoutEffect,
  useInsertionEffect,
  useImperativeHandle,
  useDebugValue,
  useSyncExternalStore,
  useTransition,
  useDeferredValue,
  createContext,
  createElement,
  createRef,
  forwardRef,
  memo,
  lazy,
  Fragment,
  Suspense,
  StrictMode,
  Component,
  Children,
  cloneElement,
  isValidElement,
  startTransition
} = R;

// react-global:react/jsx-runtime
var { jsx, jsxs, Fragment: Fragment2 } = window.__RENRE_JSX_RUNTIME__;

// src/ui/ContextMenu.tsx
function ContextMenu({
  state,
  onClose,
  onNewFile,
  onNewFolder,
  onRename,
  onDelete
}) {
  const ref = useRef(null);
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (ref.current && !ref.current.contains(e.target)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [onClose]);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      ref,
      className: "fixed z-50 min-w-[160px] rounded-md border bg-popover p-1 shadow-md",
      style: { left: state.x, top: state.y },
      children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "w-full text-left px-3 py-1.5 text-sm rounded-sm hover:bg-accent hover:text-accent-foreground",
            onClick: () => {
              onNewFile();
              onClose();
            },
            children: "New File"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "w-full text-left px-3 py-1.5 text-sm rounded-sm hover:bg-accent hover:text-accent-foreground",
            onClick: () => {
              onNewFolder();
              onClose();
            },
            children: "New Folder"
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "h-px my-1 bg-border" }),
        state.node && /* @__PURE__ */ jsxs(Fragment2, { children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "w-full text-left px-3 py-1.5 text-sm rounded-sm hover:bg-accent hover:text-accent-foreground",
              onClick: () => {
                onRename();
                onClose();
              },
              children: "Rename"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "w-full text-left px-3 py-1.5 text-sm rounded-sm text-destructive hover:bg-destructive/10",
              onClick: () => {
                onDelete();
                onClose();
              },
              children: "Delete"
            }
          )
        ] })
      ]
    }
  );
}

// src/ui/InlineInput.tsx
function InlineInput({
  defaultValue,
  onSubmit,
  onCancel,
  depth
}) {
  const inputRef = useRef(null);
  useEffect(() => {
    inputRef.current?.focus();
    inputRef.current?.select();
  }, []);
  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      const value = inputRef.current?.value.trim();
      if (value) onSubmit(value);
    } else if (e.key === "Escape") {
      onCancel();
    }
  };
  return /* @__PURE__ */ jsx("div", { style: { paddingLeft: `${depth * 16 + 8}px`, height: "28px" }, className: "flex items-center", children: /* @__PURE__ */ jsx(
    "input",
    {
      ref: inputRef,
      defaultValue,
      onKeyDown: handleKeyDown,
      onBlur: onCancel,
      className: "h-6 w-full bg-background border border-primary rounded px-1 text-sm focus:outline-none"
    }
  ) });
}

// src/ui/file-icons.ts
var FILE_ICONS = {
  ts: "\u{1F7E6}",
  tsx: "\u269B\uFE0F",
  js: "\u{1F7E8}",
  jsx: "\u269B\uFE0F",
  json: "\u{1F4CB}",
  md: "\u{1F4DD}",
  css: "\u{1F3A8}",
  scss: "\u{1F3A8}",
  html: "\u{1F310}",
  svg: "\u{1F5BC}\uFE0F",
  png: "\u{1F5BC}\uFE0F",
  jpg: "\u{1F5BC}\uFE0F",
  py: "\u{1F40D}",
  rb: "\u{1F48E}",
  rs: "\u{1F980}",
  go: "\u{1F439}",
  java: "\u2615",
  sh: "\u{1F41A}",
  yaml: "\u2699\uFE0F",
  yml: "\u2699\uFE0F",
  toml: "\u2699\uFE0F",
  sql: "\u{1F5C4}\uFE0F",
  dockerfile: "\u{1F433}",
  gitignore: "\u{1F4C2}",
  env: "\u{1F512}",
  lock: "\u{1F512}"
};
function getFileIcon(name, type, expanded) {
  if (type === "directory") return expanded ? "\u{1F4C2}" : "\u{1F4C1}";
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  return FILE_ICONS[ext] ?? "\u{1F4C4}";
}

// src/ui/FileTreeNode.tsx
function FileTreeNode({
  node,
  depth,
  onToggle,
  onSelect,
  onContextMenu,
  onDrop,
  selectedPath
}) {
  const [dragOver, setDragOver] = useState(false);
  const handleDragStart = (e) => {
    e.dataTransfer.setData("text/plain", node.path);
    e.dataTransfer.effectAllowed = "move";
  };
  const handleDragOver = (e) => {
    if (node.type !== "directory") return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setDragOver(true);
  };
  const handleDragLeave = () => setDragOver(false);
  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const sourcePath = e.dataTransfer.getData("text/plain");
    if (sourcePath && sourcePath !== node.path && node.type === "directory") {
      onDrop(sourcePath, node.path);
    }
  };
  const handleClick = () => {
    if (node.type === "directory") {
      onToggle(node);
    } else {
      onSelect(node);
    }
  };
  const isSelected = selectedPath === node.path;
  return /* @__PURE__ */ jsxs(Fragment2, { children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: `flex items-center cursor-pointer select-none hover:bg-accent/50 ${isSelected ? "bg-accent text-accent-foreground" : ""} ${dragOver ? "bg-primary/20 outline outline-1 outline-primary" : ""}`,
        style: { paddingLeft: `${depth * 16 + 8}px`, height: "28px" },
        onClick: handleClick,
        onContextMenu: (e) => onContextMenu(e, node),
        draggable: true,
        onDragStart: handleDragStart,
        onDragOver: handleDragOver,
        onDragLeave: handleDragLeave,
        onDrop: handleDrop,
        children: [
          node.type === "directory" && /* @__PURE__ */ jsx("span", { className: "mr-1 text-xs text-muted-foreground w-3 inline-block", children: node.expanded ? "\u25BE" : "\u25B8" }),
          node.type === "file" && /* @__PURE__ */ jsx("span", { className: "mr-1 w-3 inline-block" }),
          /* @__PURE__ */ jsx("span", { className: "mr-1.5 text-sm", children: getFileIcon(node.name, node.type, node.expanded) }),
          /* @__PURE__ */ jsx("span", { className: "text-sm truncate", children: node.name })
        ]
      }
    ),
    node.type === "directory" && node.expanded && node.children?.map((child) => /* @__PURE__ */ jsx(
      FileTreeNode,
      {
        node: child,
        depth: depth + 1,
        onToggle,
        onSelect,
        onContextMenu,
        onDrop,
        selectedPath
      },
      child.path
    ))
  ] });
}

// src/ui/Sidebar.tsx
function Sidebar({
  treeNodes,
  sidebarWidth,
  rootDragOver,
  activeFilePath,
  inlineInput,
  onToggle,
  onSelect,
  onContextMenu,
  onDrop,
  onTreeContextMenu,
  onRootDragOver,
  onRootDragLeave,
  onRootDrop,
  onNewFile,
  onNewFolder,
  onRefresh,
  onInlineSubmit,
  onInlineCancel
}) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "flex flex-col border-r bg-muted/20 overflow-hidden",
      style: { width: `${sidebarWidth}px`, minWidth: `${sidebarWidth}px` },
      children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-3 py-2 border-b bg-muted/40", children: [
          /* @__PURE__ */ jsx("span", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Explorer" }),
          /* @__PURE__ */ jsxs("div", { className: "flex gap-1", children: [
            /* @__PURE__ */ jsx(
              "button",
              {
                className: "h-6 w-6 flex items-center justify-center rounded hover:bg-accent text-muted-foreground hover:text-foreground text-xs",
                title: "New File",
                onClick: onNewFile,
                children: "+"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                className: "h-6 w-6 flex items-center justify-center rounded hover:bg-accent text-muted-foreground hover:text-foreground text-xs",
                title: "New Folder",
                onClick: onNewFolder,
                children: "\u{1F4C1}"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                className: "h-6 w-6 flex items-center justify-center rounded hover:bg-accent text-muted-foreground hover:text-foreground text-xs",
                title: "Refresh",
                onClick: onRefresh,
                children: "\u21BB"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs(
          "div",
          {
            className: `flex-1 overflow-auto py-1 ${rootDragOver ? "bg-primary/10" : ""}`,
            onContextMenu: onTreeContextMenu,
            onDragOver: onRootDragOver,
            onDragLeave: onRootDragLeave,
            onDrop: onRootDrop,
            children: [
              treeNodes.map((node) => /* @__PURE__ */ jsx(
                FileTreeNode,
                {
                  node,
                  depth: 0,
                  onToggle,
                  onSelect,
                  onContextMenu,
                  onDrop,
                  selectedPath: activeFilePath
                },
                node.path
              )),
              inlineInput && !inlineInput.originalPath && /* @__PURE__ */ jsx(
                InlineInput,
                {
                  defaultValue: "",
                  depth: inlineInput.depth,
                  onSubmit: onInlineSubmit,
                  onCancel: onInlineCancel
                }
              ),
              treeNodes.length === 0 && !inlineInput && /* @__PURE__ */ jsx("div", { className: "text-sm text-muted-foreground text-center py-8 px-4", children: "No files found." })
            ]
          }
        )
      ]
    }
  );
}

// src/ui/TabBar.tsx
function TabBar({
  tabs,
  activeIndex,
  onSelect,
  onClose
}) {
  return /* @__PURE__ */ jsx("div", { className: "flex items-center border-b bg-muted/30 overflow-x-auto", children: tabs.map((tab, i) => /* @__PURE__ */ jsxs(
    "div",
    {
      className: `group flex items-center gap-1.5 px-3 py-1.5 text-sm cursor-pointer border-r border-b-2 select-none whitespace-nowrap ${i === activeIndex ? "bg-background border-b-primary text-foreground" : "bg-muted/30 border-b-transparent text-muted-foreground hover:bg-muted/60"}`,
      onClick: () => onSelect(i),
      children: [
        /* @__PURE__ */ jsx("span", { className: "text-xs", children: getFileIcon(tab.name, "file") }),
        /* @__PURE__ */ jsx("span", { children: tab.name }),
        tab.modified && /* @__PURE__ */ jsx("span", { className: "w-2 h-2 rounded-full bg-primary inline-block" }),
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "ml-1 opacity-0 group-hover:opacity-100 hover:bg-accent rounded px-0.5 text-xs text-muted-foreground hover:text-foreground",
            onClick: (e) => {
              e.stopPropagation();
              onClose(i);
            },
            children: "\xD7"
          }
        )
      ]
    },
    tab.path
  )) });
}

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/_virtual/_rollupPluginBabelHelpers.js
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}
function _defineProperty(e, r, t) {
  return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: true,
    configurable: true,
    writable: true
  }) : e[r] = t, e;
}
function _iterableToArrayLimit(r, l2) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e, n, i, u, a = [], f = true, o = false;
    try {
      if (i = (t = t.call(r)).next, 0 === l2) ;
      else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l2); f = true) ;
    } catch (r2) {
      o = true, n = r2;
    } finally {
      try {
        if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function(r2) {
      return Object.getOwnPropertyDescriptor(e, r2).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread2(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
      _defineProperty(e, r2, t[r2]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
      Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
    });
  }
  return e;
}
function _objectWithoutProperties(e, t) {
  if (null == e) return {};
  var o, r, i = _objectWithoutPropertiesLoose(e, t);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
  }
  return i;
}
function _objectWithoutPropertiesLoose(r, e) {
  if (null == r) return {};
  var t = {};
  for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
    if (-1 !== e.indexOf(n)) continue;
    t[n] = r[n];
  }
  return t;
}
function _slicedToArray(r, e) {
  return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _toPrimitive(t, r) {
  if ("object" != typeof t || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r);
    if ("object" != typeof i) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == typeof i ? i : i + "";
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}

// ../../node_modules/.pnpm/state-local@1.0.7/node_modules/state-local/lib/es/state-local.js
function _defineProperty2(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
function ownKeys2(object, enumerableOnly) {
  var keys = Object.keys(object);
  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function(sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }
  return keys;
}
function _objectSpread22(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};
    if (i % 2) {
      ownKeys2(Object(source), true).forEach(function(key) {
        _defineProperty2(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys2(Object(source)).forEach(function(key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }
  return target;
}
function compose() {
  for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }
  return function(x) {
    return fns.reduceRight(function(y, f) {
      return f(y);
    }, x);
  };
}
function curry(fn) {
  return function curried() {
    var _this = this;
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    return args.length >= fn.length ? fn.apply(this, args) : function() {
      for (var _len3 = arguments.length, nextArgs = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        nextArgs[_key3] = arguments[_key3];
      }
      return curried.apply(_this, [].concat(args, nextArgs));
    };
  };
}
function isObject(value) {
  return {}.toString.call(value).includes("Object");
}
function isEmpty(obj) {
  return !Object.keys(obj).length;
}
function isFunction(value) {
  return typeof value === "function";
}
function hasOwnProperty(object, property) {
  return Object.prototype.hasOwnProperty.call(object, property);
}
function validateChanges(initial, changes) {
  if (!isObject(changes)) errorHandler("changeType");
  if (Object.keys(changes).some(function(field) {
    return !hasOwnProperty(initial, field);
  })) errorHandler("changeField");
  return changes;
}
function validateSelector(selector) {
  if (!isFunction(selector)) errorHandler("selectorType");
}
function validateHandler(handler) {
  if (!(isFunction(handler) || isObject(handler))) errorHandler("handlerType");
  if (isObject(handler) && Object.values(handler).some(function(_handler) {
    return !isFunction(_handler);
  })) errorHandler("handlersType");
}
function validateInitial(initial) {
  if (!initial) errorHandler("initialIsRequired");
  if (!isObject(initial)) errorHandler("initialType");
  if (isEmpty(initial)) errorHandler("initialContent");
}
function throwError(errorMessages3, type) {
  throw new Error(errorMessages3[type] || errorMessages3["default"]);
}
var errorMessages = {
  initialIsRequired: "initial state is required",
  initialType: "initial state should be an object",
  initialContent: "initial state shouldn't be an empty object",
  handlerType: "handler should be an object or a function",
  handlersType: "all handlers should be a functions",
  selectorType: "selector should be a function",
  changeType: "provided value of changes should be an object",
  changeField: 'it seams you want to change a field in the state which is not specified in the "initial" state',
  "default": "an unknown error accured in `state-local` package"
};
var errorHandler = curry(throwError)(errorMessages);
var validators = {
  changes: validateChanges,
  selector: validateSelector,
  handler: validateHandler,
  initial: validateInitial
};
function create(initial) {
  var handler = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  validators.initial(initial);
  validators.handler(handler);
  var state = {
    current: initial
  };
  var didUpdate = curry(didStateUpdate)(state, handler);
  var update = curry(updateState)(state);
  var validate = curry(validators.changes)(initial);
  var getChanges = curry(extractChanges)(state);
  function getState2() {
    var selector = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : function(state2) {
      return state2;
    };
    validators.selector(selector);
    return selector(state.current);
  }
  function setState2(causedChanges) {
    compose(didUpdate, update, validate, getChanges)(causedChanges);
  }
  return [getState2, setState2];
}
function extractChanges(state, causedChanges) {
  return isFunction(causedChanges) ? causedChanges(state.current) : causedChanges;
}
function updateState(state, changes) {
  state.current = _objectSpread22(_objectSpread22({}, state.current), changes);
  return changes;
}
function didStateUpdate(state, handler, changes) {
  isFunction(handler) ? handler(state.current) : Object.keys(changes).forEach(function(field) {
    var _handler$field;
    return (_handler$field = handler[field]) === null || _handler$field === void 0 ? void 0 : _handler$field.call(handler, state.current[field]);
  });
  return changes;
}
var index = {
  create
};
var state_local_default = index;

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/config/index.js
var config = {
  paths: {
    vs: "https://cdn.jsdelivr.net/npm/monaco-editor@0.55.1/min/vs"
  }
};

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/utils/curry.js
function curry2(fn) {
  return function curried() {
    var _this = this;
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return args.length >= fn.length ? fn.apply(this, args) : function() {
      for (var _len2 = arguments.length, nextArgs = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        nextArgs[_key2] = arguments[_key2];
      }
      return curried.apply(_this, [].concat(args, nextArgs));
    };
  };
}

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/utils/isObject.js
function isObject2(value) {
  return {}.toString.call(value).includes("Object");
}

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/validators/index.js
function validateConfig(config3) {
  if (!config3) errorHandler2("configIsRequired");
  if (!isObject2(config3)) errorHandler2("configType");
  if (config3.urls) {
    informAboutDeprecation();
    return {
      paths: {
        vs: config3.urls.monacoBase
      }
    };
  }
  return config3;
}
function informAboutDeprecation() {
  console.warn(errorMessages2.deprecation);
}
function throwError2(errorMessages3, type) {
  throw new Error(errorMessages3[type] || errorMessages3["default"]);
}
var errorMessages2 = {
  configIsRequired: "the configuration object is required",
  configType: "the configuration object should be an object",
  "default": "an unknown error accured in `@monaco-editor/loader` package",
  deprecation: "Deprecation warning!\n    You are using deprecated way of configuration.\n\n    Instead of using\n      monaco.config({ urls: { monacoBase: '...' } })\n    use\n      monaco.config({ paths: { vs: '...' } })\n\n    For more please check the link https://github.com/suren-atoyan/monaco-loader#config\n  "
};
var errorHandler2 = curry2(throwError2)(errorMessages2);
var validators2 = {
  config: validateConfig
};

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/utils/compose.js
var compose2 = function compose3() {
  for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }
  return function(x) {
    return fns.reduceRight(function(y, f) {
      return f(y);
    }, x);
  };
};

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/utils/deepMerge.js
function merge(target, source) {
  Object.keys(source).forEach(function(key) {
    if (source[key] instanceof Object) {
      if (target[key]) {
        Object.assign(source[key], merge(target[key], source[key]));
      }
    }
  });
  return _objectSpread2(_objectSpread2({}, target), source);
}

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/utils/makeCancelable.js
var CANCELATION_MESSAGE = {
  type: "cancelation",
  msg: "operation is manually canceled"
};
function makeCancelable(promise) {
  var hasCanceled_ = false;
  var wrappedPromise = new Promise(function(resolve, reject) {
    promise.then(function(val) {
      return hasCanceled_ ? reject(CANCELATION_MESSAGE) : resolve(val);
    });
    promise["catch"](reject);
  });
  return wrappedPromise.cancel = function() {
    return hasCanceled_ = true;
  }, wrappedPromise;
}

// ../../node_modules/.pnpm/@monaco-editor+loader@1.7.0/node_modules/@monaco-editor/loader/lib/es/loader/index.js
var _excluded = ["monaco"];
var _state$create = state_local_default.create({
  config,
  isInitialized: false,
  resolve: null,
  reject: null,
  monaco: null
});
var _state$create2 = _slicedToArray(_state$create, 2);
var getState = _state$create2[0];
var setState = _state$create2[1];
function config2(globalConfig) {
  var _validators$config = validators2.config(globalConfig), monaco = _validators$config.monaco, config3 = _objectWithoutProperties(_validators$config, _excluded);
  setState(function(state) {
    return {
      config: merge(state.config, config3),
      monaco
    };
  });
}
function init() {
  var state = getState(function(_ref) {
    var monaco = _ref.monaco, isInitialized = _ref.isInitialized, resolve = _ref.resolve;
    return {
      monaco,
      isInitialized,
      resolve
    };
  });
  if (!state.isInitialized) {
    setState({
      isInitialized: true
    });
    if (state.monaco) {
      state.resolve(state.monaco);
      return makeCancelable(wrapperPromise);
    }
    if (window.monaco && window.monaco.editor) {
      storeMonacoInstance(window.monaco);
      state.resolve(window.monaco);
      return makeCancelable(wrapperPromise);
    }
    compose2(injectScripts, getMonacoLoaderScript)(configureLoader);
  }
  return makeCancelable(wrapperPromise);
}
function injectScripts(script) {
  return document.body.appendChild(script);
}
function createScript(src) {
  var script = document.createElement("script");
  return src && (script.src = src), script;
}
function getMonacoLoaderScript(configureLoader2) {
  var state = getState(function(_ref2) {
    var config3 = _ref2.config, reject = _ref2.reject;
    return {
      config: config3,
      reject
    };
  });
  var loaderScript = createScript("".concat(state.config.paths.vs, "/loader.js"));
  loaderScript.onload = function() {
    return configureLoader2();
  };
  loaderScript.onerror = state.reject;
  return loaderScript;
}
function configureLoader() {
  var state = getState(function(_ref3) {
    var config3 = _ref3.config, resolve = _ref3.resolve, reject = _ref3.reject;
    return {
      config: config3,
      resolve,
      reject
    };
  });
  var require2 = window.require;
  require2.config(state.config);
  require2(["vs/editor/editor.main"], function(loaded) {
    var monaco = loaded.m || loaded;
    storeMonacoInstance(monaco);
    state.resolve(monaco);
  }, function(error) {
    state.reject(error);
  });
}
function storeMonacoInstance(monaco) {
  if (!getState().monaco) {
    setState({
      monaco
    });
  }
}
function __getMonacoInstance() {
  return getState(function(_ref4) {
    var monaco = _ref4.monaco;
    return monaco;
  });
}
var wrapperPromise = new Promise(function(resolve, reject) {
  return setState({
    resolve,
    reject
  });
});
var loader = {
  config: config2,
  init,
  __getMonacoInstance
};

// ../../node_modules/.pnpm/@monaco-editor+react@4.7.0_monaco-editor@0.55.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@monaco-editor/react/dist/index.mjs
var le = { wrapper: { display: "flex", position: "relative", textAlign: "initial" }, fullWidth: { width: "100%" }, hide: { display: "none" } };
var v = le;
var ae = { container: { display: "flex", height: "100%", width: "100%", justifyContent: "center", alignItems: "center" } };
var Y = ae;
function Me({ children: e }) {
  return react_default.createElement("div", { style: Y.container }, e);
}
var Z = Me;
var $ = Z;
function Ee({ width: e, height: r, isEditorReady: n, loading: t, _ref: a, className: m, wrapperProps: E }) {
  return react_default.createElement("section", { style: { ...v.wrapper, width: e, height: r }, ...E }, !n && react_default.createElement($, null, t), react_default.createElement("div", { ref: a, style: { ...v.fullWidth, ...!n && v.hide }, className: m }));
}
var ee = Ee;
var H = memo(ee);
function Ce(e) {
  useEffect(e, []);
}
var k = Ce;
function he(e, r, n = true) {
  let t = useRef(true);
  useEffect(t.current || !n ? () => {
    t.current = false;
  } : e, r);
}
var l = he;
function D() {
}
function h(e, r, n, t) {
  return De(e, t) || be(e, r, n, t);
}
function De(e, r) {
  return e.editor.getModel(te(e, r));
}
function be(e, r, n, t) {
  return e.editor.createModel(r, n, t ? te(e, t) : void 0);
}
function te(e, r) {
  return e.Uri.parse(r);
}
function Oe({ original: e, modified: r, language: n, originalLanguage: t, modifiedLanguage: a, originalModelPath: m, modifiedModelPath: E, keepCurrentOriginalModel: g = false, keepCurrentModifiedModel: N = false, theme: x = "light", loading: P = "Loading...", options: y = {}, height: V = "100%", width: z = "100%", className: F, wrapperProps: j = {}, beforeMount: A = D, onMount: q = D }) {
  let [M, O] = useState(false), [T, s] = useState(true), u = useRef(null), c = useRef(null), w = useRef(null), d = useRef(q), o = useRef(A), b = useRef(false);
  k(() => {
    let i = loader.init();
    return i.then((f) => (c.current = f) && s(false)).catch((f) => f?.type !== "cancelation" && console.error("Monaco initialization: error:", f)), () => u.current ? I() : i.cancel();
  }), l(() => {
    if (u.current && c.current) {
      let i = u.current.getOriginalEditor(), f = h(c.current, e || "", t || n || "text", m || "");
      f !== i.getModel() && i.setModel(f);
    }
  }, [m], M), l(() => {
    if (u.current && c.current) {
      let i = u.current.getModifiedEditor(), f = h(c.current, r || "", a || n || "text", E || "");
      f !== i.getModel() && i.setModel(f);
    }
  }, [E], M), l(() => {
    let i = u.current.getModifiedEditor();
    i.getOption(c.current.editor.EditorOption.readOnly) ? i.setValue(r || "") : r !== i.getValue() && (i.executeEdits("", [{ range: i.getModel().getFullModelRange(), text: r || "", forceMoveMarkers: true }]), i.pushUndoStop());
  }, [r], M), l(() => {
    u.current?.getModel()?.original.setValue(e || "");
  }, [e], M), l(() => {
    let { original: i, modified: f } = u.current.getModel();
    c.current.editor.setModelLanguage(i, t || n || "text"), c.current.editor.setModelLanguage(f, a || n || "text");
  }, [n, t, a], M), l(() => {
    c.current?.editor.setTheme(x);
  }, [x], M), l(() => {
    u.current?.updateOptions(y);
  }, [y], M);
  let L = useCallback(() => {
    if (!c.current) return;
    o.current(c.current);
    let i = h(c.current, e || "", t || n || "text", m || ""), f = h(c.current, r || "", a || n || "text", E || "");
    u.current?.setModel({ original: i, modified: f });
  }, [n, r, a, e, t, m, E]), U = useCallback(() => {
    !b.current && w.current && (u.current = c.current.editor.createDiffEditor(w.current, { automaticLayout: true, ...y }), L(), c.current?.editor.setTheme(x), O(true), b.current = true);
  }, [y, x, L]);
  useEffect(() => {
    M && d.current(u.current, c.current);
  }, [M]), useEffect(() => {
    !T && !M && U();
  }, [T, M, U]);
  function I() {
    let i = u.current?.getModel();
    g || i?.original?.dispose(), N || i?.modified?.dispose(), u.current?.dispose();
  }
  return react_default.createElement(H, { width: z, height: V, isEditorReady: M, loading: P, _ref: w, className: F, wrapperProps: j });
}
var ie = Oe;
var we = memo(ie);
function He(e) {
  let r = useRef();
  return useEffect(() => {
    r.current = e;
  }, [e]), r.current;
}
var se = He;
var _ = /* @__PURE__ */ new Map();
function Ve({ defaultValue: e, defaultLanguage: r, defaultPath: n, value: t, language: a, path: m, theme: E = "light", line: g, loading: N = "Loading...", options: x = {}, overrideServices: P = {}, saveViewState: y = true, keepCurrentModel: V = false, width: z = "100%", height: F = "100%", className: j, wrapperProps: A = {}, beforeMount: q = D, onMount: M = D, onChange: O, onValidate: T = D }) {
  let [s, u] = useState(false), [c, w] = useState(true), d = useRef(null), o = useRef(null), b = useRef(null), L = useRef(M), U = useRef(q), I = useRef(), i = useRef(t), f = se(m), Q = useRef(false), B = useRef(false);
  k(() => {
    let p = loader.init();
    return p.then((R2) => (d.current = R2) && w(false)).catch((R2) => R2?.type !== "cancelation" && console.error("Monaco initialization: error:", R2)), () => o.current ? pe() : p.cancel();
  }), l(() => {
    let p = h(d.current, e || t || "", r || a || "", m || n || "");
    p !== o.current?.getModel() && (y && _.set(f, o.current?.saveViewState()), o.current?.setModel(p), y && o.current?.restoreViewState(_.get(m)));
  }, [m], s), l(() => {
    o.current?.updateOptions(x);
  }, [x], s), l(() => {
    !o.current || t === void 0 || (o.current.getOption(d.current.editor.EditorOption.readOnly) ? o.current.setValue(t) : t !== o.current.getValue() && (B.current = true, o.current.executeEdits("", [{ range: o.current.getModel().getFullModelRange(), text: t, forceMoveMarkers: true }]), o.current.pushUndoStop(), B.current = false));
  }, [t], s), l(() => {
    let p = o.current?.getModel();
    p && a && d.current?.editor.setModelLanguage(p, a);
  }, [a], s), l(() => {
    g !== void 0 && o.current?.revealLine(g);
  }, [g], s), l(() => {
    d.current?.editor.setTheme(E);
  }, [E], s);
  let X = useCallback(() => {
    if (!(!b.current || !d.current) && !Q.current) {
      U.current(d.current);
      let p = m || n, R2 = h(d.current, t || e || "", r || a || "", p || "");
      o.current = d.current?.editor.create(b.current, { model: R2, automaticLayout: true, ...x }, P), y && o.current.restoreViewState(_.get(p)), d.current.editor.setTheme(E), g !== void 0 && o.current.revealLine(g), u(true), Q.current = true;
    }
  }, [e, r, n, t, a, m, x, P, y, E, g]);
  useEffect(() => {
    s && L.current(o.current, d.current);
  }, [s]), useEffect(() => {
    !c && !s && X();
  }, [c, s, X]), i.current = t, useEffect(() => {
    s && O && (I.current?.dispose(), I.current = o.current?.onDidChangeModelContent((p) => {
      B.current || O(o.current.getValue(), p);
    }));
  }, [s, O]), useEffect(() => {
    if (s) {
      let p = d.current.editor.onDidChangeMarkers((R2) => {
        let G = o.current.getModel()?.uri;
        if (G && R2.find((J) => J.path === G.path)) {
          let J = d.current.editor.getModelMarkers({ resource: G });
          T?.(J);
        }
      });
      return () => {
        p?.dispose();
      };
    }
    return () => {
    };
  }, [s, T]);
  function pe() {
    I.current?.dispose(), V ? y && _.set(m, o.current.saveViewState()) : o.current.getModel()?.dispose(), o.current.dispose();
  }
  return react_default.createElement(H, { width: z, height: F, isEditorReady: s, loading: N, _ref: b, className: j, wrapperProps: A });
}
var fe = Ve;
var de = memo(fe);

// src/ui/CodeEditor.tsx
function CodeEditor({
  content,
  language,
  onChange,
  onSave,
  theme
}) {
  const handleKeyDown = useCallback(
    (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        onSave();
      }
    },
    [onSave]
  );
  return /* @__PURE__ */ jsx("div", { className: "h-full", onKeyDown: handleKeyDown, children: /* @__PURE__ */ jsx(
    de,
    {
      height: "100%",
      language,
      value: content,
      theme,
      onChange: (val) => onChange(val ?? ""),
      options: {
        minimap: { enabled: true },
        fontSize: 13,
        lineNumbers: "on",
        wordWrap: "on",
        scrollBeyondLastLine: false,
        automaticLayout: true,
        tabSize: 2
      }
    }
  ) });
}

// src/ui/EditorArea.tsx
function EditorArea({
  tabs,
  activeTabIndex,
  activeTab,
  theme,
  onSelectTab,
  onCloseTab,
  onContentChange,
  onSave,
  onToggleTheme
}) {
  if (tabs.length === 0) {
    return /* @__PURE__ */ jsxs("div", { className: "flex-1 flex flex-col items-center justify-center text-muted-foreground gap-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-6xl", children: "\u{1F4DD}" }),
      /* @__PURE__ */ jsx("div", { className: "text-lg font-medium", children: "No file open" }),
      /* @__PURE__ */ jsx("div", { className: "text-sm", children: "Select a file from the explorer to start editing" }),
      /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground/60 mt-4 space-y-1 text-center", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          "Ctrl+S ",
          "\u2014",
          " Save file"
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          "Right-click ",
          "\u2014",
          " Context menu"
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          "Drag & drop ",
          "\u2014",
          " Move files"
        ] })
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxs(Fragment2, { children: [
    /* @__PURE__ */ jsx(
      TabBar,
      {
        tabs,
        activeIndex: activeTabIndex,
        onSelect: onSelectTab,
        onClose: onCloseTab
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-3 py-1 border-b bg-muted/20", children: [
      /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground truncate", children: activeTab?.path }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: activeTab?.language }),
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "text-xs px-2 py-0.5 rounded hover:bg-accent text-muted-foreground hover:text-foreground",
            onClick: onToggleTheme,
            children: theme === "vs-dark" ? "\u2600\uFE0F" : "\u{1F319}"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "text-xs px-2 py-0.5 rounded bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50",
            onClick: onSave,
            disabled: !activeTab?.modified,
            children: "Save"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-hidden", children: activeTab && /* @__PURE__ */ jsx(
      CodeEditor,
      {
        content: activeTab.content,
        language: activeTab.language,
        onChange: onContentChange,
        onSave,
        theme
      }
    ) })
  ] });
}

// src/ui/editor-panel.tsx
function updateNodeInTree(nodes, path, updater) {
  return nodes.map((node) => {
    if (node.path === path) return updater(node);
    if (node.children) {
      return { ...node, children: updateNodeInTree(node.children, path, updater) };
    }
    return node;
  });
}
function removeNodeFromTree(nodes, targetPath) {
  return nodes.filter((n) => n.path !== targetPath).map((n) => ({
    ...n,
    children: n.children ? removeNodeFromTree(n.children, targetPath) : void 0
  }));
}
function getNodeDepth(path) {
  return path ? path.split("/").length : 0;
}
function createResizeListeners(startX, startWidth, resizingRef, setWidth) {
  const move = (moveEvent) => {
    if (!resizingRef.current) return;
    const diff = moveEvent.clientX - startX;
    setWidth(Math.max(180, Math.min(500, startWidth + diff)));
  };
  const up = () => {
    resizingRef.current = false;
    document.removeEventListener("mousemove", move);
    document.removeEventListener("mouseup", up);
  };
  return { move, up };
}
function useResizeHandle(initialWidth) {
  const [width, setWidth] = useState(initialWidth);
  const resizingRef = useRef(false);
  const onMouseDown = useCallback(
    (e) => {
      e.preventDefault();
      resizingRef.current = true;
      const { move, up } = createResizeListeners(e.clientX, width, resizingRef, setWidth);
      document.addEventListener("mousemove", move);
      document.addEventListener("mouseup", up);
    },
    [width]
  );
  return { width, onMouseDown };
}
function useFileTree(sdk, extName) {
  const [treeNodes, setTreeNodes] = useState([]);
  const [loading, setLoading] = useState(true);
  const loadDirectory = useCallback(
    async (path) => {
      if (!sdk) return [];
      try {
        const result = await sdk.exec.run(`${extName}:tree`, { path });
        const entries = JSON.parse(result.output);
        return entries.map((e) => ({
          ...e,
          loaded: e.type === "file",
          expanded: false,
          children: e.type === "directory" ? [] : void 0
        }));
      } catch {
        return [];
      }
    },
    [sdk, extName]
  );
  const refreshDirectory = useCallback(
    async (parentPath) => {
      const nodes = await loadDirectory(parentPath);
      if (!parentPath) {
        setTreeNodes(nodes);
      } else {
        setTreeNodes(
          (prev) => updateNodeInTree(prev, parentPath, (n) => ({ ...n, children: nodes, loaded: true }))
        );
      }
    },
    [loadDirectory]
  );
  useEffect(() => {
    void loadDirectory("").then((nodes) => {
      setTreeNodes(nodes);
      setLoading(false);
    });
  }, [loadDirectory]);
  const handleToggle = useCallback(
    async (node) => {
      if (node.expanded) {
        setTreeNodes(
          (prev) => updateNodeInTree(prev, node.path, (n) => ({ ...n, expanded: false }))
        );
        return;
      }
      if (!node.loaded) {
        const children = await loadDirectory(node.path);
        setTreeNodes(
          (prev) => updateNodeInTree(prev, node.path, (n) => ({
            ...n,
            expanded: true,
            loaded: true,
            children
          }))
        );
      } else {
        setTreeNodes(
          (prev) => updateNodeInTree(prev, node.path, (n) => ({ ...n, expanded: true }))
        );
      }
    },
    [loadDirectory]
  );
  return { treeNodes, setTreeNodes, loading, loadDirectory, refreshDirectory, handleToggle };
}
function useTabs(sdk, extName) {
  const [tabs, setTabs] = useState([]);
  const [activeTabIndex, setActiveTabIndex] = useState(-1);
  const activeTab = activeTabIndex >= 0 && activeTabIndex < tabs.length ? tabs[activeTabIndex] ?? null : null;
  const handleSelect = useCallback(
    async (node) => {
      const existingIndex = tabs.findIndex((t) => t.path === node.path);
      if (existingIndex >= 0) {
        setActiveTabIndex(existingIndex);
        return;
      }
      if (!sdk) return;
      try {
        const result = await sdk.exec.run(`${extName}:read`, { path: node.path });
        const data = JSON.parse(result.output);
        if (data.error) {
          sdk.ui.toast({ title: "Error", description: data.error, variant: "destructive" });
          return;
        }
        setTabs((prev) => [
          ...prev,
          {
            path: node.path,
            name: node.name,
            content: data.content,
            originalContent: data.content,
            language: data.language,
            modified: false
          }
        ]);
        setActiveTabIndex(tabs.length);
      } catch {
        sdk.ui.toast({
          title: "Error",
          description: "Failed to open file",
          variant: "destructive"
        });
      }
    },
    [sdk, extName, tabs]
  );
  const handleSave = useCallback(async () => {
    if (!activeTab || !sdk || !activeTab.modified) return;
    try {
      await sdk.exec.run(`${extName}:write`, {
        path: activeTab.path,
        content: activeTab.content
      });
      setTabs(
        (prev) => prev.map(
          (t, i) => i === activeTabIndex ? { ...t, modified: false, originalContent: t.content } : t
        )
      );
      sdk.ui.toast({ title: "Saved", description: activeTab.name });
    } catch {
      sdk.ui.toast({ title: "Error", description: "Failed to save", variant: "destructive" });
    }
  }, [activeTab, activeTabIndex, sdk, extName]);
  const handleTabClose = useCallback(
    (index2) => {
      const tab = tabs[index2];
      if (tab?.modified) {
        sdk?.ui.toast({
          title: "Unsaved changes",
          description: `${tab.name} has unsaved changes`
        });
      }
      setTabs((prev) => prev.filter((_2, i) => i !== index2));
      if (activeTabIndex >= index2 && activeTabIndex > 0) {
        setActiveTabIndex((prev) => prev - 1);
      } else if (tabs.length <= 1) {
        setActiveTabIndex(-1);
      }
    },
    [tabs, activeTabIndex, sdk]
  );
  const handleContentChange = useCallback(
    (value) => {
      setTabs(
        (prev) => prev.map(
          (t, i) => i === activeTabIndex ? { ...t, content: value, modified: value !== t.originalContent } : t
        )
      );
    },
    [activeTabIndex]
  );
  return {
    tabs,
    setTabs,
    activeTabIndex,
    setActiveTabIndex,
    activeTab,
    handleSelect,
    handleSave,
    handleTabClose,
    handleContentChange
  };
}
function useContextMenuActions(deps) {
  const { sdk, extName, tabs, handleTabClose, refreshDirectory, setTreeNodes, setTabs } = deps;
  const [contextMenu, setContextMenu] = useState(null);
  const [inlineInput, setInlineInput] = useState(null);
  const handleContextMenu = useCallback((e, node) => {
    e.preventDefault();
    const parentPath = node.type === "directory" ? node.path : node.path.split("/").slice(0, -1).join("/");
    setContextMenu({ x: e.clientX, y: e.clientY, node, parentPath });
  }, []);
  const handleTreeContextMenu = useCallback((e) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY, node: null, parentPath: "" });
  }, []);
  const handleNewFile = useCallback(() => {
    const parentPath = contextMenu?.parentPath ?? "";
    setInlineInput({ type: "new-file", parentPath, depth: getNodeDepth(parentPath) + 1 });
  }, [contextMenu]);
  const handleNewFolder = useCallback(() => {
    const parentPath = contextMenu?.parentPath ?? "";
    setInlineInput({ type: "new-folder", parentPath, depth: getNodeDepth(parentPath) + 1 });
  }, [contextMenu]);
  const handleRename = useCallback(() => {
    if (!contextMenu?.node) return;
    const node = contextMenu.node;
    setInlineInput({
      type: "rename",
      parentPath: node.path.split("/").slice(0, -1).join("/"),
      depth: getNodeDepth(node.path),
      originalPath: node.path,
      originalName: node.name
    });
  }, [contextMenu]);
  const handleDelete = useCallback(async () => {
    if (!contextMenu?.node || !sdk) return;
    const node = contextMenu.node;
    try {
      await sdk.exec.run(`${extName}:delete`, { path: node.path });
      setTreeNodes((prev) => removeNodeFromTree(prev, node.path));
      const tabIdx = tabs.findIndex((t) => t.path === node.path);
      if (tabIdx >= 0) handleTabClose(tabIdx);
      sdk.ui.toast({ title: "Deleted", description: node.name });
    } catch {
      sdk.ui.toast({ title: "Error", description: "Failed to delete", variant: "destructive" });
    }
  }, [contextMenu, sdk, extName, tabs, handleTabClose, setTreeNodes]);
  const handleInlineSubmit = useCallback(
    async (value) => {
      if (!sdk || !inlineInput) return;
      const { type, parentPath, originalPath } = inlineInput;
      const newPath = parentPath ? `${parentPath}/${value}` : value;
      try {
        if (type === "rename" && originalPath) {
          const oldParent = originalPath.split("/").slice(0, -1).join("/");
          const targetPath = oldParent ? `${oldParent}/${value}` : value;
          await sdk.exec.run(`${extName}:rename`, { oldPath: originalPath, newPath: targetPath });
          setTabs(
            (prev) => prev.map(
              (t) => t.path === originalPath ? { ...t, path: targetPath, name: value } : t
            )
          );
        } else {
          const fileType = type === "new-file" ? "file" : "directory";
          await sdk.exec.run(`${extName}:create`, { path: newPath, type: fileType });
        }
        await refreshDirectory(parentPath);
      } catch {
        sdk.ui.toast({
          title: "Error",
          description: `Failed to ${type}`,
          variant: "destructive"
        });
      }
      setInlineInput(null);
    },
    [sdk, extName, inlineInput, refreshDirectory, setTabs]
  );
  return {
    contextMenu,
    setContextMenu,
    inlineInput,
    setInlineInput,
    handleContextMenu,
    handleTreeContextMenu,
    handleNewFile,
    handleNewFolder,
    handleRename,
    handleDelete,
    handleInlineSubmit
  };
}
function useDragAndDrop(deps) {
  const { sdk, extName, refreshDirectory, setTabs } = deps;
  const [rootDragOver, setRootDragOver] = useState(false);
  const handleDrop = useCallback(
    async (sourcePath, targetDirPath) => {
      if (!sdk) return;
      const fileName = sourcePath.split("/").pop() ?? "";
      const newPath = targetDirPath ? `${targetDirPath}/${fileName}` : fileName;
      try {
        await sdk.exec.run(`${extName}:rename`, { oldPath: sourcePath, newPath });
        setTabs(
          (prev) => prev.map((t) => t.path === sourcePath ? { ...t, path: newPath } : t)
        );
        const sourceParent = sourcePath.split("/").slice(0, -1).join("/");
        await refreshDirectory(sourceParent);
        await refreshDirectory(targetDirPath);
        sdk.ui.toast({
          title: "Moved",
          description: `${fileName} \u2192 ${targetDirPath || "/"}`
        });
      } catch {
        sdk.ui.toast({ title: "Error", description: "Failed to move", variant: "destructive" });
      }
    },
    [sdk, extName, refreshDirectory, setTabs]
  );
  const handleRootDragOver = useCallback((e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setRootDragOver(true);
  }, []);
  const handleRootDrop = useCallback(
    (e) => {
      e.preventDefault();
      setRootDragOver(false);
      const sourcePath = e.dataTransfer.getData("text/plain");
      if (sourcePath) {
        void handleDrop(sourcePath, "");
      }
    },
    [handleDrop]
  );
  return { rootDragOver, setRootDragOver, handleDrop, handleRootDragOver, handleRootDrop };
}
function useThemeDetection() {
  const [theme, setTheme] = useState("vs-dark");
  const detectedTheme = useMemo(
    () => typeof document === "undefined" || document.documentElement.classList.contains("dark") ? "vs-dark" : "vs-light",
    []
  );
  useEffect(() => {
    setTheme(detectedTheme);
  }, [detectedTheme]);
  return { theme, setTheme };
}
function useKeyboardShortcuts(handleSave) {
  useEffect(() => {
    const onKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        void handleSave();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [handleSave]);
}
function EditorPanel({ sdk, extensionName }) {
  const extName = extensionName ?? "file-editor";
  const { width: sidebarWidth, onMouseDown: handleResizeMouseDown } = useResizeHandle(260);
  const fileTree = useFileTree(sdk, extName);
  const tabState = useTabs(sdk, extName);
  const { theme, setTheme } = useThemeDetection();
  const ctxMenu = useContextMenuActions({
    sdk,
    extName,
    tabs: tabState.tabs,
    handleTabClose: tabState.handleTabClose,
    refreshDirectory: fileTree.refreshDirectory,
    setTreeNodes: fileTree.setTreeNodes,
    setTabs: tabState.setTabs
  });
  const dragDrop = useDragAndDrop({
    sdk,
    extName,
    refreshDirectory: fileTree.refreshDirectory,
    setTabs: tabState.setTabs
  });
  useKeyboardShortcuts(tabState.handleSave);
  if (fileTree.loading) {
    return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-96 text-muted-foreground", children: "Loading file tree..." });
  }
  return /* @__PURE__ */ jsxs("div", { className: "flex h-[calc(100vh-200px)] border rounded-lg overflow-hidden bg-background", children: [
    /* @__PURE__ */ jsx(
      Sidebar,
      {
        treeNodes: fileTree.treeNodes,
        sidebarWidth,
        rootDragOver: dragDrop.rootDragOver,
        activeFilePath: tabState.activeTab?.path ?? null,
        inlineInput: ctxMenu.inlineInput,
        onToggle: fileTree.handleToggle,
        onSelect: tabState.handleSelect,
        onContextMenu: ctxMenu.handleContextMenu,
        onDrop: dragDrop.handleDrop,
        onTreeContextMenu: ctxMenu.handleTreeContextMenu,
        onRootDragOver: dragDrop.handleRootDragOver,
        onRootDragLeave: () => dragDrop.setRootDragOver(false),
        onRootDrop: dragDrop.handleRootDrop,
        onNewFile: () => ctxMenu.setInlineInput({ type: "new-file", parentPath: "", depth: 0 }),
        onNewFolder: () => ctxMenu.setInlineInput({ type: "new-folder", parentPath: "", depth: 0 }),
        onRefresh: () => {
          void fileTree.refreshDirectory("");
        },
        onInlineSubmit: ctxMenu.handleInlineSubmit,
        onInlineCancel: () => ctxMenu.setInlineInput(null)
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: "w-1 cursor-col-resize hover:bg-primary/30 active:bg-primary/50 flex-shrink-0",
        onMouseDown: handleResizeMouseDown
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "flex-1 flex flex-col overflow-hidden", children: /* @__PURE__ */ jsx(
      EditorArea,
      {
        tabs: tabState.tabs,
        activeTabIndex: tabState.activeTabIndex,
        activeTab: tabState.activeTab,
        theme,
        onSelectTab: tabState.setActiveTabIndex,
        onCloseTab: tabState.handleTabClose,
        onContentChange: tabState.handleContentChange,
        onSave: tabState.handleSave,
        onToggleTheme: () => setTheme((t) => t === "vs-dark" ? "vs-light" : "vs-dark")
      }
    ) }),
    ctxMenu.contextMenu && /* @__PURE__ */ jsx(
      ContextMenu,
      {
        state: ctxMenu.contextMenu,
        onClose: () => ctxMenu.setContextMenu(null),
        onNewFile: ctxMenu.handleNewFile,
        onNewFolder: ctxMenu.handleNewFolder,
        onRename: ctxMenu.handleRename,
        onDelete: ctxMenu.handleDelete
      }
    ),
    ctxMenu.inlineInput?.originalPath && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-40", onClick: () => ctxMenu.setInlineInput(null), children: /* @__PURE__ */ jsx(
      "div",
      {
        className: "absolute",
        style: { left: sidebarWidth * 0.3, top: "50%" },
        onClick: (e) => e.stopPropagation(),
        children: /* @__PURE__ */ jsx(
          InlineInput,
          {
            defaultValue: ctxMenu.inlineInput.originalName ?? "",
            depth: 0,
            onSubmit: ctxMenu.handleInlineSubmit,
            onCancel: () => ctxMenu.setInlineInput(null)
          }
        )
      }
    ) })
  ] });
}
export {
  EditorPanel as default
};
