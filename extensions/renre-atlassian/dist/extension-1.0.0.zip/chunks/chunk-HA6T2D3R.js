import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// src/shared/adf.ts
function buildAdfBody(text) {
  return {
    type: "doc",
    version: 1,
    content: [
      {
        type: "paragraph",
        content: [{ type: "text", text }]
      }
    ]
  };
}

export {
  buildAdfBody
};
