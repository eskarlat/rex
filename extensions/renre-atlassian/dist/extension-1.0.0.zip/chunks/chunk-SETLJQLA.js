import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  createClients,
  errorOutput,
  toOutput
} from "./chunk-5QSCZNEA.js";

// src/shared/command-helper.ts
async function jiraCommand(context, fn) {
  try {
    const { jira } = createClients(context);
    const data = await fn(jira, context.args);
    return toOutput(data);
  } catch (err) {
    return errorOutput(err);
  }
}
async function confluenceCommand(context, fn) {
  try {
    const { confluence } = createClients(context);
    const data = await fn(confluence, context.args);
    return toOutput(data);
  } catch (err) {
    return errorOutput(err);
  }
}

export {
  jiraCommand,
  confluenceCommand
};
