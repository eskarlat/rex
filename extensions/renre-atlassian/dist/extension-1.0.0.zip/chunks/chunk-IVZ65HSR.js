import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  __commonJS,
  __require,
  __toESM
} from "./chunk-77GVX2VY.js";

// ../../node_modules/.pnpm/buffer-crc32@1.0.0/node_modules/buffer-crc32/dist/index.cjs
var require_dist = __commonJS({
  "../../node_modules/.pnpm/buffer-crc32@1.0.0/node_modules/buffer-crc32/dist/index.cjs"(exports, module) {
    "use strict";
    function getDefaultExportFromCjs(x) {
      return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
    }
    var CRC_TABLE = new Int32Array([
      0,
      1996959894,
      3993919788,
      2567524794,
      124634137,
      1886057615,
      3915621685,
      2657392035,
      249268274,
      2044508324,
      3772115230,
      2547177864,
      162941995,
      2125561021,
      3887607047,
      2428444049,
      498536548,
      1789927666,
      4089016648,
      2227061214,
      450548861,
      1843258603,
      4107580753,
      2211677639,
      325883990,
      1684777152,
      4251122042,
      2321926636,
      335633487,
      1661365465,
      4195302755,
      2366115317,
      997073096,
      1281953886,
      3579855332,
      2724688242,
      1006888145,
      1258607687,
      3524101629,
      2768942443,
      901097722,
      1119000684,
      3686517206,
      2898065728,
      853044451,
      1172266101,
      3705015759,
      2882616665,
      651767980,
      1373503546,
      3369554304,
      3218104598,
      565507253,
      1454621731,
      3485111705,
      3099436303,
      671266974,
      1594198024,
      3322730930,
      2970347812,
      795835527,
      1483230225,
      3244367275,
      3060149565,
      1994146192,
      31158534,
      2563907772,
      4023717930,
      1907459465,
      112637215,
      2680153253,
      3904427059,
      2013776290,
      251722036,
      2517215374,
      3775830040,
      2137656763,
      141376813,
      2439277719,
      3865271297,
      1802195444,
      476864866,
      2238001368,
      4066508878,
      1812370925,
      453092731,
      2181625025,
      4111451223,
      1706088902,
      314042704,
      2344532202,
      4240017532,
      1658658271,
      366619977,
      2362670323,
      4224994405,
      1303535960,
      984961486,
      2747007092,
      3569037538,
      1256170817,
      1037604311,
      2765210733,
      3554079995,
      1131014506,
      879679996,
      2909243462,
      3663771856,
      1141124467,
      855842277,
      2852801631,
      3708648649,
      1342533948,
      654459306,
      3188396048,
      3373015174,
      1466479909,
      544179635,
      3110523913,
      3462522015,
      1591671054,
      702138776,
      2966460450,
      3352799412,
      1504918807,
      783551873,
      3082640443,
      3233442989,
      3988292384,
      2596254646,
      62317068,
      1957810842,
      3939845945,
      2647816111,
      81470997,
      1943803523,
      3814918930,
      2489596804,
      225274430,
      2053790376,
      3826175755,
      2466906013,
      167816743,
      2097651377,
      4027552580,
      2265490386,
      503444072,
      1762050814,
      4150417245,
      2154129355,
      426522225,
      1852507879,
      4275313526,
      2312317920,
      282753626,
      1742555852,
      4189708143,
      2394877945,
      397917763,
      1622183637,
      3604390888,
      2714866558,
      953729732,
      1340076626,
      3518719985,
      2797360999,
      1068828381,
      1219638859,
      3624741850,
      2936675148,
      906185462,
      1090812512,
      3747672003,
      2825379669,
      829329135,
      1181335161,
      3412177804,
      3160834842,
      628085408,
      1382605366,
      3423369109,
      3138078467,
      570562233,
      1426400815,
      3317316542,
      2998733608,
      733239954,
      1555261956,
      3268935591,
      3050360625,
      752459403,
      1541320221,
      2607071920,
      3965973030,
      1969922972,
      40735498,
      2617837225,
      3943577151,
      1913087877,
      83908371,
      2512341634,
      3803740692,
      2075208622,
      213261112,
      2463272603,
      3855990285,
      2094854071,
      198958881,
      2262029012,
      4057260610,
      1759359992,
      534414190,
      2176718541,
      4139329115,
      1873836001,
      414664567,
      2282248934,
      4279200368,
      1711684554,
      285281116,
      2405801727,
      4167216745,
      1634467795,
      376229701,
      2685067896,
      3608007406,
      1308918612,
      956543938,
      2808555105,
      3495958263,
      1231636301,
      1047427035,
      2932959818,
      3654703836,
      1088359270,
      936918e3,
      2847714899,
      3736837829,
      1202900863,
      817233897,
      3183342108,
      3401237130,
      1404277552,
      615818150,
      3134207493,
      3453421203,
      1423857449,
      601450431,
      3009837614,
      3294710456,
      1567103746,
      711928724,
      3020668471,
      3272380065,
      1510334235,
      755167117
    ]);
    function ensureBuffer(input) {
      if (Buffer.isBuffer(input)) {
        return input;
      }
      if (typeof input === "number") {
        return Buffer.alloc(input);
      } else if (typeof input === "string") {
        return Buffer.from(input);
      } else {
        throw new Error("input must be buffer, number, or string, received " + typeof input);
      }
    }
    function bufferizeInt(num) {
      const tmp = ensureBuffer(4);
      tmp.writeInt32BE(num, 0);
      return tmp;
    }
    function _crc32(buf, previous) {
      buf = ensureBuffer(buf);
      if (Buffer.isBuffer(previous)) {
        previous = previous.readUInt32BE(0);
      }
      let crc = ~~previous ^ -1;
      for (var n = 0; n < buf.length; n++) {
        crc = CRC_TABLE[(crc ^ buf[n]) & 255] ^ crc >>> 8;
      }
      return crc ^ -1;
    }
    function crc32() {
      return bufferizeInt(_crc32.apply(null, arguments));
    }
    crc32.signed = function() {
      return _crc32.apply(null, arguments);
    };
    crc32.unsigned = function() {
      return _crc32.apply(null, arguments) >>> 0;
    };
    var bufferCrc32 = crc32;
    var index = /* @__PURE__ */ getDefaultExportFromCjs(bufferCrc32);
    module.exports = index;
  }
});

// ../../node_modules/.pnpm/yazl@3.3.1/node_modules/yazl/index.js
var require_yazl = __commonJS({
  "../../node_modules/.pnpm/yazl@3.3.1/node_modules/yazl/index.js"(exports) {
    var fs = __require("fs");
    var Transform = __require("stream").Transform;
    var PassThrough = __require("stream").PassThrough;
    var zlib = __require("zlib");
    var util = __require("util");
    var EventEmitter = __require("events").EventEmitter;
    var errorMonitor = __require("events").errorMonitor;
    var crc32 = require_dist();
    exports.ZipFile = ZipFile;
    exports.dateToDosDateTime = dateToDosDateTime;
    util.inherits(ZipFile, EventEmitter);
    function ZipFile() {
      this.outputStream = new PassThrough();
      this.entries = [];
      this.outputStreamCursor = 0;
      this.ended = false;
      this.allDone = false;
      this.forceZip64Eocd = false;
      this.errored = false;
      this.on(errorMonitor, function() {
        this.errored = true;
      });
    }
    ZipFile.prototype.addFile = function(realPath, metadataPath, options) {
      var self = this;
      metadataPath = validateMetadataPath(metadataPath, false);
      if (options == null) options = {};
      if (shouldIgnoreAdding(self)) return;
      var entry = new Entry(metadataPath, false, options);
      self.entries.push(entry);
      fs.stat(realPath, function(err, stats) {
        if (err) return self.emit("error", err);
        if (!stats.isFile()) return self.emit("error", new Error("not a file: " + realPath));
        entry.uncompressedSize = stats.size;
        if (options.mtime == null) entry.setLastModDate(stats.mtime);
        if (options.mode == null) entry.setFileAttributesMode(stats.mode);
        entry.setFileDataPumpFunction(function() {
          var readStream = fs.createReadStream(realPath);
          entry.state = Entry.FILE_DATA_IN_PROGRESS;
          readStream.on("error", function(err2) {
            self.emit("error", err2);
          });
          pumpFileDataReadStream(self, entry, readStream);
        });
        pumpEntries(self);
      });
    };
    ZipFile.prototype.addReadStream = function(readStream, metadataPath, options) {
      this.addReadStreamLazy(metadataPath, options, function(cb) {
        cb(null, readStream);
      });
    };
    ZipFile.prototype.addReadStreamLazy = function(metadataPath, options, getReadStreamFunction) {
      var self = this;
      if (typeof options === "function") {
        getReadStreamFunction = options;
        options = null;
      }
      if (options == null) options = {};
      metadataPath = validateMetadataPath(metadataPath, false);
      if (shouldIgnoreAdding(self)) return;
      var entry = new Entry(metadataPath, false, options);
      self.entries.push(entry);
      entry.setFileDataPumpFunction(function() {
        entry.state = Entry.FILE_DATA_IN_PROGRESS;
        getReadStreamFunction(function(err, readStream) {
          if (err) return self.emit("error", err);
          pumpFileDataReadStream(self, entry, readStream);
        });
      });
      pumpEntries(self);
    };
    ZipFile.prototype.addBuffer = function(buffer, metadataPath, options) {
      var self = this;
      metadataPath = validateMetadataPath(metadataPath, false);
      if (buffer.length > 1073741823) throw new Error("buffer too large: " + buffer.length + " > 1073741823");
      if (options == null) options = {};
      if (options.size != null) throw new Error("options.size not allowed");
      if (shouldIgnoreAdding(self)) return;
      var entry = new Entry(metadataPath, false, options);
      entry.uncompressedSize = buffer.length;
      entry.crc32 = crc32.unsigned(buffer);
      entry.crcAndFileSizeKnown = true;
      self.entries.push(entry);
      if (entry.compressionLevel === 0) {
        setCompressedBuffer(buffer);
      } else {
        zlib.deflateRaw(buffer, { level: entry.compressionLevel }, function(err, compressedBuffer) {
          setCompressedBuffer(compressedBuffer);
        });
      }
      function setCompressedBuffer(compressedBuffer) {
        entry.compressedSize = compressedBuffer.length;
        entry.setFileDataPumpFunction(function() {
          writeToOutputStream(self, compressedBuffer);
          writeToOutputStream(self, entry.getDataDescriptor());
          entry.state = Entry.FILE_DATA_DONE;
          setImmediate(function() {
            pumpEntries(self);
          });
        });
        pumpEntries(self);
      }
    };
    ZipFile.prototype.addEmptyDirectory = function(metadataPath, options) {
      var self = this;
      metadataPath = validateMetadataPath(metadataPath, true);
      if (options == null) options = {};
      if (options.size != null) throw new Error("options.size not allowed");
      if (options.compress != null) throw new Error("options.compress not allowed");
      if (options.compressionLevel != null) throw new Error("options.compressionLevel not allowed");
      if (shouldIgnoreAdding(self)) return;
      var entry = new Entry(metadataPath, true, options);
      self.entries.push(entry);
      entry.setFileDataPumpFunction(function() {
        writeToOutputStream(self, entry.getDataDescriptor());
        entry.state = Entry.FILE_DATA_DONE;
        pumpEntries(self);
      });
      pumpEntries(self);
    };
    var eocdrSignatureBuffer = bufferFrom([80, 75, 5, 6]);
    ZipFile.prototype.end = function(options, calculatedTotalSizeCallback) {
      if (typeof options === "function") {
        calculatedTotalSizeCallback = options;
        options = null;
      }
      if (options == null) options = {};
      if (this.ended) return;
      this.ended = true;
      if (this.errored) return;
      this.calculatedTotalSizeCallback = calculatedTotalSizeCallback;
      this.forceZip64Eocd = !!options.forceZip64Format;
      if (options.comment) {
        if (typeof options.comment === "string") {
          this.comment = encodeCp437(options.comment);
        } else {
          this.comment = options.comment;
        }
        if (this.comment.length > 65535) throw new Error("comment is too large");
        if (bufferIncludes(this.comment, eocdrSignatureBuffer)) throw new Error("comment contains end of central directory record signature");
      } else {
        this.comment = EMPTY_BUFFER;
      }
      pumpEntries(this);
    };
    function writeToOutputStream(self, buffer) {
      self.outputStream.write(buffer);
      self.outputStreamCursor += buffer.length;
    }
    function pumpFileDataReadStream(self, entry, readStream) {
      var crc32Watcher = new Crc32Watcher();
      var uncompressedSizeCounter = new ByteCounter();
      var compressor = entry.compressionLevel !== 0 ? new zlib.DeflateRaw({ level: entry.compressionLevel }) : new PassThrough();
      var compressedSizeCounter = new ByteCounter();
      readStream.pipe(crc32Watcher).pipe(uncompressedSizeCounter).pipe(compressor).pipe(compressedSizeCounter).pipe(self.outputStream, { end: false });
      compressedSizeCounter.on("end", function() {
        entry.crc32 = crc32Watcher.crc32;
        if (entry.uncompressedSize == null) {
          entry.uncompressedSize = uncompressedSizeCounter.byteCount;
        } else {
          if (entry.uncompressedSize !== uncompressedSizeCounter.byteCount) return self.emit("error", new Error("file data stream has unexpected number of bytes"));
        }
        entry.compressedSize = compressedSizeCounter.byteCount;
        self.outputStreamCursor += entry.compressedSize;
        writeToOutputStream(self, entry.getDataDescriptor());
        entry.state = Entry.FILE_DATA_DONE;
        pumpEntries(self);
      });
    }
    function determineCompressionLevel(options) {
      if (options.compress != null && options.compressionLevel != null) {
        if (!!options.compress !== !!options.compressionLevel) throw new Error("conflicting settings for compress and compressionLevel");
      }
      if (options.compressionLevel != null) return options.compressionLevel;
      if (options.compress === false) return 0;
      return 6;
    }
    function pumpEntries(self) {
      if (self.allDone || self.errored) return;
      if (self.ended && self.calculatedTotalSizeCallback != null) {
        var calculatedTotalSize = calculateTotalSize(self);
        if (calculatedTotalSize != null) {
          self.calculatedTotalSizeCallback(calculatedTotalSize);
          self.calculatedTotalSizeCallback = null;
        }
      }
      var entry = getFirstNotDoneEntry();
      function getFirstNotDoneEntry() {
        for (var i = 0; i < self.entries.length; i++) {
          var entry2 = self.entries[i];
          if (entry2.state < Entry.FILE_DATA_DONE) return entry2;
        }
        return null;
      }
      if (entry != null) {
        if (entry.state < Entry.READY_TO_PUMP_FILE_DATA) return;
        if (entry.state === Entry.FILE_DATA_IN_PROGRESS) return;
        entry.relativeOffsetOfLocalHeader = self.outputStreamCursor;
        var localFileHeader = entry.getLocalFileHeader();
        writeToOutputStream(self, localFileHeader);
        entry.doFileDataPump();
      } else {
        if (self.ended) {
          self.offsetOfStartOfCentralDirectory = self.outputStreamCursor;
          self.entries.forEach(function(entry2) {
            var centralDirectoryRecord = entry2.getCentralDirectoryRecord();
            writeToOutputStream(self, centralDirectoryRecord);
          });
          writeToOutputStream(self, getEndOfCentralDirectoryRecord(self));
          self.outputStream.end();
          self.allDone = true;
        }
      }
    }
    function calculateTotalSize(self) {
      var pretendOutputCursor = 0;
      var centralDirectorySize = 0;
      for (var i = 0; i < self.entries.length; i++) {
        var entry = self.entries[i];
        if (entry.compressionLevel !== 0) return -1;
        if (entry.state >= Entry.READY_TO_PUMP_FILE_DATA) {
          if (entry.uncompressedSize == null) return -1;
        } else {
          if (entry.uncompressedSize == null) return null;
        }
        entry.relativeOffsetOfLocalHeader = pretendOutputCursor;
        var useZip64Format = entry.useZip64Format();
        pretendOutputCursor += LOCAL_FILE_HEADER_FIXED_SIZE + entry.utf8FileName.length;
        pretendOutputCursor += entry.uncompressedSize;
        if (!entry.crcAndFileSizeKnown) {
          if (useZip64Format) {
            pretendOutputCursor += ZIP64_DATA_DESCRIPTOR_SIZE;
          } else {
            pretendOutputCursor += DATA_DESCRIPTOR_SIZE;
          }
        }
        centralDirectorySize += CENTRAL_DIRECTORY_RECORD_FIXED_SIZE + entry.utf8FileName.length + entry.fileComment.length;
        if (!entry.forceDosTimestamp) {
          centralDirectorySize += INFO_ZIP_UNIVERSAL_TIMESTAMP_EXTRA_FIELD_SIZE;
        }
        if (useZip64Format) {
          centralDirectorySize += ZIP64_EXTENDED_INFORMATION_EXTRA_FIELD_SIZE;
        }
      }
      var endOfCentralDirectorySize = 0;
      if (self.forceZip64Eocd || self.entries.length >= 65535 || centralDirectorySize >= 65535 || pretendOutputCursor >= 4294967295) {
        endOfCentralDirectorySize += ZIP64_END_OF_CENTRAL_DIRECTORY_RECORD_SIZE + ZIP64_END_OF_CENTRAL_DIRECTORY_LOCATOR_SIZE;
      }
      endOfCentralDirectorySize += END_OF_CENTRAL_DIRECTORY_RECORD_SIZE + self.comment.length;
      return pretendOutputCursor + centralDirectorySize + endOfCentralDirectorySize;
    }
    function shouldIgnoreAdding(self) {
      if (self.ended) throw new Error("cannot add entries after calling end()");
      if (self.errored) return true;
      return false;
    }
    var ZIP64_END_OF_CENTRAL_DIRECTORY_RECORD_SIZE = 56;
    var ZIP64_END_OF_CENTRAL_DIRECTORY_LOCATOR_SIZE = 20;
    var END_OF_CENTRAL_DIRECTORY_RECORD_SIZE = 22;
    function getEndOfCentralDirectoryRecord(self, actuallyJustTellMeHowLongItWouldBe) {
      var needZip64Format = false;
      var normalEntriesLength = self.entries.length;
      if (self.forceZip64Eocd || self.entries.length >= 65535) {
        normalEntriesLength = 65535;
        needZip64Format = true;
      }
      var sizeOfCentralDirectory = self.outputStreamCursor - self.offsetOfStartOfCentralDirectory;
      var normalSizeOfCentralDirectory = sizeOfCentralDirectory;
      if (self.forceZip64Eocd || sizeOfCentralDirectory >= 4294967295) {
        normalSizeOfCentralDirectory = 4294967295;
        needZip64Format = true;
      }
      var normalOffsetOfStartOfCentralDirectory = self.offsetOfStartOfCentralDirectory;
      if (self.forceZip64Eocd || self.offsetOfStartOfCentralDirectory >= 4294967295) {
        normalOffsetOfStartOfCentralDirectory = 4294967295;
        needZip64Format = true;
      }
      if (actuallyJustTellMeHowLongItWouldBe) {
        if (needZip64Format) {
          return ZIP64_END_OF_CENTRAL_DIRECTORY_RECORD_SIZE + ZIP64_END_OF_CENTRAL_DIRECTORY_LOCATOR_SIZE + END_OF_CENTRAL_DIRECTORY_RECORD_SIZE;
        } else {
          return END_OF_CENTRAL_DIRECTORY_RECORD_SIZE;
        }
      }
      var eocdrBuffer = bufferAlloc(END_OF_CENTRAL_DIRECTORY_RECORD_SIZE + self.comment.length);
      eocdrBuffer.writeUInt32LE(101010256, 0);
      eocdrBuffer.writeUInt16LE(0, 4);
      eocdrBuffer.writeUInt16LE(0, 6);
      eocdrBuffer.writeUInt16LE(normalEntriesLength, 8);
      eocdrBuffer.writeUInt16LE(normalEntriesLength, 10);
      eocdrBuffer.writeUInt32LE(normalSizeOfCentralDirectory, 12);
      eocdrBuffer.writeUInt32LE(normalOffsetOfStartOfCentralDirectory, 16);
      eocdrBuffer.writeUInt16LE(self.comment.length, 20);
      self.comment.copy(eocdrBuffer, 22);
      if (!needZip64Format) return eocdrBuffer;
      var zip64EocdrBuffer = bufferAlloc(ZIP64_END_OF_CENTRAL_DIRECTORY_RECORD_SIZE);
      zip64EocdrBuffer.writeUInt32LE(101075792, 0);
      writeUInt64LE(zip64EocdrBuffer, ZIP64_END_OF_CENTRAL_DIRECTORY_RECORD_SIZE - 12, 4);
      zip64EocdrBuffer.writeUInt16LE(VERSION_MADE_BY, 12);
      zip64EocdrBuffer.writeUInt16LE(VERSION_NEEDED_TO_EXTRACT_ZIP64, 14);
      zip64EocdrBuffer.writeUInt32LE(0, 16);
      zip64EocdrBuffer.writeUInt32LE(0, 20);
      writeUInt64LE(zip64EocdrBuffer, self.entries.length, 24);
      writeUInt64LE(zip64EocdrBuffer, self.entries.length, 32);
      writeUInt64LE(zip64EocdrBuffer, sizeOfCentralDirectory, 40);
      writeUInt64LE(zip64EocdrBuffer, self.offsetOfStartOfCentralDirectory, 48);
      var zip64EocdlBuffer = bufferAlloc(ZIP64_END_OF_CENTRAL_DIRECTORY_LOCATOR_SIZE);
      zip64EocdlBuffer.writeUInt32LE(117853008, 0);
      zip64EocdlBuffer.writeUInt32LE(0, 4);
      writeUInt64LE(zip64EocdlBuffer, self.outputStreamCursor, 8);
      zip64EocdlBuffer.writeUInt32LE(1, 16);
      return Buffer.concat([
        zip64EocdrBuffer,
        zip64EocdlBuffer,
        eocdrBuffer
      ]);
    }
    function validateMetadataPath(metadataPath, isDirectory) {
      if (metadataPath === "") throw new Error("empty metadataPath");
      metadataPath = metadataPath.replace(/\\/g, "/");
      if (/^[a-zA-Z]:/.test(metadataPath) || /^\//.test(metadataPath)) throw new Error("absolute path: " + metadataPath);
      if (metadataPath.split("/").indexOf("..") !== -1) throw new Error("invalid relative path: " + metadataPath);
      var looksLikeDirectory = /\/$/.test(metadataPath);
      if (isDirectory) {
        if (!looksLikeDirectory) metadataPath += "/";
      } else {
        if (looksLikeDirectory) throw new Error("file path cannot end with '/': " + metadataPath);
      }
      return metadataPath;
    }
    var EMPTY_BUFFER = bufferAlloc(0);
    function Entry(metadataPath, isDirectory, options) {
      this.utf8FileName = bufferFrom(metadataPath);
      if (this.utf8FileName.length > 65535) throw new Error("utf8 file name too long. " + utf8FileName.length + " > 65535");
      this.isDirectory = isDirectory;
      this.state = Entry.WAITING_FOR_METADATA;
      this.setLastModDate(options.mtime != null ? options.mtime : /* @__PURE__ */ new Date());
      this.forceDosTimestamp = !!options.forceDosTimestamp;
      if (options.mode != null) {
        this.setFileAttributesMode(options.mode);
      } else {
        this.setFileAttributesMode(isDirectory ? 16893 : 33204);
      }
      if (isDirectory) {
        this.crcAndFileSizeKnown = true;
        this.crc32 = 0;
        this.uncompressedSize = 0;
        this.compressedSize = 0;
      } else {
        this.crcAndFileSizeKnown = false;
        this.crc32 = null;
        this.uncompressedSize = null;
        this.compressedSize = null;
        if (options.size != null) this.uncompressedSize = options.size;
      }
      if (isDirectory) {
        this.compressionLevel = 0;
      } else {
        this.compressionLevel = determineCompressionLevel(options);
      }
      this.forceZip64Format = !!options.forceZip64Format;
      if (options.fileComment) {
        if (typeof options.fileComment === "string") {
          this.fileComment = bufferFrom(options.fileComment, "utf-8");
        } else {
          this.fileComment = options.fileComment;
        }
        if (this.fileComment.length > 65535) throw new Error("fileComment is too large");
      } else {
        this.fileComment = EMPTY_BUFFER;
      }
    }
    Entry.WAITING_FOR_METADATA = 0;
    Entry.READY_TO_PUMP_FILE_DATA = 1;
    Entry.FILE_DATA_IN_PROGRESS = 2;
    Entry.FILE_DATA_DONE = 3;
    Entry.prototype.setLastModDate = function(date) {
      this.mtime = date;
      var dosDateTime = dateToDosDateTime(date);
      this.lastModFileTime = dosDateTime.time;
      this.lastModFileDate = dosDateTime.date;
    };
    Entry.prototype.setFileAttributesMode = function(mode) {
      if ((mode & 65535) !== mode) throw new Error("invalid mode. expected: 0 <= " + mode + " <= 65535");
      this.externalFileAttributes = mode << 16 >>> 0;
    };
    Entry.prototype.setFileDataPumpFunction = function(doFileDataPump) {
      this.doFileDataPump = doFileDataPump;
      this.state = Entry.READY_TO_PUMP_FILE_DATA;
    };
    Entry.prototype.useZip64Format = function() {
      return this.forceZip64Format || this.uncompressedSize != null && this.uncompressedSize > 4294967294 || this.compressedSize != null && this.compressedSize > 4294967294 || this.relativeOffsetOfLocalHeader != null && this.relativeOffsetOfLocalHeader > 4294967294;
    };
    var LOCAL_FILE_HEADER_FIXED_SIZE = 30;
    var VERSION_NEEDED_TO_EXTRACT_UTF8 = 20;
    var VERSION_NEEDED_TO_EXTRACT_ZIP64 = 45;
    var VERSION_MADE_BY = 3 << 8 | 63;
    var FILE_NAME_IS_UTF8 = 1 << 11;
    var UNKNOWN_CRC32_AND_FILE_SIZES = 1 << 3;
    Entry.prototype.getLocalFileHeader = function() {
      var crc322 = 0;
      var compressedSize = 0;
      var uncompressedSize = 0;
      if (this.crcAndFileSizeKnown) {
        crc322 = this.crc32;
        compressedSize = this.compressedSize;
        uncompressedSize = this.uncompressedSize;
      }
      var fixedSizeStuff = bufferAlloc(LOCAL_FILE_HEADER_FIXED_SIZE);
      var generalPurposeBitFlag = FILE_NAME_IS_UTF8;
      if (!this.crcAndFileSizeKnown) generalPurposeBitFlag |= UNKNOWN_CRC32_AND_FILE_SIZES;
      fixedSizeStuff.writeUInt32LE(67324752, 0);
      fixedSizeStuff.writeUInt16LE(VERSION_NEEDED_TO_EXTRACT_UTF8, 4);
      fixedSizeStuff.writeUInt16LE(generalPurposeBitFlag, 6);
      fixedSizeStuff.writeUInt16LE(this.getCompressionMethod(), 8);
      fixedSizeStuff.writeUInt16LE(this.lastModFileTime, 10);
      fixedSizeStuff.writeUInt16LE(this.lastModFileDate, 12);
      fixedSizeStuff.writeUInt32LE(crc322, 14);
      fixedSizeStuff.writeUInt32LE(compressedSize, 18);
      fixedSizeStuff.writeUInt32LE(uncompressedSize, 22);
      fixedSizeStuff.writeUInt16LE(this.utf8FileName.length, 26);
      fixedSizeStuff.writeUInt16LE(0, 28);
      return Buffer.concat([
        fixedSizeStuff,
        // file name (variable size)
        this.utf8FileName
        // extra field (variable size)
        // no extra fields
      ]);
    };
    var DATA_DESCRIPTOR_SIZE = 16;
    var ZIP64_DATA_DESCRIPTOR_SIZE = 24;
    Entry.prototype.getDataDescriptor = function() {
      if (this.crcAndFileSizeKnown) {
        return EMPTY_BUFFER;
      }
      if (!this.useZip64Format()) {
        var buffer = bufferAlloc(DATA_DESCRIPTOR_SIZE);
        buffer.writeUInt32LE(134695760, 0);
        buffer.writeUInt32LE(this.crc32, 4);
        buffer.writeUInt32LE(this.compressedSize, 8);
        buffer.writeUInt32LE(this.uncompressedSize, 12);
        return buffer;
      } else {
        var buffer = bufferAlloc(ZIP64_DATA_DESCRIPTOR_SIZE);
        buffer.writeUInt32LE(134695760, 0);
        buffer.writeUInt32LE(this.crc32, 4);
        writeUInt64LE(buffer, this.compressedSize, 8);
        writeUInt64LE(buffer, this.uncompressedSize, 16);
        return buffer;
      }
    };
    var CENTRAL_DIRECTORY_RECORD_FIXED_SIZE = 46;
    var INFO_ZIP_UNIVERSAL_TIMESTAMP_EXTRA_FIELD_SIZE = 9;
    var ZIP64_EXTENDED_INFORMATION_EXTRA_FIELD_SIZE = 28;
    Entry.prototype.getCentralDirectoryRecord = function() {
      var fixedSizeStuff = bufferAlloc(CENTRAL_DIRECTORY_RECORD_FIXED_SIZE);
      var generalPurposeBitFlag = FILE_NAME_IS_UTF8;
      if (!this.crcAndFileSizeKnown) generalPurposeBitFlag |= UNKNOWN_CRC32_AND_FILE_SIZES;
      var izutefBuffer = EMPTY_BUFFER;
      if (!this.forceDosTimestamp) {
        izutefBuffer = bufferAlloc(INFO_ZIP_UNIVERSAL_TIMESTAMP_EXTRA_FIELD_SIZE);
        izutefBuffer.writeUInt16LE(21589, 0);
        izutefBuffer.writeUInt16LE(INFO_ZIP_UNIVERSAL_TIMESTAMP_EXTRA_FIELD_SIZE - 4, 2);
        var EB_UT_FL_MTIME = 1 << 0;
        var EB_UT_FL_ATIME = 1 << 1;
        izutefBuffer.writeUInt8(EB_UT_FL_MTIME | EB_UT_FL_ATIME, 4);
        var timestamp = Math.floor(this.mtime.getTime() / 1e3);
        if (timestamp < -2147483648) timestamp = -2147483648;
        if (timestamp > 2147483647) timestamp = 2147483647;
        izutefBuffer.writeUInt32LE(timestamp, 5);
      }
      var normalCompressedSize = this.compressedSize;
      var normalUncompressedSize = this.uncompressedSize;
      var normalRelativeOffsetOfLocalHeader = this.relativeOffsetOfLocalHeader;
      var versionNeededToExtract = VERSION_NEEDED_TO_EXTRACT_UTF8;
      var zeiefBuffer = EMPTY_BUFFER;
      if (this.useZip64Format()) {
        normalCompressedSize = 4294967295;
        normalUncompressedSize = 4294967295;
        normalRelativeOffsetOfLocalHeader = 4294967295;
        versionNeededToExtract = VERSION_NEEDED_TO_EXTRACT_ZIP64;
        zeiefBuffer = bufferAlloc(ZIP64_EXTENDED_INFORMATION_EXTRA_FIELD_SIZE);
        zeiefBuffer.writeUInt16LE(1, 0);
        zeiefBuffer.writeUInt16LE(ZIP64_EXTENDED_INFORMATION_EXTRA_FIELD_SIZE - 4, 2);
        writeUInt64LE(zeiefBuffer, this.uncompressedSize, 4);
        writeUInt64LE(zeiefBuffer, this.compressedSize, 12);
        writeUInt64LE(zeiefBuffer, this.relativeOffsetOfLocalHeader, 20);
      }
      fixedSizeStuff.writeUInt32LE(33639248, 0);
      fixedSizeStuff.writeUInt16LE(VERSION_MADE_BY, 4);
      fixedSizeStuff.writeUInt16LE(versionNeededToExtract, 6);
      fixedSizeStuff.writeUInt16LE(generalPurposeBitFlag, 8);
      fixedSizeStuff.writeUInt16LE(this.getCompressionMethod(), 10);
      fixedSizeStuff.writeUInt16LE(this.lastModFileTime, 12);
      fixedSizeStuff.writeUInt16LE(this.lastModFileDate, 14);
      fixedSizeStuff.writeUInt32LE(this.crc32, 16);
      fixedSizeStuff.writeUInt32LE(normalCompressedSize, 20);
      fixedSizeStuff.writeUInt32LE(normalUncompressedSize, 24);
      fixedSizeStuff.writeUInt16LE(this.utf8FileName.length, 28);
      fixedSizeStuff.writeUInt16LE(izutefBuffer.length + zeiefBuffer.length, 30);
      fixedSizeStuff.writeUInt16LE(this.fileComment.length, 32);
      fixedSizeStuff.writeUInt16LE(0, 34);
      fixedSizeStuff.writeUInt16LE(0, 36);
      fixedSizeStuff.writeUInt32LE(this.externalFileAttributes, 38);
      fixedSizeStuff.writeUInt32LE(normalRelativeOffsetOfLocalHeader, 42);
      return Buffer.concat([
        fixedSizeStuff,
        // file name (variable size)
        this.utf8FileName,
        // extra field (variable size)
        izutefBuffer,
        zeiefBuffer,
        // file comment (variable size)
        this.fileComment
      ]);
    };
    Entry.prototype.getCompressionMethod = function() {
      var NO_COMPRESSION = 0;
      var DEFLATE_COMPRESSION = 8;
      return this.compressionLevel === 0 ? NO_COMPRESSION : DEFLATE_COMPRESSION;
    };
    var minDosDate = new Date(1980, 0, 1);
    var maxDosDate = new Date(2107, 11, 31, 23, 59, 58);
    function dateToDosDateTime(jsDate) {
      if (jsDate < minDosDate) jsDate = minDosDate;
      else if (jsDate > maxDosDate) jsDate = maxDosDate;
      var date = 0;
      date |= jsDate.getDate() & 31;
      date |= (jsDate.getMonth() + 1 & 15) << 5;
      date |= (jsDate.getFullYear() - 1980 & 127) << 9;
      var time = 0;
      time |= Math.floor(jsDate.getSeconds() / 2);
      time |= (jsDate.getMinutes() & 63) << 5;
      time |= (jsDate.getHours() & 31) << 11;
      return { date, time };
    }
    function writeUInt64LE(buffer, n, offset) {
      var high = Math.floor(n / 4294967296);
      var low = n % 4294967296;
      buffer.writeUInt32LE(low, offset);
      buffer.writeUInt32LE(high, offset + 4);
    }
    util.inherits(ByteCounter, Transform);
    function ByteCounter(options) {
      Transform.call(this, options);
      this.byteCount = 0;
    }
    ByteCounter.prototype._transform = function(chunk, encoding, cb) {
      this.byteCount += chunk.length;
      cb(null, chunk);
    };
    util.inherits(Crc32Watcher, Transform);
    function Crc32Watcher(options) {
      Transform.call(this, options);
      this.crc32 = 0;
    }
    Crc32Watcher.prototype._transform = function(chunk, encoding, cb) {
      this.crc32 = crc32.unsigned(chunk, this.crc32);
      cb(null, chunk);
    };
    var cp437 = "\0\u263A\u263B\u2665\u2666\u2663\u2660\u2022\u25D8\u25CB\u25D9\u2642\u2640\u266A\u266B\u263C\u25BA\u25C4\u2195\u203C\xB6\xA7\u25AC\u21A8\u2191\u2193\u2192\u2190\u221F\u2194\u25B2\u25BC !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u2302\xC7\xFC\xE9\xE2\xE4\xE0\xE5\xE7\xEA\xEB\xE8\xEF\xEE\xEC\xC4\xC5\xC9\xE6\xC6\xF4\xF6\xF2\xFB\xF9\xFF\xD6\xDC\xA2\xA3\xA5\u20A7\u0192\xE1\xED\xF3\xFA\xF1\xD1\xAA\xBA\xBF\u2310\xAC\xBD\xBC\xA1\xAB\xBB\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255D\u255C\u255B\u2510\u2514\u2534\u252C\u251C\u2500\u253C\u255E\u255F\u255A\u2554\u2569\u2566\u2560\u2550\u256C\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256B\u256A\u2518\u250C\u2588\u2584\u258C\u2590\u2580\u03B1\xDF\u0393\u03C0\u03A3\u03C3\xB5\u03C4\u03A6\u0398\u03A9\u03B4\u221E\u03C6\u03B5\u2229\u2261\xB1\u2265\u2264\u2320\u2321\xF7\u2248\xB0\u2219\xB7\u221A\u207F\xB2\u25A0\xA0";
    if (cp437.length !== 256) throw new Error("assertion failure");
    var reverseCp437 = null;
    function encodeCp437(string) {
      if (/^[\x20-\x7e]*$/.test(string)) {
        return bufferFrom(string, "utf-8");
      }
      if (reverseCp437 == null) {
        reverseCp437 = {};
        for (var i = 0; i < cp437.length; i++) {
          reverseCp437[cp437[i]] = i;
        }
      }
      var result = bufferAlloc(string.length);
      for (var i = 0; i < string.length; i++) {
        var b = reverseCp437[string[i]];
        if (b == null) throw new Error("character not encodable in CP437: " + JSON.stringify(string[i]));
        result[i] = b;
      }
      return result;
    }
    function bufferAlloc(size) {
      bufferAlloc = modern;
      try {
        return bufferAlloc(size);
      } catch (e) {
        bufferAlloc = legacy;
        return bufferAlloc(size);
      }
      function modern(size2) {
        return Buffer.allocUnsafe(size2);
      }
      function legacy(size2) {
        return new Buffer(size2);
      }
    }
    function bufferFrom(something, encoding) {
      bufferFrom = modern;
      try {
        return bufferFrom(something, encoding);
      } catch (e) {
        bufferFrom = legacy;
        return bufferFrom(something, encoding);
      }
      function modern(something2, encoding2) {
        return Buffer.from(something2, encoding2);
      }
      function legacy(something2, encoding2) {
        return new Buffer(something2, encoding2);
      }
    }
    function bufferIncludes(buffer, content) {
      bufferIncludes = modern;
      try {
        return bufferIncludes(buffer, content);
      } catch (e) {
        bufferIncludes = legacy;
        return bufferIncludes(buffer, content);
      }
      function modern(buffer2, content2) {
        return buffer2.includes(content2);
      }
      function legacy(buffer2, content2) {
        for (var i = 0; i <= buffer2.length - content2.length; i++) {
          for (var j = 0; ; j++) {
            if (j === content2.length) return true;
            if (buffer2[i + j] !== content2[j]) break;
          }
        }
        return false;
      }
    }
  }
});

// src/client/base-client.ts
var AtlassianBaseClient = class {
  baseUrl;
  authHeader;
  constructor(config) {
    let domain = config.domain;
    if (domain.startsWith("https://")) {
      domain = domain.slice(8);
    } else if (domain.startsWith("http://")) {
      domain = domain.slice(7);
    }
    while (domain.endsWith("/")) {
      domain = domain.slice(0, -1);
    }
    this.baseUrl = `https://${domain}`;
    const credentials = `${config.email}:${config.apiToken}`;
    this.authHeader = `Basic ${Buffer.from(credentials).toString("base64")}`;
  }
  buildHeaders(extra) {
    return {
      Authorization: this.authHeader,
      "Content-Type": "application/json",
      Accept: "application/json",
      ...extra
    };
  }
  async ensureOk(res) {
    if (!res.ok) {
      const text = await res.text().catch(() => "Unknown error");
      throw new Error(`Atlassian API error ${res.status}: ${text}`);
    }
  }
  async request(method, path, body, headers) {
    const res = await fetch(`${this.baseUrl}${path}`, {
      method,
      headers: this.buildHeaders(headers),
      body: body !== void 0 ? JSON.stringify(body) : void 0
    });
    await this.ensureOk(res);
    if (res.status === 204) {
      return void 0;
    }
    return res.json();
  }
  async requestFormData(path, formData, headers) {
    const res = await fetch(`${this.baseUrl}${path}`, {
      method: "POST",
      headers: {
        Authorization: this.authHeader,
        "X-Atlassian-Token": "nocheck",
        ...headers
      },
      body: formData
    });
    await this.ensureOk(res);
    if (res.status === 204) {
      return void 0;
    }
    return res.json();
  }
  async requestRaw(method, path, body, headers) {
    const res = await fetch(`${this.baseUrl}${path}`, {
      method,
      headers: this.buildHeaders(headers),
      body: body !== void 0 ? JSON.stringify(body) : void 0
    });
    await this.ensureOk(res);
    return res;
  }
};

// src/client/confluence-client.ts
var ConfluenceClient = class extends AtlassianBaseClient {
  constructor(config) {
    super(config);
  }
  // --- Pages ---
  async search(cql, limit = 25, start = 0) {
    const params = new URLSearchParams({ cql, limit: String(limit), start: String(start) });
    return this.request("GET", `/wiki/rest/api/search?${params.toString()}`);
  }
  async getPage(pageId, expand = "body.storage,version") {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}?expand=${encodeURIComponent(expand)}`
    );
  }
  async getPageChildren(pageId, limit = 25, start = 0) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}/child/page?limit=${limit}&start=${start}`
    );
  }
  async getPageHistory(pageId) {
    return this.request("GET", `/wiki/rest/api/content/${pageId}/history`);
  }
  async createPage(page) {
    return this.request("POST", "/wiki/rest/api/content", page);
  }
  async updatePage(pageId, page) {
    return this.request("PUT", `/wiki/rest/api/content/${pageId}`, page);
  }
  async deletePage(pageId) {
    return this.request("DELETE", `/wiki/rest/api/content/${pageId}`);
  }
  async movePage(pageId, targetAncestorId, currentVersion) {
    return this.request("PUT", `/wiki/rest/api/content/${pageId}`, {
      type: "page",
      ancestors: [{ id: targetAncestorId }],
      version: { number: currentVersion + 1 }
    });
  }
  async getPageVersion(pageId, version) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}?expand=body.storage&status=historical&version=${version}`
    );
  }
  // --- Comments ---
  async getComments(pageId, limit = 25, start = 0) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}/child/comment?expand=body.storage&limit=${limit}&start=${start}`
    );
  }
  async addComment(pageId, body) {
    return this.request("POST", "/wiki/rest/api/content", {
      type: "comment",
      container: { id: pageId, type: "page" },
      body: { storage: { value: body, representation: "storage" } }
    });
  }
  async replyToComment(pageId, parentCommentId, body) {
    return this.request("POST", "/wiki/rest/api/content", {
      type: "comment",
      container: { id: pageId, type: "page" },
      ancestors: [{ id: parentCommentId }],
      body: { storage: { value: body, representation: "storage" } }
    });
  }
  // --- Labels ---
  async getLabels(pageId) {
    return this.request("GET", `/wiki/rest/api/content/${pageId}/label`);
  }
  async addLabel(pageId, labels) {
    return this.request("POST", `/wiki/rest/api/content/${pageId}/label`, labels);
  }
  // --- Users ---
  async searchUser(query) {
    return this.request(
      "GET",
      `/wiki/rest/api/search/user?cql=${encodeURIComponent('user.fullname~"' + query + '"')}`
    );
  }
  // --- Analytics ---
  async getPageViews(pageId, fromDate) {
    const params = fromDate ? `?fromDate=${encodeURIComponent(fromDate)}` : "";
    return this.request("GET", `/wiki/rest/api/analytics/content/${pageId}/views${params}`);
  }
  async getPageViewers(pageId, fromDate) {
    const params = fromDate ? `?fromDate=${encodeURIComponent(fromDate)}` : "";
    return this.request("GET", `/wiki/rest/api/analytics/content/${pageId}/viewers${params}`);
  }
  // --- Attachments ---
  async uploadAttachment(pageId, filename, content) {
    const formData = new FormData();
    const blob = new Blob([content]);
    formData.append("file", blob, filename);
    return this.requestFormData(`/wiki/rest/api/content/${pageId}/child/attachment`, formData);
  }
  async getAttachments(pageId, limit = 25, start = 0) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}/child/attachment?limit=${limit}&start=${start}`
    );
  }
  async downloadAttachment(pageId, filename) {
    const data = await this.getAttachments(pageId, 100);
    const results = data["results"] ?? [];
    const attachment = results.find((a) => a["title"] === filename);
    if (!attachment) {
      throw new Error(`Attachment "${filename}" not found on page ${pageId}`);
    }
    return this.requestRaw("GET", `/wiki/rest/api/content/${attachment["id"]}/download`);
  }
  async downloadAttachmentById(attachmentId) {
    return this.requestRaw("GET", `/wiki/rest/api/content/${attachmentId}/download`);
  }
  async deleteAttachment(attachmentId) {
    return this.request("DELETE", `/wiki/rest/api/content/${attachmentId}`);
  }
  async getPageImages(pageId) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}/child/attachment?mediaType=image&expand=metadata`
    );
  }
};

// src/client/jira-client.ts
var JiraClient = class extends AtlassianBaseClient {
  constructor(config) {
    super(config);
  }
  // --- Issues ---
  async getIssue(issueKey, expand) {
    const query = expand ? `?expand=${encodeURIComponent(expand)}` : "";
    return this.request("GET", `/rest/api/3/issue/${issueKey}${query}`);
  }
  async search(jql, startAt = 0, maxResults = 50, fields) {
    const effectiveFields = fields ?? ["summary", "status", "assignee", "priority", "issuetype", "updated"];
    const params = new URLSearchParams({
      jql,
      startAt: String(startAt),
      maxResults: String(maxResults),
      fields: effectiveFields.join(",")
    });
    return this.request("GET", `/rest/api/3/search/jql?${params.toString()}`);
  }
  async createIssue(fields) {
    return this.request("POST", "/rest/api/3/issue", { fields });
  }
  async updateIssue(issueKey, fields) {
    return this.request("PUT", `/rest/api/3/issue/${issueKey}`, { fields });
  }
  async deleteIssue(issueKey) {
    return this.request("DELETE", `/rest/api/3/issue/${issueKey}`);
  }
  async bulkCreateIssues(issues) {
    return this.request("POST", "/rest/api/3/issue/bulk", { issueUpdates: issues });
  }
  async getChangelogs(issueKey, startAt = 0, maxResults = 100) {
    return this.request(
      "GET",
      `/rest/api/3/issue/${issueKey}/changelog?startAt=${startAt}&maxResults=${maxResults}`
    );
  }
  // --- Fields ---
  async getFields() {
    return this.request("GET", "/rest/api/3/field");
  }
  async getFieldOptions(fieldId, contextId) {
    return this.request("GET", `/rest/api/3/field/${fieldId}/context/${contextId}/option`);
  }
  // --- Comments ---
  async addComment(issueKey, body) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/comment`, { body });
  }
  async editComment(issueKey, commentId, body) {
    return this.request("PUT", `/rest/api/3/issue/${issueKey}/comment/${commentId}`, { body });
  }
  // --- Transitions ---
  async getTransitions(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/transitions`);
  }
  async transitionIssue(issueKey, transitionId) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/transitions`, {
      transition: { id: transitionId }
    });
  }
  // --- Projects ---
  async getAllProjects() {
    return this.request("GET", "/rest/api/3/project");
  }
  async getProjectVersions(projectKey) {
    return this.request("GET", `/rest/api/3/project/${projectKey}/versions`);
  }
  async getProjectComponents(projectKey) {
    return this.request("GET", `/rest/api/3/project/${projectKey}/components`);
  }
  async createVersion(version) {
    return this.request("POST", "/rest/api/3/version", version);
  }
  // --- Agile ---
  async getBoards(startAt = 0, maxResults = 50) {
    return this.request("GET", `/rest/agile/1.0/board?startAt=${startAt}&maxResults=${maxResults}`);
  }
  async getBoardIssues(boardId, startAt = 0, maxResults = 50) {
    return this.request(
      "GET",
      `/rest/agile/1.0/board/${boardId}/issue?startAt=${startAt}&maxResults=${maxResults}`
    );
  }
  async getSprintsFromBoard(boardId, startAt = 0, maxResults = 50) {
    return this.request(
      "GET",
      `/rest/agile/1.0/board/${boardId}/sprint?startAt=${startAt}&maxResults=${maxResults}`
    );
  }
  async getSprintIssues(sprintId, startAt = 0, maxResults = 50) {
    return this.request(
      "GET",
      `/rest/agile/1.0/sprint/${sprintId}/issue?startAt=${startAt}&maxResults=${maxResults}`
    );
  }
  async createSprint(sprint) {
    return this.request("POST", "/rest/agile/1.0/sprint", sprint);
  }
  async updateSprint(sprintId, sprint) {
    return this.request("PUT", `/rest/agile/1.0/sprint/${sprintId}`, sprint);
  }
  async addIssuesToSprint(sprintId, issueKeys) {
    return this.request("POST", `/rest/agile/1.0/sprint/${sprintId}/issue`, {
      issues: issueKeys
    });
  }
  // --- Links ---
  async getLinkTypes() {
    return this.request("GET", "/rest/api/3/issueLinkType");
  }
  async linkToEpic(epicKey, issueKeys) {
    return this.request("PUT", `/rest/agile/1.0/epic/${epicKey}/issue`, {
      issues: issueKeys
    });
  }
  async createIssueLink(link) {
    return this.request("POST", "/rest/api/3/issueLink", link);
  }
  async createRemoteIssueLink(issueKey, remoteLink) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/remotelink`, remoteLink);
  }
  async removeIssueLink(linkId) {
    return this.request("DELETE", `/rest/api/3/issueLink/${linkId}`);
  }
  // --- Worklog ---
  async getWorklog(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/worklog`);
  }
  async addWorklog(issueKey, worklog) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/worklog`, worklog);
  }
  // --- Attachments ---
  async downloadAttachment(attachmentId) {
    return this.requestRaw("GET", `/rest/api/3/attachment/content/${attachmentId}`);
  }
  async getIssueForAttachments(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}?fields=attachment`);
  }
  // --- Users ---
  async getMyself() {
    return this.request("GET", "/rest/api/3/myself");
  }
  async getUser(accountId) {
    return this.request("GET", `/rest/api/3/user?accountId=${encodeURIComponent(accountId)}`);
  }
  // --- Watchers ---
  async getWatchers(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/watchers`);
  }
  async addWatcher(issueKey, accountId) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/watchers`, accountId);
  }
  async removeWatcher(issueKey, accountId) {
    return this.request(
      "DELETE",
      `/rest/api/3/issue/${issueKey}/watchers?accountId=${encodeURIComponent(accountId)}`
    );
  }
  // --- Service Desk ---
  async getServiceDesks() {
    return this.request("GET", "/rest/servicedeskapi/servicedesk");
  }
  async getServiceDeskQueues(serviceDeskId) {
    return this.request("GET", `/rest/servicedeskapi/servicedesk/${serviceDeskId}/queue`);
  }
  async getQueueIssues(serviceDeskId, queueId) {
    return this.request(
      "GET",
      `/rest/servicedeskapi/servicedesk/${serviceDeskId}/queue/${queueId}/issue`
    );
  }
  // --- Forms (Proforma) ---
  async getIssueProformaForms(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/properties/proforma.forms`);
  }
  async getProformaFormDetails(issueKey, formId) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/properties/proforma.forms.${formId}`);
  }
  async updateProformaFormAnswers(issueKey, formId, answers) {
    return this.request(
      "PUT",
      `/rest/api/3/issue/${issueKey}/properties/proforma.forms.${formId}`,
      answers
    );
  }
  // --- Metrics ---
  async getIssueDateFields(issueKey) {
    return this.request(
      "GET",
      `/rest/api/3/issue/${issueKey}?fields=created,updated,resolutiondate,duedate`
    );
  }
  async getIssueSla(issueKey) {
    return this.request("GET", `/rest/servicedeskapi/request/${issueKey}/sla`);
  }
  // --- Development ---
  async getDevelopmentInfo(issueId, applicationType = "stash", dataType = "repository") {
    const params = new URLSearchParams({
      issueId,
      applicationType,
      dataType
    });
    return this.request("GET", `/rest/dev-status/1.0/issue/detail?${params.toString()}`);
  }
  async getDevelopmentSummary(issueId) {
    return this.request("GET", `/rest/dev-status/1.0/issue/summary?issueId=${issueId}`);
  }
  async getBatchDevelopmentInfo(issueIds, applicationType = "stash", dataType = "repository") {
    const results = [];
    for (const issueId of issueIds) {
      const data = await this.getDevelopmentInfo(issueId, applicationType, dataType);
      results.push(data);
    }
    return results;
  }
};

// src/shared/client.ts
function createClients(context) {
  const domain = context.config["domain"];
  const email = context.config["email"];
  const apiToken = context.config["apiToken"];
  if (!domain || !email || !apiToken) {
    throw new Error(
      "Missing Atlassian configuration. Set domain, email, and apiToken via: renre-kit ext config renre-atlassian --set domain=<company>.atlassian.net && renre-kit ext config renre-atlassian --set email=<user@company.com> && renre-kit vault set renre-atlassian.apiToken"
    );
  }
  const config = { domain, email, apiToken };
  return {
    jira: new JiraClient(config),
    confluence: new ConfluenceClient(config)
  };
}

// ../../packages/extension-sdk/dist/node/index.js
var import_yazl = __toESM(require_yazl(), 1);
var NOISE_KEYS = /* @__PURE__ */ new Set([
  "self",
  "expand",
  "_links",
  "_expands",
  "avatarUrls",
  "iconUrl",
  "icon"
]);
var PAGINATION_KEYS = {
  total: "total",
  startAt: "offset",
  start: "offset",
  offset: "offset",
  maxResults: "limit",
  limit: "limit",
  size: "count"
};
function jsonToMarkdown(data, options) {
  const maxDepth = options?.maxDepth ?? 4;
  const filterNoise = options?.filterNoise ?? false;
  const lines = [];
  if (options?.title) {
    lines.push(`# ${options.title}`, "");
  }
  const paginatedResult = tryPaginatedResponse(data, maxDepth, filterNoise);
  if (paginatedResult !== null) {
    lines.push(paginatedResult);
  } else {
    lines.push(renderValue(data, 1, maxDepth, filterNoise));
  }
  return lines.join("\n").trim();
}
function detectPagination(data) {
  const fields = {};
  let arrayKey = null;
  for (const key of Object.keys(data)) {
    const role = PAGINATION_KEYS[key];
    if (role && typeof data[key] === "number") {
      fields[role] = data[key];
    } else if (Array.isArray(data[key]) && arrayKey === null) {
      arrayKey = key;
    }
  }
  if (!arrayKey) return null;
  const hasPaginationMeta = "total" in fields || "offset" in fields || "limit" in fields;
  return hasPaginationMeta ? { fields, arrayKey } : null;
}
function tryPaginatedResponse(data, maxDepth, filterNoise) {
  if (!isPlainObject(data)) return null;
  const pagination = detectPagination(data);
  if (!pagination) return null;
  const items = data[pagination.arrayKey];
  const lines = [];
  const total = pagination.fields["total"];
  if (total !== void 0) {
    lines.push(`*Showing ${items.length} of ${total}*`, "");
  }
  lines.push(renderValue(items, 1, maxDepth, filterNoise));
  return lines.join("\n");
}
function renderValue(value, depth, maxDepth, filterNoise) {
  if (value === null || value === void 0) return "*none*";
  if (typeof value === "string") return renderString(value);
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) return renderArray(value, depth, maxDepth, filterNoise);
  if (isPlainObject(value)) return renderObject(value, depth, maxDepth, filterNoise);
  return typeof value === "symbol" ? value.toString() : JSON.stringify(value);
}
function renderString(value) {
  if (value === "") return "*(empty)*";
  if (value.includes("\n")) {
    return `\`\`\`
${value}
\`\`\``;
  }
  if (isUrl(value)) {
    return `[${value}](${value})`;
  }
  return value;
}
function renderArray(arr, depth, maxDepth, filterNoise) {
  if (arr.length === 0) return "*(empty list)*";
  if (arr.length === 1) {
    return renderValue(arr[0], depth, maxDepth, filterNoise);
  }
  if (arr.every(isPrimitive)) {
    return arr.map((item) => `- ${item === null ? "*none*" : String(item)}`).join("\n");
  }
  if (arr.every(isPlainObject)) {
    return renderObjectArray(arr, depth, maxDepth, filterNoise);
  }
  return arr.map((item, i) => {
    const rendered = renderValue(item, depth + 1, maxDepth, filterNoise);
    if (isPrimitive(item)) return `- ${rendered}`;
    return `### Item ${i + 1}

${rendered}`;
  }).join("\n");
}
function renderObjectArray(arr, depth, maxDepth, filterNoise) {
  const allKeys = collectTableKeys(arr, filterNoise);
  if (allKeys.length === 0) return "*(empty)*";
  const canTable = arr.every(
    (obj) => allKeys.every((key) => {
      const val = obj[key];
      return val === void 0 || val === null || isPrimitive(val) || isSingleValueObject(val);
    })
  );
  if (canTable) {
    return renderTable(arr, allKeys);
  }
  return arr.map((obj, i) => {
    const heading = "#".repeat(Math.min(depth + 1, 6));
    const label = findLabel(obj) ?? `Item ${i + 1}`;
    return `${heading} ${label}

${renderObject(obj, depth + 1, maxDepth, filterNoise)}`;
  }).join("\n\n");
}
function renderTable(arr, keys) {
  const headers = keys.map(humanizeKey);
  const headerRow = `| ${headers.join(" | ")} |`;
  const separatorRow = `| ${headers.map(() => "---").join(" | ")} |`;
  const dataRows = arr.map((obj) => {
    const cells = keys.map((key) => flattenCellValue(obj[key]));
    return `| ${cells.join(" | ")} |`;
  });
  return [headerRow, separatorRow, ...dataRows].join("\n");
}
function renderObject(obj, depth, maxDepth, filterNoise) {
  const entries = Object.entries(obj).filter(
    ([key, val]) => val !== null && val !== void 0 && (!filterNoise || !NOISE_KEYS.has(key))
  );
  if (entries.length === 0) return "*(empty)*";
  if (depth > maxDepth) {
    return `\`\`\`json
${JSON.stringify(obj, null, 2)}
\`\`\``;
  }
  const simpleEntries = [];
  const complexEntries = [];
  for (const [key, val] of entries) {
    if (typeof val === "string" && val.includes("\n")) {
      complexEntries.push([key, val]);
    } else if (isPrimitive(val)) {
      simpleEntries.push([key, val]);
    } else if (isSingleValueObject(val)) {
      simpleEntries.push([key, extractSingleValue(val)]);
    } else {
      complexEntries.push([key, val]);
    }
  }
  const lines = [];
  for (const [key, val] of simpleEntries) {
    const rendered = renderInlineValue(val);
    lines.push(`**${humanizeKey(key)}:** ${rendered}`);
  }
  for (const [key, val] of complexEntries) {
    const heading = "#".repeat(Math.min(depth + 1, 6));
    lines.push("", `${heading} ${humanizeKey(key)}`, "");
    lines.push(renderValue(val, depth + 1, maxDepth, filterNoise));
  }
  return lines.join("\n");
}
function renderInlineValue(value) {
  if (value === null || value === void 0) return "*none*";
  if (typeof value === "string") {
    if (value === "") return "*(empty)*";
    if (isUrl(value)) return `[${value}](${value})`;
    return value;
  }
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return JSON.stringify(value);
}
function flattenCellValue(value) {
  if (value === null || value === void 0) return "";
  if (isPrimitive(value)) return String(value);
  if (isSingleValueObject(value)) {
    return String(extractSingleValue(value));
  }
  if (Array.isArray(value)) {
    if (value.length === 0) return "";
    if (value.every(isPrimitive)) return value.join(", ");
    if (value.every(isSingleValueObject)) {
      return value.map((v) => extractSingleValue(v)).join(", ");
    }
  }
  return JSON.stringify(value);
}
function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isPrimitive(value) {
  return value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean";
}
function isSingleValueObject(value) {
  if (!isPlainObject(value)) return false;
  const entries = Object.entries(value);
  if (entries.length === 0) return false;
  const meaningfulEntries = entries.filter(
    ([key]) => key !== "id" && key !== "self" && key !== "iconUrl" && key !== "avatarUrls"
  );
  return meaningfulEntries.length === 1 && isPrimitive(meaningfulEntries[0][1]);
}
function extractSingleValue(obj) {
  const meaningful = Object.entries(obj).find(
    ([key]) => key !== "id" && key !== "self" && key !== "iconUrl" && key !== "avatarUrls"
  );
  return meaningful?.[1] ?? Object.values(obj)[0];
}
function findLabel(obj) {
  for (const key of ["key", "name", "title", "displayName", "summary", "label", "id"]) {
    const val = obj[key];
    if (typeof val === "string") return val;
  }
  return null;
}
function collectTableKeys(arr, filterNoise) {
  const keySet = /* @__PURE__ */ new Set();
  for (const obj of arr) {
    for (const key of Object.keys(obj)) {
      if (filterNoise && NOISE_KEYS.has(key)) continue;
      keySet.add(key);
    }
  }
  return [...keySet];
}
function humanizeKey(key) {
  let result = key.replace(/_/g, " ");
  result = result.replace(/([a-z])([A-Z])/g, "$1 $2");
  return result.split(" ").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
}
function isUrl(value) {
  return value.startsWith("https://") || value.startsWith("http://");
}

// src/shared/formatters.ts
function toOutput(data) {
  return {
    output: jsonToMarkdown(data, { filterNoise: true }),
    exitCode: 0
  };
}
function errorOutput(err) {
  const message = err instanceof Error ? err.message : String(err);
  return {
    output: message,
    exitCode: 1
  };
}

export {
  createClients,
  toOutput,
  errorOutput
};
