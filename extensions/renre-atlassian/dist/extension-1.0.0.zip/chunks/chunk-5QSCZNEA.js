import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  external_exports,
  jsonToMarkdown
} from "./chunk-GIJXU2QH.js";

// src/shared/schemas.ts
var paginationSchema = external_exports.object({
  startAt: external_exports.coerce.number().int().min(0).default(0),
  maxResults: external_exports.coerce.number().int().min(1).max(100).default(50)
});
var confluencePaginationSchema = external_exports.object({
  start: external_exports.coerce.number().int().min(0).default(0),
  limit: external_exports.coerce.number().int().min(1).max(100).default(25)
});
var issueKeySchema = external_exports.string().min(1, "issueKey is required");
var pageIdSchema = external_exports.string().min(1, "pageId is required");
var accountIdSchema = external_exports.string().min(1, "accountId is required");
var projectKeySchema = external_exports.string().min(1, "projectKey is required");
var boardIdSchema = external_exports.coerce.number().int().positive("boardId must be a positive integer");
var sprintIdSchema = external_exports.coerce.number().int().positive("sprintId must be a positive integer");
var atlassianConfigSchema = external_exports.object({
  domain: external_exports.string().min(1, "domain is required").refine((d) => d.includes("."), "domain must be a valid hostname (e.g. company.atlassian.net)"),
  email: external_exports.string().email("email must be a valid email address"),
  apiToken: external_exports.string().min(1, "apiToken is required")
});

// src/client/base-client.ts
var AtlassianApiError = class extends Error {
  constructor(status, body) {
    super(`Atlassian API error ${status}: ${body}`);
    this.status = status;
    this.body = body;
    this.name = "AtlassianApiError";
  }
};
var AtlassianBaseClient = class {
  baseUrl;
  authHeader;
  constructor(config) {
    let domain = config.domain;
    if (domain.startsWith("https://")) {
      domain = domain.slice(8);
    } else if (domain.startsWith("http://")) {
      domain = domain.slice(7);
    }
    while (domain.endsWith("/")) {
      domain = domain.slice(0, -1);
    }
    this.baseUrl = `https://${domain}`;
    const credentials = `${config.email}:${config.apiToken}`;
    this.authHeader = `Basic ${Buffer.from(credentials).toString("base64")}`;
  }
  buildHeaders(extra) {
    return {
      Authorization: this.authHeader,
      "Content-Type": "application/json",
      Accept: "application/json",
      ...extra
    };
  }
  async ensureOk(res) {
    if (!res.ok) {
      const text = await res.text().catch(() => "Unknown error");
      throw new AtlassianApiError(res.status, text);
    }
  }
  async request(method, path, body, headers) {
    const res = await fetch(`${this.baseUrl}${path}`, {
      method,
      headers: this.buildHeaders(headers),
      body: body !== void 0 ? JSON.stringify(body) : void 0
    });
    await this.ensureOk(res);
    if (res.status === 204) {
      return void 0;
    }
    return res.json();
  }
  async requestFormData(path, formData, headers) {
    const res = await fetch(`${this.baseUrl}${path}`, {
      method: "POST",
      headers: {
        Authorization: this.authHeader,
        "X-Atlassian-Token": "nocheck",
        ...headers
      },
      body: formData
    });
    await this.ensureOk(res);
    if (res.status === 204) {
      return void 0;
    }
    return res.json();
  }
  async requestRaw(method, path, body, headers) {
    const res = await fetch(`${this.baseUrl}${path}`, {
      method,
      headers: this.buildHeaders(headers),
      body: body !== void 0 ? JSON.stringify(body) : void 0
    });
    await this.ensureOk(res);
    return res;
  }
};

// src/client/confluence-client.ts
var ConfluenceClient = class extends AtlassianBaseClient {
  constructor(config) {
    super(config);
  }
  // --- Pages ---
  async search(cql, limit = 25, start = 0) {
    const params = new URLSearchParams({ cql, limit: String(limit), start: String(start) });
    return this.request("GET", `/wiki/rest/api/search?${params.toString()}`);
  }
  async getPage(pageId, expand = "body.storage,version") {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}?expand=${encodeURIComponent(expand)}`
    );
  }
  async getPageChildren(pageId, limit = 25, start = 0) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}/child/page?limit=${limit}&start=${start}`
    );
  }
  async getPageHistory(pageId) {
    return this.request("GET", `/wiki/rest/api/content/${pageId}/history`);
  }
  async createPage(page) {
    return this.request("POST", "/wiki/rest/api/content", page);
  }
  async updatePage(pageId, page) {
    return this.request("PUT", `/wiki/rest/api/content/${pageId}`, page);
  }
  async deletePage(pageId) {
    return this.request("DELETE", `/wiki/rest/api/content/${pageId}`);
  }
  async movePage(pageId, targetAncestorId, currentVersion) {
    return this.request("PUT", `/wiki/rest/api/content/${pageId}`, {
      type: "page",
      ancestors: [{ id: targetAncestorId }],
      version: { number: currentVersion + 1 }
    });
  }
  async getPageVersion(pageId, version) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}?expand=body.storage&status=historical&version=${version}`
    );
  }
  // --- Comments ---
  async getComments(pageId, limit = 25, start = 0) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}/child/comment?expand=body.storage&limit=${limit}&start=${start}`
    );
  }
  async addComment(pageId, body) {
    return this.request("POST", "/wiki/rest/api/content", {
      type: "comment",
      container: { id: pageId, type: "page" },
      body: { storage: { value: body, representation: "storage" } }
    });
  }
  async replyToComment(pageId, parentCommentId, body) {
    return this.request("POST", "/wiki/rest/api/content", {
      type: "comment",
      container: { id: pageId, type: "page" },
      ancestors: [{ id: parentCommentId }],
      body: { storage: { value: body, representation: "storage" } }
    });
  }
  // --- Labels ---
  async getLabels(pageId) {
    return this.request("GET", `/wiki/rest/api/content/${pageId}/label`);
  }
  async addLabel(pageId, labels) {
    return this.request("POST", `/wiki/rest/api/content/${pageId}/label`, labels);
  }
  // --- Users ---
  async searchUser(query) {
    return this.request(
      "GET",
      `/wiki/rest/api/search/user?cql=${encodeURIComponent('user.fullname~"' + query + '"')}`
    );
  }
  // --- Analytics ---
  async getPageViews(pageId, fromDate) {
    const params = fromDate ? `?fromDate=${encodeURIComponent(fromDate)}` : "";
    return this.request("GET", `/wiki/rest/api/analytics/content/${pageId}/views${params}`);
  }
  async getPageViewers(pageId, fromDate) {
    const params = fromDate ? `?fromDate=${encodeURIComponent(fromDate)}` : "";
    return this.request("GET", `/wiki/rest/api/analytics/content/${pageId}/viewers${params}`);
  }
  // --- Attachments ---
  async uploadAttachment(pageId, filename, content) {
    const formData = new FormData();
    const blob = new Blob([content]);
    formData.append("file", blob, filename);
    return this.requestFormData(`/wiki/rest/api/content/${pageId}/child/attachment`, formData);
  }
  async getAttachments(pageId, limit = 25, start = 0) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}/child/attachment?limit=${limit}&start=${start}`
    );
  }
  async downloadAttachment(pageId, filename) {
    const data = await this.getAttachments(pageId, 100);
    const results = data["results"] ?? [];
    const attachment = results.find((a) => a["title"] === filename);
    if (!attachment) {
      throw new Error(`Attachment "${filename}" not found on page ${pageId}`);
    }
    return this.requestRaw("GET", `/wiki/rest/api/content/${attachment["id"]}/download`);
  }
  async downloadAttachmentById(attachmentId) {
    return this.requestRaw("GET", `/wiki/rest/api/content/${attachmentId}/download`);
  }
  async deleteAttachment(attachmentId) {
    return this.request("DELETE", `/wiki/rest/api/content/${attachmentId}`);
  }
  async getPageImages(pageId) {
    return this.request(
      "GET",
      `/wiki/rest/api/content/${pageId}/child/attachment?mediaType=image&expand=metadata`
    );
  }
};

// src/client/jira-client.ts
var JiraClient = class extends AtlassianBaseClient {
  constructor(config) {
    super(config);
  }
  // --- Issues ---
  async getIssue(issueKey, expand) {
    const query = expand ? `?expand=${encodeURIComponent(expand)}` : "";
    return this.request("GET", `/rest/api/3/issue/${issueKey}${query}`);
  }
  async search(jql, startAt = 0, maxResults = 50, fields) {
    const effectiveFields = fields ?? ["summary", "status", "assignee", "priority", "issuetype", "updated"];
    const params = new URLSearchParams({
      jql,
      startAt: String(startAt),
      maxResults: String(maxResults),
      fields: effectiveFields.join(",")
    });
    return this.request("GET", `/rest/api/3/search/jql?${params.toString()}`);
  }
  async createIssue(fields) {
    return this.request("POST", "/rest/api/3/issue", { fields });
  }
  async updateIssue(issueKey, fields) {
    return this.request("PUT", `/rest/api/3/issue/${issueKey}`, { fields });
  }
  async deleteIssue(issueKey) {
    return this.request("DELETE", `/rest/api/3/issue/${issueKey}`);
  }
  async bulkCreateIssues(issues) {
    return this.request("POST", "/rest/api/3/issue/bulk", { issueUpdates: issues });
  }
  async getChangelogs(issueKey, startAt = 0, maxResults = 100) {
    return this.request(
      "GET",
      `/rest/api/3/issue/${issueKey}/changelog?startAt=${startAt}&maxResults=${maxResults}`
    );
  }
  // --- Fields ---
  async getFields() {
    return this.request("GET", "/rest/api/3/field");
  }
  async getFieldOptions(fieldId, contextId) {
    return this.request("GET", `/rest/api/3/field/${fieldId}/context/${contextId}/option`);
  }
  // --- Comments ---
  async addComment(issueKey, body) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/comment`, { body });
  }
  async editComment(issueKey, commentId, body) {
    return this.request("PUT", `/rest/api/3/issue/${issueKey}/comment/${commentId}`, { body });
  }
  // --- Transitions ---
  async getTransitions(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/transitions`);
  }
  async transitionIssue(issueKey, transitionId) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/transitions`, {
      transition: { id: transitionId }
    });
  }
  // --- Projects ---
  async getAllProjects() {
    return this.request("GET", "/rest/api/3/project");
  }
  async getProjectVersions(projectKey) {
    return this.request("GET", `/rest/api/3/project/${projectKey}/versions`);
  }
  async getProjectComponents(projectKey) {
    return this.request("GET", `/rest/api/3/project/${projectKey}/components`);
  }
  async createVersion(version) {
    return this.request("POST", "/rest/api/3/version", version);
  }
  // --- Agile ---
  async getBoards(startAt = 0, maxResults = 50) {
    return this.request("GET", `/rest/agile/1.0/board?startAt=${startAt}&maxResults=${maxResults}`);
  }
  async getBoardIssues(boardId, startAt = 0, maxResults = 50) {
    return this.request(
      "GET",
      `/rest/agile/1.0/board/${boardId}/issue?startAt=${startAt}&maxResults=${maxResults}`
    );
  }
  async getSprintsFromBoard(boardId, startAt = 0, maxResults = 50) {
    return this.request(
      "GET",
      `/rest/agile/1.0/board/${boardId}/sprint?startAt=${startAt}&maxResults=${maxResults}`
    );
  }
  async getSprintIssues(sprintId, startAt = 0, maxResults = 50) {
    return this.request(
      "GET",
      `/rest/agile/1.0/sprint/${sprintId}/issue?startAt=${startAt}&maxResults=${maxResults}`
    );
  }
  async createSprint(sprint) {
    return this.request("POST", "/rest/agile/1.0/sprint", sprint);
  }
  async updateSprint(sprintId, sprint) {
    return this.request("PUT", `/rest/agile/1.0/sprint/${sprintId}`, sprint);
  }
  async addIssuesToSprint(sprintId, issueKeys) {
    return this.request("POST", `/rest/agile/1.0/sprint/${sprintId}/issue`, {
      issues: issueKeys
    });
  }
  // --- Links ---
  async getLinkTypes() {
    return this.request("GET", "/rest/api/3/issueLinkType");
  }
  async linkToEpic(epicKey, issueKeys) {
    return this.request("PUT", `/rest/agile/1.0/epic/${epicKey}/issue`, {
      issues: issueKeys
    });
  }
  async createIssueLink(link) {
    return this.request("POST", "/rest/api/3/issueLink", link);
  }
  async createRemoteIssueLink(issueKey, remoteLink) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/remotelink`, remoteLink);
  }
  async removeIssueLink(linkId) {
    return this.request("DELETE", `/rest/api/3/issueLink/${linkId}`);
  }
  // --- Worklog ---
  async getWorklog(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/worklog`);
  }
  async addWorklog(issueKey, worklog) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/worklog`, worklog);
  }
  // --- Attachments ---
  async downloadAttachment(attachmentId) {
    return this.requestRaw("GET", `/rest/api/3/attachment/content/${attachmentId}`);
  }
  async getIssueForAttachments(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}?fields=attachment`);
  }
  // --- Users ---
  async getMyself() {
    return this.request("GET", "/rest/api/3/myself");
  }
  async getUser(accountId) {
    return this.request("GET", `/rest/api/3/user?accountId=${encodeURIComponent(accountId)}`);
  }
  // --- Watchers ---
  async getWatchers(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/watchers`);
  }
  async addWatcher(issueKey, accountId) {
    return this.request("POST", `/rest/api/3/issue/${issueKey}/watchers`, accountId);
  }
  async removeWatcher(issueKey, accountId) {
    return this.request(
      "DELETE",
      `/rest/api/3/issue/${issueKey}/watchers?accountId=${encodeURIComponent(accountId)}`
    );
  }
  // --- Service Desk ---
  async getServiceDesks() {
    return this.request("GET", "/rest/servicedeskapi/servicedesk");
  }
  async getServiceDeskQueues(serviceDeskId) {
    return this.request("GET", `/rest/servicedeskapi/servicedesk/${serviceDeskId}/queue`);
  }
  async getQueueIssues(serviceDeskId, queueId) {
    return this.request(
      "GET",
      `/rest/servicedeskapi/servicedesk/${serviceDeskId}/queue/${queueId}/issue`
    );
  }
  // --- Forms (Proforma) ---
  async getIssueProformaForms(issueKey) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/properties/proforma.forms`);
  }
  async getProformaFormDetails(issueKey, formId) {
    return this.request("GET", `/rest/api/3/issue/${issueKey}/properties/proforma.forms.${formId}`);
  }
  async updateProformaFormAnswers(issueKey, formId, answers) {
    return this.request(
      "PUT",
      `/rest/api/3/issue/${issueKey}/properties/proforma.forms.${formId}`,
      answers
    );
  }
  // --- Metrics ---
  async getIssueDateFields(issueKey) {
    return this.request(
      "GET",
      `/rest/api/3/issue/${issueKey}?fields=created,updated,resolutiondate,duedate`
    );
  }
  async getIssueSla(issueKey) {
    return this.request("GET", `/rest/servicedeskapi/request/${issueKey}/sla`);
  }
  // --- Development ---
  async getDevelopmentInfo(issueId, applicationType = "stash", dataType = "repository") {
    const params = new URLSearchParams({
      issueId,
      applicationType,
      dataType
    });
    return this.request("GET", `/rest/dev-status/1.0/issue/detail?${params.toString()}`);
  }
  async getDevelopmentSummary(issueId) {
    return this.request("GET", `/rest/dev-status/1.0/issue/summary?issueId=${issueId}`);
  }
  async getBatchDevelopmentInfo(issueIds, applicationType = "stash", dataType = "repository") {
    const results = [];
    for (const issueId of issueIds) {
      const data = await this.getDevelopmentInfo(issueId, applicationType, dataType);
      results.push(data);
    }
    return results;
  }
};

// src/shared/client.ts
function createClients(context) {
  const result = atlassianConfigSchema.safeParse(context.config);
  if (!result.success) {
    const details = result.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    throw new Error(
      `Invalid Atlassian config (${details}). Configure via: renre-kit ext config renre-atlassian --set domain=<company>.atlassian.net && renre-kit ext config renre-atlassian --set email=<user@company.com> && renre-kit vault set renre-atlassian.apiToken`
    );
  }
  const config = result.data;
  return {
    jira: new JiraClient(config),
    confluence: new ConfluenceClient(config)
  };
}

// src/shared/formatters.ts
function toOutput(data) {
  return {
    output: jsonToMarkdown(data, { filterNoise: true }),
    exitCode: 0
  };
}
function errorOutput(err) {
  const message = err instanceof Error ? err.message : String(err);
  return {
    output: message,
    exitCode: 1
  };
}

export {
  issueKeySchema,
  pageIdSchema,
  accountIdSchema,
  projectKeySchema,
  boardIdSchema,
  sprintIdSchema,
  createClients,
  toOutput,
  errorOutput
};
