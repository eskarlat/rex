import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  ZodError,
  createClients,
  errorOutput,
  toOutput
} from "./chunk-JIYXZLUF.js";

// src/shared/command-helper.ts
function formatZodError(err) {
  return err.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
}
async function jiraCommand(context, schema, fn) {
  try {
    const parsed = schema.parse(context.args);
    const { jira } = createClients(context);
    const data = await fn(jira, parsed);
    return toOutput(data);
  } catch (err) {
    if (err instanceof ZodError) {
      return errorOutput(new Error(`Invalid arguments: ${formatZodError(err)}`));
    }
    return errorOutput(err);
  }
}
async function confluenceCommand(context, schema, fn) {
  try {
    const parsed = schema.parse(context.args);
    const { confluence } = createClients(context);
    const data = await fn(confluence, parsed);
    return toOutput(data);
  } catch (err) {
    if (err instanceof ZodError) {
      return errorOutput(new Error(`Invalid arguments: ${formatZodError(err)}`));
    }
    return errorOutput(err);
  }
}

export {
  jiraCommand,
  confluenceCommand
};
