import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  createClients,
  errorOutput,
  toOutput
} from "./chunk-IVZ65HSR.js";

// src/shared/command-helper.ts
async function jiraCommand(context, fn) {
  try {
    const { jira } = createClients(context);
    const data = await fn(jira, context.args);
    return toOutput(data);
  } catch (err) {
    return errorOutput(err);
  }
}
async function confluenceCommand(context, fn) {
  try {
    const { confluence } = createClients(context);
    const data = await fn(confluence, context.args);
    return toOutput(data);
  } catch (err) {
    return errorOutput(err);
  }
}
function paginationArgs(args, defaults = { startAt: 0, maxResults: 50 }) {
  return {
    startAt: args["startAt"] ?? defaults.startAt,
    maxResults: args["maxResults"] ?? defaults.maxResults
  };
}
function confluencePaginationArgs(args, defaults = { start: 0, limit: 25 }) {
  return {
    start: args["start"] ?? defaults.start,
    limit: args["limit"] ?? defaults.limit
  };
}

export {
  jiraCommand,
  confluenceCommand,
  paginationArgs,
  confluencePaginationArgs
};
