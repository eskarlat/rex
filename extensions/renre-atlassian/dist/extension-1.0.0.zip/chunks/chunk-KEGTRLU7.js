import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  createClients,
  errorOutput,
  toJsonOutput,
  toOutput
} from "./chunk-7UH5QAIX.js";

// src/shared/command-helper.ts
function formatOutput(data, args) {
  return "json" in args && args.json ? toJsonOutput(data) : toOutput(data);
}
async function jiraCommand(context, fn) {
  try {
    const { jira } = createClients(context);
    const data = await fn(jira, context.args);
    return formatOutput(data, context.args);
  } catch (err) {
    return errorOutput(err);
  }
}
async function confluenceCommand(context, fn) {
  try {
    const { confluence } = createClients(context);
    const data = await fn(confluence, context.args);
    return formatOutput(data, context.args);
  } catch (err) {
    return errorOutput(err);
  }
}

export {
  jiraCommand,
  confluenceCommand
};
