import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  createClients,
  errorOutput,
  toOutput
} from "../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../chunks/chunk-GIJXU2QH.js";
import "../chunks/chunk-LWY6IOUG.js";

// src/commands/status.ts
var status_default = defineCommand({
  handler: async (ctx) => {
    try {
      const { jira } = createClients(ctx);
      const user = await jira.getMyself();
      return toOutput({
        connected: true,
        user,
        domain: ctx.config["domain"],
        jiraCommands: 50,
        confluenceCommands: 23,
        totalCommands: 75
      });
    } catch (err) {
      return errorOutput(err);
    }
  }
});
export {
  status_default as default
};
