import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  createClients,
  errorOutput,
  toOutput
} from "../chunks/chunk-IVZ65HSR.js";
import "../chunks/chunk-77GVX2VY.js";

// src/commands/status.ts
async function status(context) {
  try {
    const { jira } = createClients(context);
    const user = await jira.getMyself();
    return toOutput({
      connected: true,
      user,
      domain: context.config["domain"],
      jiraCommands: 50,
      confluenceCommands: 23,
      totalCommands: 75
    });
  } catch (err) {
    return errorOutput(err);
  }
}
export {
  status as default
};
