import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  pageIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/upload-attachment.ts
var upload_attachment_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    filename: external_exports.string().min(1),
    content: external_exports.string().min(1)
  },
  handler: (ctx) => confluenceCommand(
    ctx,
    (confluence, args) => confluence.uploadAttachment(args.pageId, args.filename, args.content)
  )
});
export {
  upload_attachment_default as default
};
