import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/upload-attachment.ts
var schema = external_exports.object({
  pageId: pageIdSchema,
  filename: external_exports.string().min(1),
  content: external_exports.string().min(1)
});
async function uploadAttachment(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.uploadAttachment(args.pageId, args.filename, args.content)
  );
}
export {
  uploadAttachment as default
};
