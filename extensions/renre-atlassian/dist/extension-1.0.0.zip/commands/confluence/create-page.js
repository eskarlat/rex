import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/create-page.ts
var create_page_default = defineCommand({
  args: {
    title: external_exports.string().min(1),
    spaceKey: external_exports.string().min(1),
    body: external_exports.string().min(1),
    parentId: external_exports.string().optional()
  },
  handler: (ctx) => confluenceCommand(ctx, (confluence, args) => {
    const page = {
      type: "page",
      title: args.title,
      space: { key: args.spaceKey },
      body: { storage: { value: args.body, representation: "storage" } }
    };
    if (args.parentId) page["ancestors"] = [{ id: args.parentId }];
    return confluence.createPage(page);
  })
});
export {
  create_page_default as default
};
