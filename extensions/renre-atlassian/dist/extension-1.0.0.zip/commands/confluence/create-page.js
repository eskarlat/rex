import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/create-page.ts
var schema = external_exports.object({
  title: external_exports.string().min(1),
  spaceKey: external_exports.string().min(1),
  body: external_exports.string().min(1),
  parentId: external_exports.string().optional()
});
async function createPage(context) {
  return confluenceCommand(context, schema, (confluence, args) => {
    const page = {
      type: "page",
      title: args.title,
      space: { key: args.spaceKey },
      body: { storage: { value: args.body, representation: "storage" } }
    };
    if (args.parentId) page["ancestors"] = [{ id: args.parentId }];
    return confluence.createPage(page);
  });
}
export {
  createPage as default
};
