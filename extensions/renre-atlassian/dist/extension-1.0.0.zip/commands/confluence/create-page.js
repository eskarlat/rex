import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/create-page.ts
async function createPage(context) {
  return confluenceCommand(context, (confluence, args) => {
    const page = {
      type: "page",
      title: args["title"],
      space: { key: args["spaceKey"] },
      body: { storage: { value: args["body"], representation: "storage" } }
    };
    if (args["parentId"]) page["ancestors"] = [{ id: args["parentId"] }];
    return confluence.createPage(page);
  });
}
export {
  createPage as default
};
