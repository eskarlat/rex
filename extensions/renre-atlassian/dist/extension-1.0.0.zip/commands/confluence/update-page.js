import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  pageIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/update-page.ts
var update_page_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    version: external_exports.coerce.number().int().positive(),
    title: external_exports.string().min(1),
    body: external_exports.string().min(1)
  },
  handler: (ctx) => confluenceCommand(
    ctx,
    (confluence, args) => confluence.updatePage(args.pageId, {
      type: "page",
      title: args.title,
      body: { storage: { value: args.body, representation: "storage" } },
      version: { number: args.version + 1 }
    })
  )
});
export {
  update_page_default as default
};
