import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/update-page.ts
var schema = external_exports.object({
  pageId: pageIdSchema,
  version: external_exports.coerce.number().int().positive(),
  title: external_exports.string().min(1),
  body: external_exports.string().min(1)
});
async function updatePage(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.updatePage(args.pageId, {
      type: "page",
      title: args.title,
      body: { storage: { value: args.body, representation: "storage" } },
      version: { number: args.version + 1 }
    })
  );
}
export {
  updatePage as default
};
