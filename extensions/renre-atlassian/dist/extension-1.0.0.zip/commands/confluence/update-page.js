import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/update-page.ts
async function updatePage(context) {
  return confluenceCommand(context, (confluence, args) => {
    const version = args["version"];
    return confluence.updatePage(args["pageId"], {
      type: "page",
      title: args["title"],
      body: { storage: { value: args["body"], representation: "storage" } },
      version: { number: version + 1 }
    });
  });
}
export {
  updatePage as default
};
