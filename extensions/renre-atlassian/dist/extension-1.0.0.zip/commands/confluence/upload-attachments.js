import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/upload-attachments.ts
var schema = external_exports.object({
  pageId: pageIdSchema,
  files: external_exports.array(external_exports.object({ filename: external_exports.string().min(1), content: external_exports.string() })).min(1)
});
async function uploadAttachments(context) {
  return confluenceCommand(context, schema, async (confluence, args) => {
    const results = [];
    for (const f of args.files) {
      results.push(await confluence.uploadAttachment(args.pageId, f.filename, f.content));
    }
    return results;
  });
}
export {
  uploadAttachments as default
};
