import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  pageIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/upload-attachments.ts
var upload_attachments_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    files: external_exports.array(external_exports.object({ filename: external_exports.string().min(1), content: external_exports.string() })).min(1)
  },
  handler: (ctx) => confluenceCommand(ctx, async (confluence, args) => {
    const results = [];
    for (const f of args.files) {
      results.push(await confluence.uploadAttachment(args.pageId, f.filename, f.content));
    }
    return results;
  })
});
export {
  upload_attachments_default as default
};
