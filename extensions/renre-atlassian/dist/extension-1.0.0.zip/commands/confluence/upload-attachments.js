import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/upload-attachments.ts
async function uploadAttachments(context) {
  return confluenceCommand(context, async (confluence, args) => {
    const pageId = args["pageId"];
    const files = args["files"];
    const results = [];
    for (const f of files) {
      results.push(await confluence.uploadAttachment(pageId, f.filename, f.content));
    }
    return results;
  });
}
export {
  uploadAttachments as default
};
