import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  pageIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page-history.ts
var get_page_history_default = defineCommand({
  args: {
    pageId: pageIdSchema
  },
  handler: (ctx) => confluenceCommand(ctx, (confluence, args) => confluence.getPageHistory(args.pageId))
});
export {
  get_page_history_default as default
};
