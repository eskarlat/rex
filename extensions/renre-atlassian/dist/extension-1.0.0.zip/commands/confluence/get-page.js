import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page.ts
var schema = external_exports.object({
  pageId: pageIdSchema,
  expand: external_exports.string().default("body.storage,version")
});
async function getPage(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.getPage(args.pageId, args.expand)
  );
}
export {
  getPage as default
};
