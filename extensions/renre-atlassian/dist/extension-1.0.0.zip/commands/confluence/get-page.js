import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  pageIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page.ts
var get_page_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    expand: external_exports.string().default("body.storage,version")
  },
  handler: (ctx) => confluenceCommand(ctx, (confluence, args) => confluence.getPage(args.pageId, args.expand))
});
export {
  get_page_default as default
};
