import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/get-page.ts
async function getPage(context) {
  return confluenceCommand(
    context,
    (confluence, args) => confluence.getPage(
      args["pageId"],
      args["expand"] ?? "body.storage,version"
    )
  );
}
export {
  getPage as default
};
