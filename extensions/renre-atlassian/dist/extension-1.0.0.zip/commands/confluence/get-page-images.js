import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/get-page-images.ts
async function getPageImages(context) {
  return confluenceCommand(
    context,
    (confluence, args) => confluence.getPageImages(args["pageId"])
  );
}
export {
  getPageImages as default
};
