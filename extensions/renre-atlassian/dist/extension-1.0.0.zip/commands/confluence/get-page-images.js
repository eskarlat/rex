import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  pageIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page-images.ts
var get_page_images_default = defineCommand({
  args: {
    pageId: pageIdSchema
  },
  handler: (ctx) => confluenceCommand(ctx, (confluence, args) => confluence.getPageImages(args.pageId))
});
export {
  get_page_images_default as default
};
