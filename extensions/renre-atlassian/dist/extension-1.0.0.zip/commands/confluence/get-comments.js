import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand,
  confluencePaginationArgs
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/get-comments.ts
async function getComments(context) {
  return confluenceCommand(context, (confluence, args) => {
    const { start, limit } = confluencePaginationArgs(args);
    return confluence.getComments(args["pageId"], limit, start);
  });
}
export {
  getComments as default
};
