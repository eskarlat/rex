import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/delete-page.ts
async function deletePage(context) {
  return confluenceCommand(context, async (confluence, args) => {
    const pageId = args["pageId"];
    await confluence.deletePage(pageId);
    return { success: true, pageId };
  });
}
export {
  deletePage as default
};
