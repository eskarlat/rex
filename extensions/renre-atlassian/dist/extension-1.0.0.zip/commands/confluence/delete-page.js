import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/delete-page.ts
var schema = external_exports.object({ pageId: pageIdSchema });
async function deletePage(context) {
  return confluenceCommand(context, schema, async (confluence, args) => {
    await confluence.deletePage(args.pageId);
    return { success: true, pageId: args.pageId };
  });
}
export {
  deletePage as default
};
