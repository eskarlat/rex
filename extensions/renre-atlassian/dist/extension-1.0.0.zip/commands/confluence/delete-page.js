import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  pageIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/delete-page.ts
var delete_page_default = defineCommand({
  args: {
    pageId: pageIdSchema
  },
  handler: (ctx) => confluenceCommand(ctx, async (confluence, args) => {
    await confluence.deletePage(args.pageId);
    return { success: true, pageId: args.pageId };
  })
});
export {
  delete_page_default as default
};
