import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/delete-attachment.ts
var schema = external_exports.object({ attachmentId: external_exports.string().min(1) });
async function deleteAttachment(context) {
  return confluenceCommand(context, schema, async (confluence, args) => {
    await confluence.deleteAttachment(args.attachmentId);
    return { success: true, attachmentId: args.attachmentId };
  });
}
export {
  deleteAttachment as default
};
