import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/delete-attachment.ts
async function deleteAttachment(context) {
  return confluenceCommand(context, async (confluence, args) => {
    const attachmentId = args["attachmentId"];
    await confluence.deleteAttachment(attachmentId);
    return { success: true, attachmentId };
  });
}
export {
  deleteAttachment as default
};
