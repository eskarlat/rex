import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/delete-attachment.ts
var delete_attachment_default = defineCommand({
  args: {
    attachmentId: external_exports.string().min(1)
  },
  handler: (ctx) => confluenceCommand(ctx, async (confluence, args) => {
    await confluence.deleteAttachment(args.attachmentId);
    return { success: true, attachmentId: args.attachmentId };
  })
});
export {
  delete_attachment_default as default
};
