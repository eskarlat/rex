import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-labels.ts
var schema = external_exports.object({ pageId: pageIdSchema });
async function getLabels(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.getLabels(args.pageId)
  );
}
export {
  getLabels as default
};
