import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  pageIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-labels.ts
var get_labels_default = defineCommand({
  args: {
    pageId: pageIdSchema
  },
  handler: (ctx) => confluenceCommand(ctx, (confluence, args) => confluence.getLabels(args.pageId))
});
export {
  get_labels_default as default
};
