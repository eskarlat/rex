import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  pageIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/add-label.ts
var add_label_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    labels: external_exports.array(external_exports.string()).min(1)
  },
  handler: (ctx) => confluenceCommand(
    ctx,
    (confluence, args) => confluence.addLabel(
      args.pageId,
      args.labels.map((name) => ({ name }))
    )
  )
});
export {
  add_label_default as default
};
