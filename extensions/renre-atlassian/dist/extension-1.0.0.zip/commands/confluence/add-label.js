import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/add-label.ts
async function addLabel(context) {
  return confluenceCommand(context, (confluence, args) => {
    const labelNames = args["labels"];
    return confluence.addLabel(
      args["pageId"],
      labelNames.map((name) => ({ name }))
    );
  });
}
export {
  addLabel as default
};
