import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  pageIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/add-comment.ts
var add_comment_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    body: external_exports.string().min(1)
  },
  handler: (ctx) => confluenceCommand(ctx, (confluence, args) => confluence.addComment(args.pageId, args.body))
});
export {
  add_comment_default as default
};
