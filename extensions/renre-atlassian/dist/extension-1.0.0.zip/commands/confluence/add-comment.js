import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/add-comment.ts
var schema = external_exports.object({ pageId: pageIdSchema, body: external_exports.string().min(1) });
async function addComment(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.addComment(args.pageId, args.body)
  );
}
export {
  addComment as default
};
