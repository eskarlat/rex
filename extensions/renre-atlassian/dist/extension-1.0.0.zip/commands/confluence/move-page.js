import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/move-page.ts
async function movePage(context) {
  return confluenceCommand(
    context,
    (confluence, args) => confluence.movePage(
      args["pageId"],
      args["targetAncestorId"],
      args["currentVersion"]
    )
  );
}
export {
  movePage as default
};
