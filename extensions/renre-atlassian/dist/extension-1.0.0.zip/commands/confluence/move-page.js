import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  pageIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/move-page.ts
var move_page_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    targetAncestorId: external_exports.string().min(1),
    currentVersion: external_exports.coerce.number().int().positive()
  },
  handler: (ctx) => confluenceCommand(
    ctx,
    (confluence, args) => confluence.movePage(args.pageId, args.targetAncestorId, args.currentVersion)
  )
});
export {
  move_page_default as default
};
