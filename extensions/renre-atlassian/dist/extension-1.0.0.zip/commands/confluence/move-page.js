import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/move-page.ts
var schema = external_exports.object({
  pageId: pageIdSchema,
  targetAncestorId: external_exports.string().min(1),
  currentVersion: external_exports.coerce.number().int().positive()
});
async function movePage(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.movePage(args.pageId, args.targetAncestorId, args.currentVersion)
  );
}
export {
  movePage as default
};
