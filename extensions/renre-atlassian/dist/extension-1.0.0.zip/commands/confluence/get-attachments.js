import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand,
  confluencePaginationArgs
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/get-attachments.ts
async function getAttachments(context) {
  return confluenceCommand(context, (confluence, args) => {
    const { start, limit } = confluencePaginationArgs(args);
    return confluence.getAttachments(args["pageId"], limit, start);
  });
}
export {
  getAttachments as default
};
