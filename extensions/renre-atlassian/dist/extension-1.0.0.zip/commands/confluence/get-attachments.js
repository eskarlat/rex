import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  pageIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-attachments.ts
var get_attachments_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    start: external_exports.coerce.number().int().min(0).default(0),
    limit: external_exports.coerce.number().int().min(1).max(100).default(25)
  },
  handler: (ctx) => confluenceCommand(
    ctx,
    (confluence, args) => confluence.getAttachments(args.pageId, args.limit, args.start)
  )
});
export {
  get_attachments_default as default
};
