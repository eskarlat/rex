import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  confluencePaginationSchema,
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page-children.ts
var schema = external_exports.object({ pageId: pageIdSchema }).merge(confluencePaginationSchema);
async function getPageChildren(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.getPageChildren(args.pageId, args.limit, args.start)
  );
}
export {
  getPageChildren as default
};
