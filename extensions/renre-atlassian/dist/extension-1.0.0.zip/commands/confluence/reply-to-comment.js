import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/reply-to-comment.ts
var schema = external_exports.object({
  pageId: pageIdSchema,
  parentCommentId: external_exports.string().min(1),
  body: external_exports.string().min(1)
});
async function replyToComment(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.replyToComment(args.pageId, args.parentCommentId, args.body)
  );
}
export {
  replyToComment as default
};
