import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  pageIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/reply-to-comment.ts
var reply_to_comment_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    parentCommentId: external_exports.string().min(1),
    body: external_exports.string().min(1)
  },
  handler: (ctx) => confluenceCommand(
    ctx,
    (confluence, args) => confluence.replyToComment(args.pageId, args.parentCommentId, args.body)
  )
});
export {
  reply_to_comment_default as default
};
