import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page-views.ts
var schema = external_exports.object({ pageId: pageIdSchema, fromDate: external_exports.string().optional() });
async function getPageViews(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.getPageViews(args.pageId, args.fromDate)
  );
}
export {
  getPageViews as default
};
