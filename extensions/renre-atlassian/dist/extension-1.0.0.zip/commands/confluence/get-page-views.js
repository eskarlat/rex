import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  pageIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page-views.ts
var get_page_views_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    fromDate: external_exports.string().optional()
  },
  handler: (ctx) => confluenceCommand(
    ctx,
    (confluence, args) => confluence.getPageViews(args.pageId, args.fromDate)
  )
});
export {
  get_page_views_default as default
};
