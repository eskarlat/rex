import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/download-attachment.ts
var schema = external_exports.object({ pageId: pageIdSchema, filename: external_exports.string().min(1) });
async function downloadAttachment(context) {
  return confluenceCommand(context, schema, async (confluence, args) => {
    const res = await confluence.downloadAttachment(args.pageId, args.filename);
    const text = await res.text();
    return { pageId: args.pageId, filename: args.filename, content: text };
  });
}
export {
  downloadAttachment as default
};
