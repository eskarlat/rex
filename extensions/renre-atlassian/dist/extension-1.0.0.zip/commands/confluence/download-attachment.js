import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/download-attachment.ts
async function downloadAttachment(context) {
  return confluenceCommand(context, async (confluence, args) => {
    const pageId = args["pageId"];
    const filename = args["filename"];
    const res = await confluence.downloadAttachment(pageId, filename);
    const text = await res.text();
    return { pageId, filename, content: text };
  });
}
export {
  downloadAttachment as default
};
