import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  pageIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/download-attachment.ts
var download_attachment_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    filename: external_exports.string().min(1)
  },
  handler: (ctx) => confluenceCommand(ctx, async (confluence, args) => {
    const res = await confluence.downloadAttachment(args.pageId, args.filename);
    const text = await res.text();
    return { pageId: args.pageId, filename: args.filename, content: text };
  })
});
export {
  download_attachment_default as default
};
