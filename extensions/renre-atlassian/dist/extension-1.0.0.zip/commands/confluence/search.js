import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/search.ts
var search_default = defineCommand({
  args: {
    cql: external_exports.string().min(1, "CQL query is required"),
    start: external_exports.coerce.number().int().min(0).default(0),
    limit: external_exports.coerce.number().int().min(1).max(100).default(25)
  },
  handler: (ctx) => confluenceCommand(
    ctx,
    (confluence, args) => confluence.search(args.cql, args.limit, args.start)
  )
});
export {
  search_default as default
};
