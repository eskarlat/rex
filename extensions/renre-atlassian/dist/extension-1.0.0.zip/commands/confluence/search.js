import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  confluencePaginationSchema,
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/search.ts
var schema = external_exports.object({ cql: external_exports.string().min(1, "CQL query is required") }).merge(confluencePaginationSchema);
async function search(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.search(args.cql, args.limit, args.start)
  );
}
export {
  search as default
};
