import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand,
  confluencePaginationArgs
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/search.ts
async function search(context) {
  return confluenceCommand(context, (confluence, args) => {
    const { start, limit } = confluencePaginationArgs(args);
    return confluence.search(args["cql"], limit, start);
  });
}
export {
  search as default
};
