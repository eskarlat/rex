import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/get-page-diff.ts
function extractStorageValue(page) {
  const record = page;
  const bodyStorage = record["body"];
  const storage = bodyStorage?.["storage"];
  return storage?.["value"] ?? "";
}
async function getPageDiff(context) {
  return confluenceCommand(context, async (confluence, args) => {
    const pageId = args["pageId"];
    const fromVersion = args["fromVersion"];
    const toVersion = args["toVersion"];
    const [fromPage, toPage] = await Promise.all([
      confluence.getPageVersion(pageId, fromVersion),
      confluence.getPageVersion(pageId, toVersion)
    ]);
    return { pageId, fromVersion, toVersion, from: extractStorageValue(fromPage), to: extractStorageValue(toPage) };
  });
}
export {
  getPageDiff as default
};
