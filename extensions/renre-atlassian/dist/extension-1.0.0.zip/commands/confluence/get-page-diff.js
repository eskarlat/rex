import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  pageIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page-diff.ts
var schema = external_exports.object({
  pageId: pageIdSchema,
  fromVersion: external_exports.coerce.number().int().positive(),
  toVersion: external_exports.coerce.number().int().positive()
});
function extractStorageValue(page) {
  const record = page;
  const bodyStorage = record["body"];
  const storage = bodyStorage?.["storage"];
  return storage?.["value"] ?? "";
}
async function getPageDiff(context) {
  return confluenceCommand(context, schema, async (confluence, args) => {
    const [fromPage, toPage] = await Promise.all([
      confluence.getPageVersion(args.pageId, args.fromVersion),
      confluence.getPageVersion(args.pageId, args.toVersion)
    ]);
    return {
      pageId: args.pageId,
      fromVersion: args.fromVersion,
      toVersion: args.toVersion,
      from: extractStorageValue(fromPage),
      to: extractStorageValue(toPage)
    };
  });
}
export {
  getPageDiff as default
};
