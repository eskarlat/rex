import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  pageIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/get-page-diff.ts
function extractStorageValue(page) {
  const record = page;
  const bodyStorage = record["body"];
  const storage = bodyStorage?.["storage"];
  return storage?.["value"] ?? "";
}
var get_page_diff_default = defineCommand({
  args: {
    pageId: pageIdSchema,
    fromVersion: external_exports.coerce.number().int().positive(),
    toVersion: external_exports.coerce.number().int().positive()
  },
  handler: (ctx) => confluenceCommand(ctx, async (confluence, args) => {
    const [fromPage, toPage] = await Promise.all([
      confluence.getPageVersion(args.pageId, args.fromVersion),
      confluence.getPageVersion(args.pageId, args.toVersion)
    ]);
    return {
      pageId: args.pageId,
      fromVersion: args.fromVersion,
      toVersion: args.toVersion,
      from: extractStorageValue(fromPage),
      to: extractStorageValue(toPage)
    };
  })
});
export {
  get_page_diff_default as default
};
