import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/search-user.ts
var schema = external_exports.object({ query: external_exports.string().min(1) });
async function searchUser(context) {
  return confluenceCommand(
    context,
    schema,
    (confluence, args) => confluence.searchUser(args.query)
  );
}
export {
  searchUser as default
};
