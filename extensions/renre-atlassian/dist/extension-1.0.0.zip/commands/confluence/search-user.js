import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/confluence/search-user.ts
var search_user_default = defineCommand({
  args: {
    query: external_exports.string().min(1)
  },
  handler: (ctx) => confluenceCommand(ctx, (confluence, args) => confluence.searchUser(args.query))
});
export {
  search_user_default as default
};
