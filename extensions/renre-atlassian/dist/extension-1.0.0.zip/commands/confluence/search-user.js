import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  confluenceCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/confluence/search-user.ts
async function searchUser(context) {
  return confluenceCommand(
    context,
    (confluence, args) => confluence.searchUser(args["query"])
  );
}
export {
  searchUser as default
};
