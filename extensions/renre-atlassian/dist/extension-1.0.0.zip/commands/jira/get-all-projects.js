import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-all-projects.ts
var get_all_projects_default = defineCommand({
  handler: (ctx) => jiraCommand(ctx, (jira) => jira.getAllProjects())
});
export {
  get_all_projects_default as default
};
