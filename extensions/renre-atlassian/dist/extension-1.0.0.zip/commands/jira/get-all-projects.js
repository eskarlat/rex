import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-all-projects.ts
async function getAllProjects(context) {
  return jiraCommand(context, (jira) => jira.getAllProjects());
}
export {
  getAllProjects as default
};
