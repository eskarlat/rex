import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-all-projects.ts
var schema = external_exports.object({});
async function getAllProjects(context) {
  return jiraCommand(context, schema, (jira) => jira.getAllProjects());
}
export {
  getAllProjects as default
};
