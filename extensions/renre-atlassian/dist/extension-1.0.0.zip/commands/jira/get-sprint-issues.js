import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  paginationSchema,
  sprintIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-sprint-issues.ts
var schema = external_exports.object({
  sprintId: sprintIdSchema
}).merge(paginationSchema);
async function getSprintIssues(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getSprintIssues(args.sprintId, args.startAt, args.maxResults)
  );
}
export {
  getSprintIssues as default
};
