import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  sprintIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-sprint-issues.ts
var get_sprint_issues_default = defineCommand({
  args: {
    sprintId: sprintIdSchema,
    startAt: external_exports.coerce.number().int().min(0).default(0),
    maxResults: external_exports.coerce.number().int().min(1).max(100).default(50)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getSprintIssues(args.sprintId, args.startAt, args.maxResults))
});
export {
  get_sprint_issues_default as default
};
