import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/create-sprint.ts
async function createSprint(context) {
  return jiraCommand(context, (jira, args) => {
    const sprint = {
      originBoardId: args["boardId"],
      name: args["name"]
    };
    if (args["startDate"]) sprint.startDate = args["startDate"];
    if (args["endDate"]) sprint.endDate = args["endDate"];
    if (args["goal"]) sprint.goal = args["goal"];
    return jira.createSprint(sprint);
  });
}
export {
  createSprint as default
};
