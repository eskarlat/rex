import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  boardIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-sprint.ts
var create_sprint_default = defineCommand({
  args: {
    boardId: boardIdSchema,
    name: external_exports.string().min(1),
    startDate: external_exports.string().optional(),
    endDate: external_exports.string().optional(),
    goal: external_exports.string().optional()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => {
    const sprint = {
      originBoardId: args.boardId,
      name: args.name
    };
    if (args.startDate) sprint.startDate = args.startDate;
    if (args.endDate) sprint.endDate = args.endDate;
    if (args.goal) sprint.goal = args.goal;
    return jira.createSprint(sprint);
  })
});
export {
  create_sprint_default as default
};
