import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  boardIdSchema,
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-sprint.ts
var schema = external_exports.object({
  boardId: boardIdSchema,
  name: external_exports.string().min(1),
  startDate: external_exports.string().optional(),
  endDate: external_exports.string().optional(),
  goal: external_exports.string().optional()
});
async function createSprint(context) {
  return jiraCommand(context, schema, (jira, args) => {
    const sprint = {
      originBoardId: args.boardId,
      name: args.name
    };
    if (args.startDate) sprint.startDate = args.startDate;
    if (args.endDate) sprint.endDate = args.endDate;
    if (args.goal) sprint.goal = args.goal;
    return jira.createSprint(sprint);
  });
}
export {
  createSprint as default
};
