import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  boardIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-sprints-from-board.ts
var get_sprints_from_board_default = defineCommand({
  args: {
    boardId: boardIdSchema,
    startAt: external_exports.coerce.number().int().min(0).default(0),
    maxResults: external_exports.coerce.number().int().min(1).max(100).default(50)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getSprintsFromBoard(args.boardId, args.startAt, args.maxResults))
});
export {
  get_sprints_from_board_default as default
};
