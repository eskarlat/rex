import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand,
  paginationArgs
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-sprints-from-board.ts
async function getSprintsFromBoard(context) {
  return jiraCommand(context, (jira, args) => {
    const { startAt, maxResults } = paginationArgs(args);
    return jira.getSprintsFromBoard(args["boardId"], startAt, maxResults);
  });
}
export {
  getSprintsFromBoard as default
};
