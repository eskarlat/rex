import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/delete-issue.ts
async function deleteIssue(context) {
  return jiraCommand(context, async (jira, args) => {
    const issueKey = args["issueKey"];
    await jira.deleteIssue(issueKey);
    return { success: true, issueKey };
  });
}
export {
  deleteIssue as default
};
