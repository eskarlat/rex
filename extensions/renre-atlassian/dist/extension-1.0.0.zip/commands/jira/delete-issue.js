import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  issueKeySchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/delete-issue.ts
var delete_issue_default = defineCommand({
  args: {
    issueKey: issueKeySchema
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.deleteIssue(args.issueKey);
    return { success: true, issueKey: args.issueKey };
  })
});
export {
  delete_issue_default as default
};
