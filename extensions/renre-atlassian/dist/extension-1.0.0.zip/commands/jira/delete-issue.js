import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/delete-issue.ts
var schema = external_exports.object({
  issueKey: issueKeySchema
});
async function deleteIssue(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.deleteIssue(args.issueKey);
    return { success: true, issueKey: args.issueKey };
  });
}
export {
  deleteIssue as default
};
