import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-service-desk-queues.ts
async function getServiceDeskQueues(context) {
  return jiraCommand(
    context,
    (jira, args) => jira.getServiceDeskQueues(args["serviceDeskId"])
  );
}
export {
  getServiceDeskQueues as default
};
