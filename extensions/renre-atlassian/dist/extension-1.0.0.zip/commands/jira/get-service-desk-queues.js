import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-service-desk-queues.ts
var schema = external_exports.object({
  serviceDeskId: external_exports.coerce.number().int().positive()
});
async function getServiceDeskQueues(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getServiceDeskQueues(args.serviceDeskId)
  );
}
export {
  getServiceDeskQueues as default
};
