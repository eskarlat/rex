import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-service-desk-queues.ts
var get_service_desk_queues_default = defineCommand({
  args: {
    serviceDeskId: external_exports.coerce.number().int().positive()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getServiceDeskQueues(args.serviceDeskId))
});
export {
  get_service_desk_queues_default as default
};
