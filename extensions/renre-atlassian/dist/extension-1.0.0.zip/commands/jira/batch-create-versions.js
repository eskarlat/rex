import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/batch-create-versions.ts
async function batchCreateVersions(context) {
  return jiraCommand(context, async (jira, args) => {
    const projectKey = args["projectKey"];
    const versions = args["versions"];
    const results = [];
    for (const v of versions) {
      results.push(await jira.createVersion({ project: projectKey, ...v }));
    }
    return results;
  });
}
export {
  batchCreateVersions as default
};
