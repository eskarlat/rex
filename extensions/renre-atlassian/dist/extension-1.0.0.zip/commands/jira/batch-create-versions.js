import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  projectKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/batch-create-versions.ts
var batch_create_versions_default = defineCommand({
  args: {
    projectKey: projectKeySchema,
    versions: external_exports.array(external_exports.record(external_exports.unknown())).min(1)
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    const results = [];
    for (const v of args.versions) {
      results.push(await jira.createVersion({ project: args.projectKey, ...v }));
    }
    return results;
  })
});
export {
  batch_create_versions_default as default
};
