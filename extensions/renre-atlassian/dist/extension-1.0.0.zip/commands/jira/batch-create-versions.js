import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  projectKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/batch-create-versions.ts
var schema = external_exports.object({
  projectKey: projectKeySchema,
  versions: external_exports.array(external_exports.record(external_exports.unknown())).min(1)
});
async function batchCreateVersions(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    const results = [];
    for (const v of args.versions) {
      results.push(await jira.createVersion({ project: args.projectKey, ...v }));
    }
    return results;
  });
}
export {
  batchCreateVersions as default
};
