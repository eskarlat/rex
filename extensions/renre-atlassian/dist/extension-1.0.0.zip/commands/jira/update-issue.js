import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  issueKeySchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/update-issue.ts
var update_issue_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    fields: external_exports.record(external_exports.unknown()).refine(
      (obj) => Object.keys(obj).length > 0,
      "fields must not be empty"
    )
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.updateIssue(args.issueKey, args.fields);
    return { success: true, issueKey: args.issueKey };
  })
});
export {
  update_issue_default as default
};
