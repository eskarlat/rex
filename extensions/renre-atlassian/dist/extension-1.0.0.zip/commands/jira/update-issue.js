import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/update-issue.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  fields: external_exports.record(external_exports.unknown()).refine(
    (obj) => Object.keys(obj).length > 0,
    "fields must not be empty"
  )
});
async function updateIssue(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.updateIssue(args.issueKey, args.fields);
    return { success: true, issueKey: args.issueKey };
  });
}
export {
  updateIssue as default
};
