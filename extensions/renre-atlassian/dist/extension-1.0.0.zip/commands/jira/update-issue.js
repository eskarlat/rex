import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/update-issue.ts
async function updateIssue(context) {
  return jiraCommand(context, async (jira, args) => {
    const issueKey = args["issueKey"];
    await jira.updateIssue(issueKey, args["fields"]);
    return { success: true, issueKey };
  });
}
export {
  updateIssue as default
};
