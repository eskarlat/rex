import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-queue-issues.ts
async function getQueueIssues(context) {
  return jiraCommand(
    context,
    (jira, args) => jira.getQueueIssues(args["serviceDeskId"], args["queueId"])
  );
}
export {
  getQueueIssues as default
};
