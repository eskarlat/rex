import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-queue-issues.ts
var get_queue_issues_default = defineCommand({
  args: {
    serviceDeskId: external_exports.coerce.number().int().positive(),
    queueId: external_exports.coerce.number().int().positive()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getQueueIssues(args.serviceDeskId, args.queueId))
});
export {
  get_queue_issues_default as default
};
