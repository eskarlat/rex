import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-batch-dev-info.ts
async function getBatchDevInfo(context) {
  return jiraCommand(
    context,
    (jira, args) => jira.getBatchDevelopmentInfo(
      args["issueIds"],
      args["applicationType"],
      args["dataType"]
    )
  );
}
export {
  getBatchDevInfo as default
};
