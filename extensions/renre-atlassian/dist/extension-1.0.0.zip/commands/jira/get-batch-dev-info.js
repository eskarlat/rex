import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-batch-dev-info.ts
var schema = external_exports.object({
  issueIds: external_exports.array(external_exports.string()).min(1),
  applicationType: external_exports.string().optional(),
  dataType: external_exports.string().optional()
});
async function getBatchDevInfo(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getBatchDevelopmentInfo(args.issueIds, args.applicationType, args.dataType)
  );
}
export {
  getBatchDevInfo as default
};
