import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/create-version.ts
async function createVersion(context) {
  return jiraCommand(context, (jira, args) => {
    const version = {
      project: args["projectKey"],
      name: args["name"]
    };
    if (args["description"]) version.description = args["description"];
    if (args["releaseDate"]) version.releaseDate = args["releaseDate"];
    return jira.createVersion(version);
  });
}
export {
  createVersion as default
};
