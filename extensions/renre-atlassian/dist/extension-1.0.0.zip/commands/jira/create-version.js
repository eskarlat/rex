import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  projectKeySchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-version.ts
var create_version_default = defineCommand({
  args: {
    projectKey: projectKeySchema,
    name: external_exports.string().min(1),
    description: external_exports.string().optional(),
    releaseDate: external_exports.string().optional()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => {
    const version = {
      project: args.projectKey,
      name: args.name
    };
    if (args.description) version.description = args.description;
    if (args.releaseDate) version.releaseDate = args.releaseDate;
    return jira.createVersion(version);
  })
});
export {
  create_version_default as default
};
