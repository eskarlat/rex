import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  projectKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-version.ts
var schema = external_exports.object({
  projectKey: projectKeySchema,
  name: external_exports.string().min(1),
  description: external_exports.string().optional(),
  releaseDate: external_exports.string().optional()
});
async function createVersion(context) {
  return jiraCommand(context, schema, (jira, args) => {
    const version = {
      project: args.projectKey,
      name: args.name
    };
    if (args.description) version.description = args.description;
    if (args.releaseDate) version.releaseDate = args.releaseDate;
    return jira.createVersion(version);
  });
}
export {
  createVersion as default
};
