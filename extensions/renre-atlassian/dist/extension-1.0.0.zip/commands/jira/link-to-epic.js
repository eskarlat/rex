import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/link-to-epic.ts
var link_to_epic_default = defineCommand({
  args: {
    epicKey: external_exports.string().min(1),
    issueKeys: external_exports.array(external_exports.string()).min(1)
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.linkToEpic(args.epicKey, args.issueKeys);
    return { success: true };
  })
});
export {
  link_to_epic_default as default
};
