import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/link-to-epic.ts
async function linkToEpic(context) {
  return jiraCommand(context, async (jira, args) => {
    await jira.linkToEpic(args["epicKey"], args["issueKeys"]);
    return { success: true };
  });
}
export {
  linkToEpic as default
};
