import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/link-to-epic.ts
var schema = external_exports.object({
  epicKey: external_exports.string().min(1),
  issueKeys: external_exports.array(external_exports.string()).min(1)
});
async function linkToEpic(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.linkToEpic(args.epicKey, args.issueKeys);
    return { success: true };
  });
}
export {
  linkToEpic as default
};
