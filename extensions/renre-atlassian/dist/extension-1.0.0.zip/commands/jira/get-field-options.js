import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-field-options.ts
async function getFieldOptions(context) {
  return jiraCommand(
    context,
    (jira, args) => jira.getFieldOptions(args["fieldId"], args["contextId"])
  );
}
export {
  getFieldOptions as default
};
