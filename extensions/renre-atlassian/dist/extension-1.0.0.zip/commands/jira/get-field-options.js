import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-field-options.ts
var schema = external_exports.object({
  fieldId: external_exports.string().min(1),
  contextId: external_exports.string().min(1)
});
async function getFieldOptions(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getFieldOptions(args.fieldId, args.contextId)
  );
}
export {
  getFieldOptions as default
};
