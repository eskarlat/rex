import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-field-options.ts
var get_field_options_default = defineCommand({
  args: {
    fieldId: external_exports.string().min(1),
    contextId: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getFieldOptions(args.fieldId, args.contextId))
});
export {
  get_field_options_default as default
};
