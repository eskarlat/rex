import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  accountIdSchema,
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/remove-watcher.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  accountId: accountIdSchema
});
async function removeWatcher(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.removeWatcher(args.issueKey, args.accountId);
    return { success: true };
  });
}
export {
  removeWatcher as default
};
