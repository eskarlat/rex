import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/remove-watcher.ts
async function removeWatcher(context) {
  return jiraCommand(context, async (jira, args) => {
    await jira.removeWatcher(args["issueKey"], args["accountId"]);
    return { success: true };
  });
}
export {
  removeWatcher as default
};
