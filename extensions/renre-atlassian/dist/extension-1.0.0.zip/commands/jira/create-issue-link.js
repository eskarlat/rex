import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/create-issue-link.ts
async function createIssueLink(context) {
  return jiraCommand(context, async (jira, args) => {
    await jira.createIssueLink({
      type: { name: args["typeName"] },
      inwardIssue: { key: args["inwardIssueKey"] },
      outwardIssue: { key: args["outwardIssueKey"] }
    });
    return { success: true };
  });
}
export {
  createIssueLink as default
};
