import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-issue-link.ts
var create_issue_link_default = defineCommand({
  args: {
    typeName: external_exports.string().min(1),
    inwardIssueKey: external_exports.string().min(1),
    outwardIssueKey: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.createIssueLink({
      type: { name: args.typeName },
      inwardIssue: { key: args.inwardIssueKey },
      outwardIssue: { key: args.outwardIssueKey }
    });
    return { success: true };
  })
});
export {
  create_issue_link_default as default
};
