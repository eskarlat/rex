import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-issue-link.ts
var schema = external_exports.object({
  typeName: external_exports.string().min(1),
  inwardIssueKey: external_exports.string().min(1),
  outwardIssueKey: external_exports.string().min(1)
});
async function createIssueLink(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.createIssueLink({
      type: { name: args.typeName },
      inwardIssue: { key: args.inwardIssueKey },
      outwardIssue: { key: args.outwardIssueKey }
    });
    return { success: true };
  });
}
export {
  createIssueLink as default
};
