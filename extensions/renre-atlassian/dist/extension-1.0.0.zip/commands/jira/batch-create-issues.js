import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/batch-create-issues.ts
var batch_create_issues_default = defineCommand({
  args: {
    issues: external_exports.array(external_exports.object({ fields: external_exports.record(external_exports.unknown()) })).min(1)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.bulkCreateIssues(args.issues))
});
export {
  batch_create_issues_default as default
};
