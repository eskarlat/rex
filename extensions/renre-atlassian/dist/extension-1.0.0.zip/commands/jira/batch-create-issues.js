import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/batch-create-issues.ts
var schema = external_exports.object({
  issues: external_exports.array(external_exports.object({ fields: external_exports.record(external_exports.unknown()) })).min(1)
});
async function batchCreateIssues(context) {
  return jiraCommand(context, schema, (jira, args) => jira.bulkCreateIssues(args.issues));
}
export {
  batchCreateIssues as default
};
