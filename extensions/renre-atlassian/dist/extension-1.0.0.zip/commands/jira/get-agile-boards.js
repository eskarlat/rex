import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  paginationSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-agile-boards.ts
var schema = paginationSchema;
async function getAgileBoards(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getBoards(args.startAt, args.maxResults)
  );
}
export {
  getAgileBoards as default
};
