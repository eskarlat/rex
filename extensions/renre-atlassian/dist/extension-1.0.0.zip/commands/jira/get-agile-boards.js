import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-agile-boards.ts
var get_agile_boards_default = defineCommand({
  args: {
    startAt: external_exports.coerce.number().int().min(0).default(0),
    maxResults: external_exports.coerce.number().int().min(1).max(100).default(50)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getBoards(args.startAt, args.maxResults))
});
export {
  get_agile_boards_default as default
};
