import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-form-details.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  formId: external_exports.string().min(1)
});
async function getFormDetails(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getProformaFormDetails(args.issueKey, args.formId)
  );
}
export {
  getFormDetails as default
};
