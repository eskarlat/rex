import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-form-details.ts
var get_form_details_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    formId: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getProformaFormDetails(args.issueKey, args.formId))
});
export {
  get_form_details_default as default
};
