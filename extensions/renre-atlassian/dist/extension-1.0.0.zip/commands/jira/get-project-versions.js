import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  projectKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-project-versions.ts
var get_project_versions_default = defineCommand({
  args: {
    projectKey: projectKeySchema
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getProjectVersions(args.projectKey))
});
export {
  get_project_versions_default as default
};
