import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  projectKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-project-versions.ts
var schema = external_exports.object({
  projectKey: projectKeySchema
});
async function getProjectVersions(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getProjectVersions(args.projectKey)
  );
}
export {
  getProjectVersions as default
};
