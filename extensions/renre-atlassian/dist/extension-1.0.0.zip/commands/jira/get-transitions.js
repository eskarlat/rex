import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-transitions.ts
var get_transitions_default = defineCommand({
  args: {
    issueKey: issueKeySchema
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getTransitions(args.issueKey))
});
export {
  get_transitions_default as default
};
