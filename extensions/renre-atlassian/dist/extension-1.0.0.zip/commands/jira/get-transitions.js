import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-transitions.ts
var schema = external_exports.object({
  issueKey: issueKeySchema
});
async function getTransitions(context) {
  return jiraCommand(context, schema, (jira, args) => jira.getTransitions(args.issueKey));
}
export {
  getTransitions as default
};
