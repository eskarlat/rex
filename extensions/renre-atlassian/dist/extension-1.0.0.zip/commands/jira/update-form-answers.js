import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/update-form-answers.ts
var update_form_answers_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    formId: external_exports.string().min(1),
    answers: external_exports.record(external_exports.unknown())
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.updateProformaFormAnswers(args.issueKey, args.formId, args.answers);
    return { success: true };
  })
});
export {
  update_form_answers_default as default
};
