import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/update-form-answers.ts
async function updateFormAnswers(context) {
  return jiraCommand(context, async (jira, args) => {
    await jira.updateProformaFormAnswers(
      args["issueKey"],
      args["formId"],
      args["answers"]
    );
    return { success: true };
  });
}
export {
  updateFormAnswers as default
};
