import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/update-form-answers.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  formId: external_exports.string().min(1),
  answers: external_exports.record(external_exports.unknown())
});
async function updateFormAnswers(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.updateProformaFormAnswers(args.issueKey, args.formId, args.answers);
    return { success: true };
  });
}
export {
  updateFormAnswers as default
};
