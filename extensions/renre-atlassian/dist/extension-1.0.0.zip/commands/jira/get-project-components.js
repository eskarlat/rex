import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  projectKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-project-components.ts
var schema = external_exports.object({
  projectKey: projectKeySchema
});
async function getProjectComponents(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getProjectComponents(args.projectKey)
  );
}
export {
  getProjectComponents as default
};
