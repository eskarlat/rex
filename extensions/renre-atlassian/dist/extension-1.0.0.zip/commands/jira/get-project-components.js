import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  projectKeySchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-project-components.ts
var get_project_components_default = defineCommand({
  args: {
    projectKey: projectKeySchema
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getProjectComponents(args.projectKey))
});
export {
  get_project_components_default as default
};
