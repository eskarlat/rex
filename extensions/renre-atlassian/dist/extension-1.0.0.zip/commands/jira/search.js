import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  paginationSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/search.ts
var schema = external_exports.object({
  jql: external_exports.string().min(1, "JQL query is required"),
  fields: external_exports.array(external_exports.string()).optional()
}).merge(paginationSchema);
async function search(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.search(args.jql, args.startAt, args.maxResults, args.fields)
  );
}
export {
  search as default
};
