import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/search.ts
var search_default = defineCommand({
  args: {
    jql: external_exports.string().min(1, "JQL query is required"),
    fields: external_exports.array(external_exports.string()).optional(),
    startAt: external_exports.coerce.number().int().min(0).default(0),
    maxResults: external_exports.coerce.number().int().min(1).max(100).default(50)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.search(args.jql, args.startAt, args.maxResults, args.fields))
});
export {
  search_default as default
};
