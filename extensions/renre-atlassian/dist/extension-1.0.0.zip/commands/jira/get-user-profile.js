import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-user-profile.ts
var schema = external_exports.object({
  accountId: external_exports.string().optional()
});
async function getUserProfile(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => args.accountId ? jira.getUser(args.accountId) : jira.getMyself()
  );
}
export {
  getUserProfile as default
};
