import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-user-profile.ts
async function getUserProfile(context) {
  return jiraCommand(context, (jira, args) => {
    const accountId = args["accountId"];
    return accountId ? jira.getUser(accountId) : jira.getMyself();
  });
}
export {
  getUserProfile as default
};
