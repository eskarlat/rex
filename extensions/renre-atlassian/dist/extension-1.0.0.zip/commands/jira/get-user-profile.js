import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-user-profile.ts
var get_user_profile_default = defineCommand({
  args: {
    accountId: external_exports.string().optional()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => args.accountId ? jira.getUser(args.accountId) : jira.getMyself())
});
export {
  get_user_profile_default as default
};
