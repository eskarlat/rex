import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  sprintIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/add-issues-to-sprint.ts
var add_issues_to_sprint_default = defineCommand({
  args: {
    sprintId: sprintIdSchema,
    issueKeys: external_exports.array(external_exports.string()).min(1)
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.addIssuesToSprint(args.sprintId, args.issueKeys);
    return { success: true, sprintId: args.sprintId, issueKeys: args.issueKeys };
  })
});
export {
  add_issues_to_sprint_default as default
};
