import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/add-issues-to-sprint.ts
async function addIssuesToSprint(context) {
  return jiraCommand(context, async (jira, args) => {
    const sprintId = args["sprintId"];
    const issueKeys = args["issueKeys"];
    await jira.addIssuesToSprint(sprintId, issueKeys);
    return { success: true, sprintId, issueKeys };
  });
}
export {
  addIssuesToSprint as default
};
