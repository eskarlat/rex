import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  sprintIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/add-issues-to-sprint.ts
var schema = external_exports.object({
  sprintId: sprintIdSchema,
  issueKeys: external_exports.array(external_exports.string()).min(1)
});
async function addIssuesToSprint(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.addIssuesToSprint(args.sprintId, args.issueKeys);
    return { success: true, sprintId: args.sprintId, issueKeys: args.issueKeys };
  });
}
export {
  addIssuesToSprint as default
};
