import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-issue.ts
var get_issue_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    expand: external_exports.string().optional()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getIssue(args.issueKey, args.expand))
});
export {
  get_issue_default as default
};
