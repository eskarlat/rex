import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-issue.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  expand: external_exports.string().optional()
});
async function getIssue(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getIssue(args.issueKey, args.expand)
  );
}
export {
  getIssue as default
};
