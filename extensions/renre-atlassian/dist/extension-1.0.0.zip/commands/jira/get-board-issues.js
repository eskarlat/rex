import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  boardIdSchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-board-issues.ts
var get_board_issues_default = defineCommand({
  args: {
    boardId: boardIdSchema,
    startAt: external_exports.coerce.number().int().min(0).default(0),
    maxResults: external_exports.coerce.number().int().min(1).max(100).default(50)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getBoardIssues(args.boardId, args.startAt, args.maxResults))
});
export {
  get_board_issues_default as default
};
