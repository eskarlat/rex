import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  boardIdSchema,
  external_exports,
  paginationSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-board-issues.ts
var schema = external_exports.object({
  boardId: boardIdSchema
}).merge(paginationSchema);
async function getBoardIssues(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getBoardIssues(args.boardId, args.startAt, args.maxResults)
  );
}
export {
  getBoardIssues as default
};
