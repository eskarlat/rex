import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/remove-issue-link.ts
var remove_issue_link_default = defineCommand({
  args: {
    linkId: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.removeIssueLink(args.linkId);
    return { success: true, linkId: args.linkId };
  })
});
export {
  remove_issue_link_default as default
};
