import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/remove-issue-link.ts
var schema = external_exports.object({
  linkId: external_exports.string().min(1)
});
async function removeIssueLink(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.removeIssueLink(args.linkId);
    return { success: true, linkId: args.linkId };
  });
}
export {
  removeIssueLink as default
};
