import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/remove-issue-link.ts
async function removeIssueLink(context) {
  return jiraCommand(context, async (jira, args) => {
    const linkId = args["linkId"];
    await jira.removeIssueLink(linkId);
    return { success: true, linkId };
  });
}
export {
  removeIssueLink as default
};
