import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  accountIdSchema,
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/add-watcher.ts
var add_watcher_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    accountId: accountIdSchema
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.addWatcher(args.issueKey, args.accountId);
    return { success: true };
  })
});
export {
  add_watcher_default as default
};
