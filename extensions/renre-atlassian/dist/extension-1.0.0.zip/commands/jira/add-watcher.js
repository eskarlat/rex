import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/add-watcher.ts
async function addWatcher(context) {
  return jiraCommand(context, async (jira, args) => {
    await jira.addWatcher(args["issueKey"], args["accountId"]);
    return { success: true };
  });
}
export {
  addWatcher as default
};
