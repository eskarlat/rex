import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-issue-watchers.ts
var schema = external_exports.object({
  issueKey: issueKeySchema
});
async function getIssueWatchers(context) {
  return jiraCommand(context, schema, (jira, args) => jira.getWatchers(args.issueKey));
}
export {
  getIssueWatchers as default
};
