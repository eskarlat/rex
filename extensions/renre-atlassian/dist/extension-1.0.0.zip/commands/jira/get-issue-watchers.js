import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  issueKeySchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-issue-watchers.ts
var get_issue_watchers_default = defineCommand({
  args: {
    issueKey: issueKeySchema
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getWatchers(args.issueKey))
});
export {
  get_issue_watchers_default as default
};
