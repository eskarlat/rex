import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/download-attachment.ts
var schema = external_exports.object({
  attachmentId: external_exports.string().min(1)
});
async function downloadAttachment(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    const res = await jira.downloadAttachment(args.attachmentId);
    const text = await res.text();
    return { attachmentId: args.attachmentId, content: text };
  });
}
export {
  downloadAttachment as default
};
