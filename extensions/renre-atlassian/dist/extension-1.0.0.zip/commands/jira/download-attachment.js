import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/download-attachment.ts
async function downloadAttachment(context) {
  return jiraCommand(context, async (jira, args) => {
    const attachmentId = args["attachmentId"];
    const res = await jira.downloadAttachment(attachmentId);
    const text = await res.text();
    return { attachmentId, content: text };
  });
}
export {
  downloadAttachment as default
};
