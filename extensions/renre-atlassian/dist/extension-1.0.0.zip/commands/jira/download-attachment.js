import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/download-attachment.ts
var download_attachment_default = defineCommand({
  args: {
    attachmentId: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    const res = await jira.downloadAttachment(args.attachmentId);
    const text = await res.text();
    return { attachmentId: args.attachmentId, content: text };
  })
});
export {
  download_attachment_default as default
};
