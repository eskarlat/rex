import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-service-desks.ts
var schema = external_exports.object({});
async function getServiceDesks(context) {
  return jiraCommand(context, schema, (jira) => jira.getServiceDesks());
}
export {
  getServiceDesks as default
};
