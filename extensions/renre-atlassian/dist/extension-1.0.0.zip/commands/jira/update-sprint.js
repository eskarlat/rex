import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/update-sprint.ts
async function updateSprint(context) {
  return jiraCommand(context, (jira, args) => {
    const sprintId = args["sprintId"];
    const update = {};
    if (args["name"]) update.name = args["name"];
    if (args["state"]) update.state = args["state"];
    if (args["startDate"]) update.startDate = args["startDate"];
    if (args["endDate"]) update.endDate = args["endDate"];
    if (args["goal"]) update.goal = args["goal"];
    return jira.updateSprint(sprintId, update);
  });
}
export {
  updateSprint as default
};
