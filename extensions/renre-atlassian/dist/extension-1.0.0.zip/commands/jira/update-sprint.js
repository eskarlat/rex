import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  sprintIdSchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/update-sprint.ts
var update_sprint_default = defineCommand({
  args: {
    sprintId: sprintIdSchema,
    name: external_exports.string().optional(),
    state: external_exports.string().optional(),
    startDate: external_exports.string().optional(),
    endDate: external_exports.string().optional(),
    goal: external_exports.string().optional()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => {
    const update = {};
    if (args.name) update.name = args.name;
    if (args.state) update.state = args.state;
    if (args.startDate) update.startDate = args.startDate;
    if (args.endDate) update.endDate = args.endDate;
    if (args.goal) update.goal = args.goal;
    return jira.updateSprint(args.sprintId, update);
  })
});
export {
  update_sprint_default as default
};
