import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  sprintIdSchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/update-sprint.ts
var schema = external_exports.object({
  sprintId: sprintIdSchema,
  name: external_exports.string().optional(),
  state: external_exports.string().optional(),
  startDate: external_exports.string().optional(),
  endDate: external_exports.string().optional(),
  goal: external_exports.string().optional()
});
async function updateSprint(context) {
  return jiraCommand(context, schema, (jira, args) => {
    const update = {};
    if (args.name) update.name = args.name;
    if (args.state) update.state = args.state;
    if (args.startDate) update.startDate = args.startDate;
    if (args.endDate) update.endDate = args.endDate;
    if (args.goal) update.goal = args.goal;
    return jira.updateSprint(args.sprintId, update);
  });
}
export {
  updateSprint as default
};
