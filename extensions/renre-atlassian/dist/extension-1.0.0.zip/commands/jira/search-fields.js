import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/search-fields.ts
var search_fields_default = defineCommand({
  handler: (ctx) => jiraCommand(ctx, (jira) => jira.getFields())
});
export {
  search_fields_default as default
};
