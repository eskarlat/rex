import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/search-fields.ts
var search_fields_default = defineCommand({
  handler: (ctx) => jiraCommand(ctx, (jira) => jira.getFields())
});
export {
  search_fields_default as default
};
