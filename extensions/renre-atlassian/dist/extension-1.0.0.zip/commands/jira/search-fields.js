import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/search-fields.ts
var schema = external_exports.object({});
async function searchFields(context) {
  return jiraCommand(context, schema, (jira) => jira.getFields());
}
export {
  searchFields as default
};
