import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/search-fields.ts
async function searchFields(context) {
  return jiraCommand(context, (jira) => jira.getFields());
}
export {
  searchFields as default
};
