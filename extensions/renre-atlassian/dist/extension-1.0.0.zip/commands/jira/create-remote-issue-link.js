import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  issueKeySchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-remote-issue-link.ts
var create_remote_issue_link_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    url: external_exports.string().url(),
    title: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.createRemoteIssueLink(args.issueKey, {
    object: { url: args.url, title: args.title }
  }))
});
export {
  create_remote_issue_link_default as default
};
