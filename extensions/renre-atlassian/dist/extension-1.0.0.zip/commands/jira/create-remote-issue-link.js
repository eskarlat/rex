import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-remote-issue-link.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  url: external_exports.string().url(),
  title: external_exports.string().min(1)
});
async function createRemoteIssueLink(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.createRemoteIssueLink(args.issueKey, {
      object: { url: args.url, title: args.title }
    })
  );
}
export {
  createRemoteIssueLink as default
};
