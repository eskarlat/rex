import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/create-remote-issue-link.ts
async function createRemoteIssueLink(context) {
  return jiraCommand(
    context,
    (jira, args) => jira.createRemoteIssueLink(args["issueKey"], {
      object: { url: args["url"], title: args["title"] }
    })
  );
}
export {
  createRemoteIssueLink as default
};
