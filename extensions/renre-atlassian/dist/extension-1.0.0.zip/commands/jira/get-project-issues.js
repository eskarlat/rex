import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  paginationSchema,
  projectKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-project-issues.ts
var schema = external_exports.object({
  projectKey: projectKeySchema
}).merge(paginationSchema);
async function getProjectIssues(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.search(
      `project = ${args.projectKey} ORDER BY updated DESC`,
      args.startAt,
      args.maxResults
    )
  );
}
export {
  getProjectIssues as default
};
