import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand,
  paginationArgs
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-project-issues.ts
async function getProjectIssues(context) {
  return jiraCommand(context, (jira, args) => {
    const { startAt, maxResults } = paginationArgs(args);
    return jira.search(
      `project = ${args["projectKey"]} ORDER BY updated DESC`,
      startAt,
      maxResults
    );
  });
}
export {
  getProjectIssues as default
};
