import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/transition-issue.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  transitionId: external_exports.string().min(1)
});
async function transitionIssue(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    await jira.transitionIssue(args.issueKey, args.transitionId);
    return { success: true, issueKey: args.issueKey, transitionId: args.transitionId };
  });
}
export {
  transitionIssue as default
};
