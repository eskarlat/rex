import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/transition-issue.ts
var transition_issue_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    transitionId: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    await jira.transitionIssue(args.issueKey, args.transitionId);
    return { success: true, issueKey: args.issueKey, transitionId: args.transitionId };
  })
});
export {
  transition_issue_default as default
};
