import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/transition-issue.ts
async function transitionIssue(context) {
  return jiraCommand(context, async (jira, args) => {
    const issueKey = args["issueKey"];
    const transitionId = args["transitionId"];
    await jira.transitionIssue(issueKey, transitionId);
    return { success: true, issueKey, transitionId };
  });
}
export {
  transitionIssue as default
};
