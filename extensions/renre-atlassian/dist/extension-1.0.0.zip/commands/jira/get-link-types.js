import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-link-types.ts
async function getLinkTypes(context) {
  return jiraCommand(context, (jira) => jira.getLinkTypes());
}
export {
  getLinkTypes as default
};
