import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-issue-forms.ts
async function getIssueForms(context) {
  return jiraCommand(
    context,
    (jira, args) => jira.getIssueProformaForms(args["issueKey"])
  );
}
export {
  getIssueForms as default
};
