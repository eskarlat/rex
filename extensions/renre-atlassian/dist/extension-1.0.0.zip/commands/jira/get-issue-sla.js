import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-issue-sla.ts
async function getIssueSla(context) {
  return jiraCommand(context, (jira, args) => jira.getIssueSla(args["issueKey"]));
}
export {
  getIssueSla as default
};
