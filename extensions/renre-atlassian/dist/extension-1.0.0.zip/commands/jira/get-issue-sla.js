import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-issue-sla.ts
var schema = external_exports.object({
  issueKey: issueKeySchema
});
async function getIssueSla(context) {
  return jiraCommand(context, schema, (jira, args) => jira.getIssueSla(args.issueKey));
}
export {
  getIssueSla as default
};
