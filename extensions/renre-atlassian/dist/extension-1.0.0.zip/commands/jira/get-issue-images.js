import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-issue-images.ts
async function getIssueImages(context) {
  return jiraCommand(context, async (jira, args) => {
    const data = await jira.getIssueForAttachments(args["issueKey"]);
    const attachments = data["attachments"];
    return (attachments ?? []).filter((a) => {
      const mimeType = a["mimeType"];
      return mimeType?.startsWith("image/");
    });
  });
}
export {
  getIssueImages as default
};
