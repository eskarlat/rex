import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  issueKeySchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-issue-images.ts
var get_issue_images_default = defineCommand({
  args: {
    issueKey: issueKeySchema
  },
  handler: (ctx) => jiraCommand(ctx, async (jira, args) => {
    const data = await jira.getIssueForAttachments(args.issueKey);
    const attachments = data["attachments"];
    return (attachments ?? []).filter((a) => {
      const mimeType = a["mimeType"];
      return mimeType?.startsWith("image/");
    });
  })
});
export {
  get_issue_images_default as default
};
