import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-issue-images.ts
var schema = external_exports.object({
  issueKey: issueKeySchema
});
async function getIssueImages(context) {
  return jiraCommand(context, schema, async (jira, args) => {
    const data = await jira.getIssueForAttachments(args.issueKey);
    const attachments = data["attachments"];
    return (attachments ?? []).filter((a) => {
      const mimeType = a["mimeType"];
      return mimeType?.startsWith("image/");
    });
  });
}
export {
  getIssueImages as default
};
