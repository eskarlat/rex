import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/add-worklog.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  timeSpent: external_exports.string().min(1),
  comment: external_exports.string().optional(),
  started: external_exports.string().optional()
});
async function addWorklog(context) {
  return jiraCommand(context, schema, (jira, args) => {
    const worklog = { timeSpent: args.timeSpent };
    if (args.comment) worklog.comment = buildAdfBody(args.comment);
    if (args.started) worklog.started = args.started;
    return jira.addWorklog(args.issueKey, worklog);
  });
}
export {
  addWorklog as default
};
