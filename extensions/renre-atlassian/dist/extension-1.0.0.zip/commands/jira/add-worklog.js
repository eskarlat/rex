import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/add-worklog.ts
var add_worklog_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    timeSpent: external_exports.string().min(1),
    comment: external_exports.string().optional(),
    started: external_exports.string().optional()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => {
    const worklog = { timeSpent: args.timeSpent };
    if (args.comment) worklog.comment = buildAdfBody(args.comment);
    if (args.started) worklog.started = args.started;
    return jira.addWorklog(args.issueKey, worklog);
  })
});
export {
  add_worklog_default as default
};
