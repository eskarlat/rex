import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/add-worklog.ts
async function addWorklog(context) {
  return jiraCommand(context, (jira, args) => {
    const worklog = { timeSpent: args["timeSpent"] };
    if (args["comment"]) worklog.comment = buildAdfBody(args["comment"]);
    if (args["started"]) worklog.started = args["started"];
    return jira.addWorklog(args["issueKey"], worklog);
  });
}
export {
  addWorklog as default
};
