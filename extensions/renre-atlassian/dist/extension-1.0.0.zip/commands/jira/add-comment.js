import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import {
  issueKeySchema
} from "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/add-comment.ts
var add_comment_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    body: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.addComment(args.issueKey, buildAdfBody(args.body)))
});
export {
  add_comment_default as default
};
