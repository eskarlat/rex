import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/add-comment.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  body: external_exports.string().min(1)
});
async function addComment(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.addComment(args.issueKey, buildAdfBody(args.body))
  );
}
export {
  addComment as default
};
