import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-SETLJQLA.js";
import "../../chunks/chunk-5QSCZNEA.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-dev-summary.ts
var get_dev_summary_default = defineCommand({
  args: {
    issueId: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getDevelopmentSummary(args.issueId))
});
export {
  get_dev_summary_default as default
};
