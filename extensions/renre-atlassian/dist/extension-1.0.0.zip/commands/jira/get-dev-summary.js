import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-dev-summary.ts
var schema = external_exports.object({
  issueId: external_exports.string().min(1)
});
async function getDevSummary(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getDevelopmentSummary(args.issueId)
  );
}
export {
  getDevSummary as default
};
