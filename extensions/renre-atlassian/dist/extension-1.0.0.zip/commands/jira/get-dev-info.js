import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-dev-info.ts
var get_dev_info_default = defineCommand({
  args: {
    issueId: external_exports.string().min(1),
    applicationType: external_exports.string().optional(),
    dataType: external_exports.string().optional()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getDevelopmentInfo(args.issueId, args.applicationType, args.dataType))
});
export {
  get_dev_info_default as default
};
