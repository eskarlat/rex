import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/create-issue.ts
async function createIssue(context) {
  return jiraCommand(context, (jira, args) => {
    const fields = {
      project: { key: args["projectKey"] },
      issuetype: { name: args["issueType"] },
      summary: args["summary"],
      ...args["additionalFields"] ?? {}
    };
    if (args["description"]) fields.description = buildAdfBody(args["description"]);
    return jira.createIssue(fields);
  });
}
export {
  createIssue as default
};
