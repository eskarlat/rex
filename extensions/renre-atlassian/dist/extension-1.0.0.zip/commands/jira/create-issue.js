import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  projectKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-issue.ts
var create_issue_default = defineCommand({
  args: {
    projectKey: projectKeySchema,
    issueType: external_exports.string().min(1),
    summary: external_exports.string().min(1),
    description: external_exports.string().optional(),
    additionalFields: external_exports.record(external_exports.unknown()).optional()
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => {
    const fields = {
      project: { key: args.projectKey },
      issuetype: { name: args.issueType },
      summary: args.summary,
      ...args.additionalFields ?? {}
    };
    if (args.description) fields.description = buildAdfBody(args.description);
    return jira.createIssue(fields);
  })
});
export {
  create_issue_default as default
};
