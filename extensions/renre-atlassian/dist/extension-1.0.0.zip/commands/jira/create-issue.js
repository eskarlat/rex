import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  projectKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/create-issue.ts
var schema = external_exports.object({
  projectKey: projectKeySchema,
  issueType: external_exports.string().min(1),
  summary: external_exports.string().min(1),
  description: external_exports.string().optional(),
  additionalFields: external_exports.record(external_exports.unknown()).optional()
});
async function createIssue(context) {
  return jiraCommand(context, schema, (jira, args) => {
    const fields = {
      project: { key: args.projectKey },
      issuetype: { name: args.issueType },
      summary: args.summary,
      ...args.additionalFields ?? {}
    };
    if (args.description) fields.description = buildAdfBody(args.description);
    return jira.createIssue(fields);
  });
}
export {
  createIssue as default
};
