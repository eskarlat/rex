import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand,
  paginationArgs
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-changelogs.ts
async function getChangelogs(context) {
  return jiraCommand(context, (jira, args) => {
    const { startAt, maxResults } = paginationArgs(args, { startAt: 0, maxResults: 100 });
    return jira.getChangelogs(args["issueKey"], startAt, maxResults);
  });
}
export {
  getChangelogs as default
};
