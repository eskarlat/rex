import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-changelogs.ts
var schema = external_exports.object({
  issueKey: issueKeySchema,
  startAt: external_exports.coerce.number().int().min(0).default(0),
  maxResults: external_exports.coerce.number().int().min(1).max(100).default(100)
});
async function getChangelogs(context) {
  return jiraCommand(
    context,
    schema,
    (jira, args) => jira.getChangelogs(args.issueKey, args.startAt, args.maxResults)
  );
}
export {
  getChangelogs as default
};
