import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-changelogs.ts
var get_changelogs_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    startAt: external_exports.coerce.number().int().min(0).default(0),
    maxResults: external_exports.coerce.number().int().min(1).max(100).default(100)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getChangelogs(args.issueKey, args.startAt, args.maxResults))
});
export {
  get_changelogs_default as default
};
