import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/edit-comment.ts
async function editComment(context) {
  return jiraCommand(
    context,
    (jira, args) => jira.editComment(
      args["issueKey"],
      args["commentId"],
      buildAdfBody(args["body"])
    )
  );
}
export {
  editComment as default
};
