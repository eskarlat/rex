import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  buildAdfBody
} from "../../chunks/chunk-HA6T2D3R.js";
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand,
  external_exports
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/edit-comment.ts
var edit_comment_default = defineCommand({
  args: {
    issueKey: issueKeySchema,
    commentId: external_exports.string().min(1),
    body: external_exports.string().min(1)
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.editComment(args.issueKey, args.commentId, buildAdfBody(args.body)))
});
export {
  edit_comment_default as default
};
