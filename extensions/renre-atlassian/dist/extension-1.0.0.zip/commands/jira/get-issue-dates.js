import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-KEGTRLU7.js";
import {
  issueKeySchema
} from "../../chunks/chunk-7UH5QAIX.js";
import {
  defineCommand
} from "../../chunks/chunk-GIJXU2QH.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-issue-dates.ts
var get_issue_dates_default = defineCommand({
  args: {
    issueKey: issueKeySchema
  },
  handler: (ctx) => jiraCommand(ctx, (jira, args) => jira.getIssueDateFields(args.issueKey))
});
export {
  get_issue_dates_default as default
};
