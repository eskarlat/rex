import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-XR2646WS.js";
import "../../chunks/chunk-IVZ65HSR.js";
import "../../chunks/chunk-77GVX2VY.js";

// src/commands/jira/get-worklog.ts
async function getWorklog(context) {
  return jiraCommand(context, (jira, args) => jira.getWorklog(args["issueKey"]));
}
export {
  getWorklog as default
};
