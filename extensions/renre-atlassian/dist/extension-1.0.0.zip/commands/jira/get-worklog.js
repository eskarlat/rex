import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  jiraCommand
} from "../../chunks/chunk-I2NMBLXW.js";
import {
  external_exports,
  issueKeySchema
} from "../../chunks/chunk-JIYXZLUF.js";
import "../../chunks/chunk-LWY6IOUG.js";

// src/commands/jira/get-worklog.ts
var schema = external_exports.object({
  issueKey: issueKeySchema
});
async function getWorklog(context) {
  return jiraCommand(context, schema, (jira, args) => jira.getWorklog(args.issueKey));
}
export {
  getWorklog as default
};
