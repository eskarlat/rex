import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  puppeteer_default
} from "../chunks/chunk-TYSJUKUN.js";
import "../chunks/chunk-72UX6IX2.js";
import "../chunks/chunk-QPASOT6S.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-4EEO7SIT.js";
import "../chunks/chunk-SQQ3ZJ6I.js";
import "../chunks/chunk-AWU4Q6CL.js";
import {
  deleteGlobalSession,
  deleteState,
  getLogDir,
  isProcessAlive,
  readGlobalSession,
  readState,
  writeGlobalSession,
  writeState
} from "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/launch.ts
import { join } from "node:path";
function checkExistingLocal(projectPath) {
  const existing = readState(projectPath);
  if (!existing) return null;
  if (!isProcessAlive(existing.pid)) {
    deleteState(projectPath);
    deleteGlobalSession();
    return null;
  }
  return {
    output: [
      "## Browser Already Running",
      "",
      `- **PID**: ${String(existing.pid)}`,
      `- **Port**: ${String(existing.port)}`,
      `- **Launched**: ${existing.launchedAt}`,
      "",
      "Use `chrome-debugger:close` to stop it first."
    ].join("\n"),
    exitCode: 1
  };
}
function checkExistingGlobal() {
  const globalSession = readGlobalSession();
  if (!globalSession) return null;
  if (!isProcessAlive(globalSession.pid)) {
    deleteGlobalSession();
    return null;
  }
  return {
    output: [
      "## Browser Already Running (another project)",
      "",
      `- **PID**: ${String(globalSession.pid)}`,
      `- **Port**: ${String(globalSession.port)}`,
      `- **Project**: ${globalSession.projectPath}`,
      `- **Launched**: ${globalSession.launchedAt}`,
      "",
      "Only one browser instance is supported. Close it first from the originating project,",
      "or use `chrome-debugger:close` there."
    ].join("\n"),
    exitCode: 1
  };
}
function resolvePort(args, config) {
  if (typeof args.port === "number") return args.port;
  if (typeof config.port === "number") return config.port;
  return 9222;
}
var launch_default = defineCommand({
  handler: async (ctx) => {
    const localCheck = checkExistingLocal(ctx.projectPath);
    if (localCheck) return localCheck;
    const globalCheck = checkExistingGlobal();
    if (globalCheck) return globalCheck;
    const headless = ctx.config.headless === true || ctx.args.headless === true;
    const port = resolvePort(ctx.args, ctx.config);
    const executablePath = process.env["PUPPETEER_EXECUTABLE_PATH"] ?? void 0;
    const browser = await puppeteer_default.launch({
      headless,
      ...executablePath ? { executablePath } : {},
      ignoreDefaultArgs: ["--enable-automation"],
      args: [
        `--remote-debugging-port=${String(port)}`,
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-infobars",
        "--no-sandbox"
      ]
    });
    const wsEndpoint = browser.wsEndpoint();
    const browserProcess = browser.process();
    const pid = browserProcess?.pid ?? 0;
    const logDir = getLogDir(ctx.projectPath);
    const networkLogPath = join(logDir, "network.jsonl");
    const consoleLogPath = join(logDir, "console.jsonl");
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const browserState = {
      wsEndpoint,
      pid,
      port,
      launchedAt: now,
      networkLogPath,
      consoleLogPath
    };
    writeState(ctx.projectPath, browserState);
    writeGlobalSession({
      wsEndpoint,
      pid,
      port,
      projectPath: ctx.projectPath,
      launchedAt: now,
      lastSeenAt: now,
      headless,
      networkLogPath,
      consoleLogPath
    });
    void browser.disconnect();
    return {
      output: [
        "## Browser Launched",
        "",
        `- **Mode**: ${headless ? "headless" : "headed (visible)"}`,
        `- **Port**: ${String(port)}`,
        `- **PID**: ${String(pid)}`,
        `- **WebSocket**: \`${wsEndpoint}\``,
        "",
        "Ready for commands. Use `chrome-debugger:navigate --url <url>` to get started."
      ].join("\n"),
      exitCode: 0
    };
  }
});
export {
  launch_default as default
};
