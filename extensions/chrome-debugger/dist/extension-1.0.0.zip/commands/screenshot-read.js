import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  getScreenshotDir
} from "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/screenshot-read.ts
import { existsSync, readFileSync, realpathSync } from "node:fs";
import { basename, dirname, join, resolve } from "node:path";
function isInsideDir(filePath, dir) {
  const resolvedDir = realpathSync(resolve(dir));
  const parentDir = dirname(resolve(filePath));
  const realParent = existsSync(parentDir) ? realpathSync(parentDir) : parentDir;
  const resolved = join(realParent, basename(filePath));
  return resolved.startsWith(resolvedDir + "/") || resolved.startsWith(resolvedDir + "\\");
}
var screenshot_read_default = defineCommand({
  handler: (ctx) => {
    const filePath = typeof ctx.args.path === "string" ? ctx.args.path : null;
    if (!filePath) {
      return {
        output: JSON.stringify({ error: "Missing --path argument" }),
        exitCode: 1
      };
    }
    const screenshotDir = getScreenshotDir(ctx.projectPath);
    if (!isInsideDir(filePath, screenshotDir)) {
      return {
        output: JSON.stringify({ error: "Path must be inside the screenshot directory" }),
        exitCode: 1
      };
    }
    if (!existsSync(filePath)) {
      return {
        output: JSON.stringify({ error: `File not found: ${filePath}` }),
        exitCode: 1
      };
    }
    const realPath = realpathSync(filePath);
    if (!isInsideDir(realPath, screenshotDir)) {
      return {
        output: JSON.stringify({ error: "Path must be inside the screenshot directory" }),
        exitCode: 1
      };
    }
    const buffer = readFileSync(filePath);
    const base64 = buffer.toString("base64");
    return {
      output: JSON.stringify({
        dataUrl: `data:image/png;base64,${base64}`
      }),
      exitCode: 0
    };
  }
});
export {
  screenshot_read_default as default
};
