import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  probeCdpTargets,
  probeCdpVersion
} from "../chunks/chunk-SILCXKSH.js";
import {
  puppeteer_default
} from "../chunks/chunk-ZJD4FZVO.js";
import "../chunks/chunk-FOU2EXQ2.js";
import "../chunks/chunk-YGOXEHOS.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-LOYEZFXG.js";
import "../chunks/chunk-AWU4Q6CL.js";
import {
  getLogDir,
  isProcessAlive,
  readGlobalSession,
  readState,
  writeGlobalSession,
  writeState
} from "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand,
  external_exports
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/connect.ts
import { join } from "node:path";
function checkExistingBrowser(projectPath) {
  const local = readState(projectPath);
  if (local && isProcessAlive(local.pid)) {
    return `A managed browser is already running (PID: ${String(local.pid)}). Use \`chrome-debugger:close\` first.`;
  }
  const global = readGlobalSession();
  if (global && isProcessAlive(global.pid)) {
    return `A managed browser is already running (PID: ${String(global.pid)}, project: ${global.projectPath}). Use \`chrome-debugger:close\` first.`;
  }
  return null;
}
function formatTabSummary(targets) {
  const lines = targets.slice(0, 5).map((t, i) => `  ${String(i)}. ${t.title || "(untitled)"} \u2014 ${t.url}`);
  if (targets.length > 5) lines.push(`  ... and ${String(targets.length - 5)} more`);
  return lines;
}
function resolvePort(args, config) {
  if (typeof args.port === "number") return args.port;
  if (typeof config.port === "number") return config.port;
  return 9222;
}
var connect_default = defineCommand({
  args: {
    port: external_exports.number().default(9222)
  },
  handler: async (ctx) => {
    const conflict = checkExistingBrowser(ctx.projectPath);
    if (conflict) {
      return { output: `## Already Connected

${conflict}`, exitCode: 1 };
    }
    const port = resolvePort(ctx.args, ctx.config);
    const versionInfo = await probeCdpVersion(port);
    if (!versionInfo) {
      return {
        output: `## No Browser Found

No browser detected on CDP port ${String(port)}.
Make sure Chrome is running with \`--remote-debugging-port=${String(port)}\`.`,
        exitCode: 1
      };
    }
    const wsUrl = versionInfo.webSocketDebuggerUrl;
    const browser = await puppeteer_default.connect({ browserWSEndpoint: wsUrl });
    const tabCount = (await browser.pages()).length;
    void browser.disconnect();
    const targets = await probeCdpTargets(port);
    const pageTargets = (targets ?? []).filter((t) => t.type === "page");
    const logDir = getLogDir(ctx.projectPath);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const state = {
      wsEndpoint: wsUrl,
      pid: 0,
      port,
      launchedAt: now,
      networkLogPath: join(logDir, "network.jsonl"),
      consoleLogPath: join(logDir, "console.jsonl")
    };
    writeState(ctx.projectPath, state);
    const session = {
      ...state,
      projectPath: ctx.projectPath,
      lastSeenAt: now,
      headless: false
    };
    writeGlobalSession(session);
    const tabLines = formatTabSummary(pageTargets);
    return {
      output: [
        "## Connected to External Browser",
        "",
        `- **Browser**: ${versionInfo.Browser}`,
        `- **Port**: ${String(port)}`,
        `- **WebSocket**: \`${wsUrl}\``,
        `- **Tabs**: ${String(tabCount)}`,
        "",
        ...tabLines.length > 0 ? ["**Open tabs:**", ...tabLines, ""] : [],
        "All chrome-debugger commands are now available.",
        "Use `chrome-debugger:close` to disconnect (this will NOT close the external browser)."
      ].join("\n"),
      exitCode: 0
    };
  }
});
export {
  connect_default as default
};
