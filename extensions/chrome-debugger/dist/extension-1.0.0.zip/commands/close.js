import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  connectBrowser,
  disconnectCachedBrowser
} from "../chunks/chunk-Z6FOATMH.js";
import "../chunks/chunk-TYSJUKUN.js";
import "../chunks/chunk-72UX6IX2.js";
import "../chunks/chunk-QPASOT6S.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-4EEO7SIT.js";
import "../chunks/chunk-SQQ3ZJ6I.js";
import "../chunks/chunk-AWU4Q6CL.js";
import {
  deleteGlobalSession,
  deleteState,
  getLogDir,
  killProcessTree,
  readState
} from "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/close.ts
import { existsSync, unlinkSync } from "node:fs";
import { join } from "node:path";
var close_default = defineCommand({
  handler: async (ctx) => {
    const state = readState(ctx.projectPath);
    if (!state) {
      return {
        output: "No browser is running.",
        exitCode: 1
      };
    }
    disconnectCachedBrowser();
    const isExternal = state.pid === 0;
    if (!isExternal) {
      try {
        const browser = await connectBrowser(ctx.projectPath);
        await browser.close();
      } catch {
        killProcessTree(state.pid);
      }
      disconnectCachedBrowser();
    }
    const logDir = getLogDir(ctx.projectPath);
    for (const file of ["network.jsonl", "console.jsonl"]) {
      const logPath = join(logDir, file);
      if (existsSync(logPath)) {
        unlinkSync(logPath);
      }
    }
    deleteState(ctx.projectPath);
    deleteGlobalSession();
    return {
      output: [
        isExternal ? "## Disconnected from Browser" : "## Browser Closed",
        "",
        ...isExternal ? ["- **Status**: disconnected (external browser still running)"] : [`- **PID**: ${String(state.pid)} (terminated)`],
        "- **Logs**: cleaned up"
      ].join("\n"),
      exitCode: 0
    };
  }
});
export {
  close_default as default
};
