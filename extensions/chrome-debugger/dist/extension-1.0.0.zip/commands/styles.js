import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  getComputedStyles
} from "../chunks/chunk-RU2HKWWY.js";
import {
  markdownTable
} from "../chunks/chunk-RMALWN2J.js";
import {
  withBrowser
} from "../chunks/chunk-Z6FOATMH.js";
import "../chunks/chunk-TYSJUKUN.js";
import "../chunks/chunk-72UX6IX2.js";
import "../chunks/chunk-QPASOT6S.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-4EEO7SIT.js";
import "../chunks/chunk-SQQ3ZJ6I.js";
import "../chunks/chunk-AWU4Q6CL.js";
import "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/styles.ts
var KEY_PROPERTIES = [
  "display",
  "position",
  "width",
  "height",
  "margin",
  "padding",
  "border",
  "background",
  "color",
  "font-size",
  "font-family",
  "font-weight",
  "line-height",
  "text-align",
  "flex-direction",
  "justify-content",
  "align-items",
  "gap",
  "grid-template-columns",
  "overflow",
  "opacity",
  "z-index",
  "box-shadow",
  "border-radius",
  "transition",
  "transform"
];
var styles_default = defineCommand({
  handler: async (ctx) => {
    const selector = ctx.args.selector;
    if (typeof selector !== "string" || selector.length === 0) {
      return { output: "Error: --selector is required", exitCode: 1 };
    }
    const all = ctx.args.all === true;
    return withBrowser(ctx.projectPath, async (_browser, page) => {
      const computed = await page.evaluate(getComputedStyles, selector, KEY_PROPERTIES, all);
      if (!computed) {
        return {
          output: `No element found for selector: \`${selector}\``,
          exitCode: 1
        };
      }
      const rows = computed.map((s) => [s.property, s.value]);
      const table = markdownTable(["Property", "Value"], rows);
      return {
        output: [
          `## Computed Styles: \`${selector}\`${all ? " (all)" : ""}`,
          "",
          table
        ].join("\n"),
        exitCode: 0
      };
    });
  }
});
export {
  styles_default as default
};
