import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  getStorageEntries
} from "../chunks/chunk-RU2HKWWY.js";
import {
  markdownTable,
  truncate
} from "../chunks/chunk-RMALWN2J.js";
import {
  withBrowser
} from "../chunks/chunk-EKQZN3GU.js";
import "../chunks/chunk-AT5YMNYW.js";
import "../chunks/chunk-YGOXEHOS.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-FOU2EXQ2.js";
import "../chunks/chunk-LOYEZFXG.js";
import "../chunks/chunk-AWU4Q6CL.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-YIRAWI45.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/storage.ts
var storage_default = defineCommand({
  handler: async (ctx) => {
    const storageType = typeof ctx.args.type === "string" ? ctx.args.type : "local";
    return withBrowser(ctx.projectPath, async (_browser, page) => {
      const entries = await page.evaluate(getStorageEntries, storageType);
      const label = storageType === "session" ? "sessionStorage" : "localStorage";
      if (entries.length === 0) {
        return { output: `${label} is empty.`, exitCode: 0 };
      }
      const rows = entries.map((e) => [truncate(e.key, 40), truncate(e.value, 60)]);
      const table = markdownTable(["Key", "Value"], rows);
      return {
        output: [`## ${label} (${String(entries.length)} entries)`, "", table].join("\n"),
        exitCode: 0
      };
    });
  }
});
export {
  storage_default as default
};
