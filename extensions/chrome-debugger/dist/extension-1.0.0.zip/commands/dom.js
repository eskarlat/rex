import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  serializeFullPage,
  serializeSubtree
} from "../chunks/chunk-RU2HKWWY.js";
import {
  markdownCodeBlock
} from "../chunks/chunk-RMALWN2J.js";
import {
  withBrowser
} from "../chunks/chunk-7EP7YKOD.js";
import "../chunks/chunk-ZJD4FZVO.js";
import "../chunks/chunk-FOU2EXQ2.js";
import "../chunks/chunk-YGOXEHOS.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-LOYEZFXG.js";
import "../chunks/chunk-AWU4Q6CL.js";
import "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/dom.ts
var dom_default = defineCommand({
  handler: async (ctx) => {
    const selector = typeof ctx.args.selector === "string" ? ctx.args.selector : null;
    const depth = typeof ctx.args.depth === "number" ? ctx.args.depth : 5;
    return withBrowser(ctx.projectPath, async (_browser, page) => {
      const html = selector ? await page.evaluate(serializeSubtree, selector, depth) : await page.evaluate(serializeFullPage, depth);
      const title = selector ? `DOM: \`${selector}\`` : "DOM Tree";
      return {
        output: [`## ${title}`, "", markdownCodeBlock(html, "html")].join("\n"),
        exitCode: 0
      };
    });
  }
});
export {
  dom_default as default
};
