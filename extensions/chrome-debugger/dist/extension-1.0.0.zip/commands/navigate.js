import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  withBrowser
} from "../chunks/chunk-Z6FOATMH.js";
import "../chunks/chunk-TYSJUKUN.js";
import "../chunks/chunk-72UX6IX2.js";
import "../chunks/chunk-QPASOT6S.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-4EEO7SIT.js";
import "../chunks/chunk-SQQ3ZJ6I.js";
import "../chunks/chunk-AWU4Q6CL.js";
import "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand,
  external_exports
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/navigate.ts
var navigate_default = defineCommand({
  args: {
    url: external_exports.string({ required_error: "--url is required" }).min(1, "--url is required"),
    wait: external_exports.enum(["load", "domcontentloaded"]).default("domcontentloaded")
  },
  handler: async (ctx) => {
    const { url, wait } = ctx.args;
    return withBrowser(ctx.projectPath, async (_browser, page) => {
      const response = await page.goto(url, { waitUntil: wait });
      const status = response?.status() ?? 0;
      const title = await page.title();
      const finalUrl = page.url();
      return {
        output: [
          "## Navigated",
          "",
          `- **URL**: ${finalUrl}`,
          `- **Title**: ${title}`,
          `- **Status**: ${String(status)}`
        ].join("\n"),
        exitCode: 0
      };
    });
  }
});
export {
  navigate_default as default
};
