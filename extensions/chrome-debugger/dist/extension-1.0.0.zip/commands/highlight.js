import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  withBrowser
} from "../chunks/chunk-7EP7YKOD.js";
import "../chunks/chunk-ZJD4FZVO.js";
import "../chunks/chunk-FOU2EXQ2.js";
import "../chunks/chunk-YGOXEHOS.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-LOYEZFXG.js";
import "../chunks/chunk-AWU4Q6CL.js";
import "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/highlight.ts
var highlight_default = defineCommand({
  handler: async (ctx) => {
    const selector = ctx.args.selector;
    if (typeof selector !== "string" || selector.length === 0) {
      return { output: "Error: --selector is required", exitCode: 1 };
    }
    const duration = typeof ctx.args.duration === "number" ? ctx.args.duration : 3e3;
    return withBrowser(ctx.projectPath, async (_browser, page) => {
      const client = await page.createCDPSession();
      await client.send("DOM.enable");
      await client.send("Overlay.enable");
      const { root } = await client.send("DOM.getDocument");
      const { nodeId } = await client.send("DOM.querySelector", {
        nodeId: root.nodeId,
        selector
      });
      if (nodeId === 0) {
        return {
          output: `No element found for selector: \`${selector}\``,
          exitCode: 1
        };
      }
      await client.send("Overlay.highlightNode", {
        nodeId,
        highlightConfig: {
          showInfo: true,
          showStyles: true,
          showAccessibilityInfo: true,
          contentColor: { r: 111, g: 168, b: 220, a: 0.66 },
          paddingColor: { r: 147, g: 196, b: 125, a: 0.55 },
          borderColor: { r: 255, g: 229, b: 153, a: 0.66 },
          marginColor: { r: 246, g: 178, b: 107, a: 0.66 }
        }
      });
      await new Promise((resolve) => setTimeout(resolve, duration));
      await client.send("Overlay.hideHighlight");
      return {
        output: [
          `## Highlighted: \`${selector}\``,
          "",
          `Element was highlighted for ${String(duration / 1e3)}s in the browser.`
        ].join("\n"),
        exitCode: 0
      };
    });
  }
});
export {
  highlight_default as default
};
