import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  withBrowser
} from "../chunks/chunk-7EP7YKOD.js";
import "../chunks/chunk-ZJD4FZVO.js";
import "../chunks/chunk-FOU2EXQ2.js";
import "../chunks/chunk-YGOXEHOS.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-LOYEZFXG.js";
import "../chunks/chunk-AWU4Q6CL.js";
import "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand,
  external_exports
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/click.ts
var click_default = defineCommand({
  args: {
    selector: external_exports.string({ required_error: "--selector is required" }).min(1, "--selector is required")
  },
  handler: async (ctx) => {
    const { selector } = ctx.args;
    return withBrowser(ctx.projectPath, async (_browser, page) => {
      const exists = await page.$(selector);
      if (!exists) {
        return {
          output: `No element found for selector: \`${selector}\``,
          exitCode: 1
        };
      }
      await page.click(selector);
      const title = await page.title();
      const url = page.url();
      return {
        output: [
          `## Clicked: \`${selector}\``,
          "",
          `- **Current URL**: ${url}`,
          `- **Page Title**: ${title}`
        ].join("\n"),
        exitCode: 0
      };
    });
  }
});
export {
  click_default as default
};
