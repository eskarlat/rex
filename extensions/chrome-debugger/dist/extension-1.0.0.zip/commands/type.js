import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  withBrowser
} from "../chunks/chunk-IRKENI54.js";
import "../chunks/chunk-AT5YMNYW.js";
import "../chunks/chunk-YGOXEHOS.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-FOU2EXQ2.js";
import "../chunks/chunk-LOYEZFXG.js";
import "../chunks/chunk-AWU4Q6CL.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-YIRAWI45.js";
import {
  defineCommand,
  external_exports
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/type.ts
var type_default = defineCommand({
  args: {
    selector: external_exports.string({ required_error: "--selector is required" }).min(1, "--selector is required"),
    text: external_exports.string({ required_error: "--text is required" }),
    clear: external_exports.boolean().default(false)
  },
  handler: async (ctx) => {
    const { selector, text, clear } = ctx.args;
    return withBrowser(ctx.projectPath, async (_browser, page) => {
      const exists = await page.$(selector);
      if (!exists) {
        return {
          output: `No element found for selector: \`${selector}\``,
          exitCode: 1
        };
      }
      if (clear) {
        await page.evaluate((sel) => {
          const el = document.querySelector(sel);
          if (el) el.value = "";
        }, selector);
      }
      await page.type(selector, text);
      return {
        output: [
          `## Typed into: \`${selector}\``,
          "",
          `- **Text**: "${text}"`,
          `- **Cleared first**: ${clear ? "yes" : "no"}`
        ].join("\n"),
        exitCode: 0
      };
    });
  }
});
export {
  type_default as default
};
