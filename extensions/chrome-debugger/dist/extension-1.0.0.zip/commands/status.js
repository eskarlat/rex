import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  probeCdpTargets
} from "../chunks/chunk-SILCXKSH.js";
import {
  deleteGlobalSession,
  deleteState,
  isProcessAlive,
  readGlobalSession,
  readState
} from "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/status.ts
function resolvePort(args, config) {
  if (typeof args.port === "number") return args.port;
  if (typeof config.port === "number") return config.port;
  return 9222;
}
function targetsToTabs(targets) {
  return targets.filter((t) => t.type === "page").map((page, index) => ({ index, title: page.title, url: page.url }));
}
function jsonResult(data) {
  return { output: JSON.stringify(data), exitCode: 0 };
}
function cleanupStaleSession(projectPath, localState, globalSession) {
  if (localState) deleteState(projectPath);
  if (globalSession) deleteGlobalSession();
  return jsonResult({ running: false, staleSessionCleaned: true });
}
function buildActiveStatus(state, tabs, globalSession, localState) {
  return {
    running: true,
    pid: state.pid,
    port: state.port,
    launchedAt: state.launchedAt,
    tabCount: tabs.length,
    tabs,
    ...globalSession && !localState ? { projectPath: globalSession.projectPath, headless: globalSession.headless } : {}
  };
}
var status_default = defineCommand({
  handler: async (ctx) => {
    const localState = readState(ctx.projectPath);
    const globalSession = readGlobalSession();
    const port = resolvePort(ctx.args, ctx.config);
    const state = localState ?? globalSession;
    if (!state) {
      const targets2 = await probeCdpTargets(port);
      if (targets2) {
        const tabs = targetsToTabs(targets2);
        return jsonResult({ running: true, external: true, port, tabCount: tabs.length, tabs });
      }
      return jsonResult({ running: false });
    }
    if (!isProcessAlive(state.pid)) {
      return cleanupStaleSession(ctx.projectPath, localState, globalSession);
    }
    const targets = await probeCdpTargets(state.port);
    if (targets) {
      return jsonResult(buildActiveStatus(state, targetsToTabs(targets), globalSession, localState));
    }
    return cleanupStaleSession(ctx.projectPath, localState, globalSession);
  }
});
export {
  status_default as default
};
