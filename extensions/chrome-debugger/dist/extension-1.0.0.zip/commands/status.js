import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  deleteGlobalSession,
  deleteState,
  isProcessAlive,
  readGlobalSession,
  readState
} from "../chunks/chunk-YIRAWI45.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/status.ts
async function fetchTabsViaHttp(port) {
  const response = await fetch(`http://127.0.0.1:${String(port)}/json`);
  if (!response.ok) {
    throw new Error(`CDP HTTP request failed: ${String(response.status)}`);
  }
  const targets = await response.json();
  return targets.filter((t) => t.type === "page");
}
async function status(context) {
  const localState = readState(context.projectPath);
  const globalSession = readGlobalSession();
  const state = localState ?? globalSession;
  if (!state) {
    return {
      output: JSON.stringify({ running: false }),
      exitCode: 0
    };
  }
  if (!isProcessAlive(state.pid)) {
    if (localState) deleteState(context.projectPath);
    if (globalSession) deleteGlobalSession();
    return {
      output: JSON.stringify({ running: false, staleSessionCleaned: true }),
      exitCode: 0
    };
  }
  try {
    const pages = await fetchTabsViaHttp(state.port);
    const tabs = pages.map((page, index) => ({
      index,
      title: page.title,
      url: page.url
    }));
    const result = {
      running: true,
      pid: state.pid,
      port: state.port,
      launchedAt: state.launchedAt,
      tabCount: tabs.length,
      tabs,
      ...globalSession ? { projectPath: globalSession.projectPath, headless: globalSession.headless } : {}
    };
    return {
      output: JSON.stringify(result),
      exitCode: 0
    };
  } catch {
    if (localState) deleteState(context.projectPath);
    if (globalSession) deleteGlobalSession();
    return {
      output: JSON.stringify({ running: false, staleSessionCleaned: true }),
      exitCode: 0
    };
  }
}
export {
  status as default
};
