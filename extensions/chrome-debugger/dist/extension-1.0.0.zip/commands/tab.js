import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  connectBrowser,
  getPageByIndex
} from "../chunks/chunk-Z6FOATMH.js";
import "../chunks/chunk-TYSJUKUN.js";
import "../chunks/chunk-72UX6IX2.js";
import "../chunks/chunk-QPASOT6S.js";
import "../chunks/chunk-BF5SUUWU.js";
import "../chunks/chunk-A7XEC37O.js";
import "../chunks/chunk-ICGADTKU.js";
import "../chunks/chunk-WWTA3VPD.js";
import "../chunks/chunk-4EEO7SIT.js";
import "../chunks/chunk-SQQ3ZJ6I.js";
import "../chunks/chunk-AWU4Q6CL.js";
import {
  ensureBrowserRunning
} from "../chunks/chunk-AXW2RRIA.js";
import {
  defineCommand
} from "../chunks/chunk-2G267IVB.js";
import "../chunks/chunk-C3C6F2UY.js";

// src/commands/tab.ts
var tab_default = defineCommand({
  handler: async (ctx) => {
    const positional = Array.isArray(ctx.args._positional) ? ctx.args._positional : [];
    const index = Number(ctx.args.index ?? positional[0]);
    if (Number.isNaN(index)) {
      return { output: "Error: --index <number> is required", exitCode: 1 };
    }
    ensureBrowserRunning(ctx.projectPath);
    const browser = await connectBrowser(ctx.projectPath);
    const page = await getPageByIndex(browser, index);
    await page.bringToFront();
    const title = await page.title();
    return {
      output: [
        "## Switched Tab",
        "",
        `- **Index**: ${String(index)}`,
        `- **Title**: ${title}`,
        `- **URL**: ${page.url()}`
      ].join("\n"),
      exitCode: 0
    };
  }
});
export {
  tab_default as default
};
