import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  puppeteer_default
} from "./chunk-AT5YMNYW.js";
import {
  ensureBrowserRunning
} from "./chunk-YIRAWI45.js";

// src/shared/connection.ts
var cachedBrowser = null;
var cachedEndpoint = null;
function isConnected(browser) {
  return browser.connected;
}
async function connectBrowser(projectPath) {
  const state = ensureBrowserRunning(projectPath);
  if (cachedBrowser && cachedEndpoint === state.wsEndpoint && isConnected(cachedBrowser)) {
    return cachedBrowser;
  }
  if (cachedBrowser) {
    try {
      cachedBrowser.disconnect();
    } catch {
    }
  }
  const browser = await puppeteer_default.connect({ browserWSEndpoint: state.wsEndpoint });
  cachedBrowser = browser;
  cachedEndpoint = state.wsEndpoint;
  browser.on("disconnected", () => {
    if (cachedBrowser === browser) {
      cachedBrowser = null;
      cachedEndpoint = null;
    }
  });
  return browser;
}
function disconnectCachedBrowser() {
  if (cachedBrowser) {
    try {
      cachedBrowser.disconnect();
    } catch {
    }
    cachedBrowser = null;
    cachedEndpoint = null;
  }
}
async function getActivePage(browser) {
  const pages = await browser.pages();
  const page = pages[pages.length - 1];
  if (!page) {
    throw new Error("No open tabs found in browser");
  }
  return page;
}
async function getPageByIndex(browser, index) {
  const pages = await browser.pages();
  const page = pages[index];
  if (!page) {
    throw new Error(`Tab index ${String(index)} out of range (${String(pages.length)} tabs open)`);
  }
  return page;
}
async function withBrowser(projectPath, fn) {
  const browser = await connectBrowser(projectPath);
  const page = await getActivePage(browser);
  return fn(browser, page);
}

export {
  connectBrowser,
  disconnectCachedBrowser,
  getActivePage,
  getPageByIndex,
  withBrowser
};
