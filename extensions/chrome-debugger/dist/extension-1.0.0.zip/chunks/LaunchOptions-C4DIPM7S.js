import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  convertPuppeteerChannelToBrowsersChannel
} from "./chunk-72UX6IX2.js";
import "./chunk-4EEO7SIT.js";
import "./chunk-SQQ3ZJ6I.js";
import "./chunk-AWU4Q6CL.js";
import "./chunk-C3C6F2UY.js";
export {
  convertPuppeteerChannelToBrowsersChannel
};
