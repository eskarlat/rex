import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  require_typescript
} from "./chunk-QPASOT6S.js";
import "./chunk-SQQ3ZJ6I.js";
import "./chunk-C3C6F2UY.js";
export default require_typescript();
