import { createRequire } from 'module'; const require = createRequire(import.meta.url);
import {
  puppeteer_default
} from "./chunk-TYSJUKUN.js";
import {
  ensureBrowserRunning
} from "./chunk-AXW2RRIA.js";

// src/shared/monitoring.ts
import { appendFileSync, existsSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";
var monitoredPages = /* @__PURE__ */ new WeakSet();
async function setupPageMonitoring(page, networkLogPath, consoleLogPath) {
  if (monitoredPages.has(page)) return;
  monitoredPages.add(page);
  const dir = dirname(networkLogPath);
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }
  const client = await page.createCDPSession();
  await client.send("Network.enable");
  const pendingRequests = /* @__PURE__ */ new Map();
  client.on("Network.requestWillBeSent", (params) => {
    pendingRequests.set(params.requestId, {
      method: params.request.method,
      url: params.request.url,
      type: params.type ?? "Other",
      startTime: params.timestamp
    });
  });
  client.on("Network.responseReceived", (params) => {
    const req = pendingRequests.get(params.requestId);
    if (!req) return;
    pendingRequests.delete(params.requestId);
    const entry = JSON.stringify({
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      method: req.method,
      url: req.url,
      status: params.response.status,
      type: req.type,
      size: params.response.headers["content-length"] ? Number(params.response.headers["content-length"]) : 0,
      duration: Math.round((params.timestamp - req.startTime) * 1e3)
    });
    appendFileSync(networkLogPath, entry + "\n");
  });
  await client.send("Runtime.enable");
  client.on("Runtime.consoleAPICalled", (params) => {
    const text = params.args.map((arg) => {
      if (arg.value !== void 0) return String(arg.value);
      if (arg.description) return arg.description;
      return arg.type;
    }).join(" ");
    const entry = JSON.stringify({
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: params.type,
      text
    });
    appendFileSync(consoleLogPath, entry + "\n");
  });
}
async function setupBrowserMonitoring(browser, networkLogPath, consoleLogPath) {
  const pages = await browser.pages();
  for (const page of pages) {
    await setupPageMonitoring(page, networkLogPath, consoleLogPath);
  }
  browser.on("targetcreated", (target) => {
    const targetType = target.type();
    if (targetType === "page") {
      void target.page().then((newPage) => {
        if (newPage) {
          void setupPageMonitoring(newPage, networkLogPath, consoleLogPath);
        }
      });
    }
  });
}

// src/shared/connection.ts
var browserCache = /* @__PURE__ */ new Map();
async function connectBrowser(projectPath) {
  const state = ensureBrowserRunning(projectPath);
  const endpoint = state.wsEndpoint;
  const cached = browserCache.get(endpoint);
  if (cached?.connected) {
    return cached;
  }
  if (cached) {
    browserCache.delete(endpoint);
  }
  const browser = await puppeteer_default.connect({ browserWSEndpoint: endpoint });
  browserCache.set(endpoint, browser);
  browser.on("disconnected", () => {
    if (browserCache.get(endpoint) === browser) {
      browserCache.delete(endpoint);
    }
  });
  try {
    await setupBrowserMonitoring(browser, state.networkLogPath, state.consoleLogPath);
  } catch {
  }
  return browser;
}
function disconnectCachedBrowser() {
  for (const [endpoint, browser] of browserCache) {
    browserCache.delete(endpoint);
    void browser.disconnect();
  }
}
async function getActivePage(browser) {
  const pages = await browser.pages();
  const page = pages[pages.length - 1];
  if (!page) {
    throw new Error("No open tabs found in browser");
  }
  return page;
}
async function getPageByIndex(browser, index) {
  const pages = await browser.pages();
  const page = pages[index];
  if (!page) {
    throw new Error(`Tab index ${String(index)} out of range (${String(pages.length)} tabs open)`);
  }
  return page;
}
async function withBrowser(projectPath, fn) {
  const browser = await connectBrowser(projectPath);
  const page = await getActivePage(browser);
  return fn(browser, page);
}

export {
  connectBrowser,
  disconnectCachedBrowser,
  getActivePage,
  getPageByIndex,
  withBrowser
};
