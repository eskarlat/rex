import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// src/shared/cdp-probe.ts
async function probeCdpTargets(port) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2e3);
    const response = await fetch(`http://127.0.0.1:${String(port)}/json`, {
      signal: controller.signal
    });
    clearTimeout(timeout);
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  }
}
async function probeCdpVersion(port) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2e3);
    const response = await fetch(`http://127.0.0.1:${String(port)}/json/version`, {
      signal: controller.signal
    });
    clearTimeout(timeout);
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  }
}

export {
  probeCdpTargets,
  probeCdpVersion
};
